package com.thinking.machines.inventory.dl; 
import com.thinking.machines.inventory.dl.exceptions.*; 
import java.sql.*; 
public class DAOConnection 
{
 private DAOConnection()
 { } 
public static Connection getConnection() throws DAOException 
{
 Connection connection=null;
 try 
{
 Class.forName("org.sqlite.JDBC");
 connection=DriverManager.getConnection("jdbc:sqlite:inventory.db");
 }catch(Exception exception)
 {
 throw new DAOException(exception.getMessage());
 }
 return connection;
 }
 }