package com.thinking.machines.inventory.dl;
import com.thinking.machines.inventory.dl.exceptions.*;
import com.thinking.machines.inventory.dl.interfaces.*;
import java.util.*;
import java.sql.*;
public class ItemDAO implements ItemDAOInterface
{
public void add(ItemDTOInterface itemDTOInterface) throws DAOException
{
try
{
Connection connection;
connection=DAOConnection.getConnection();
PreparedStatement preparedStatement;
preparedStatement=connection.prepareStatement("select * from item where name=?");
preparedStatement.setString(1,itemDTOInterface.getName());
ResultSet resultSet;
resultSet=preparedStatement.executeQuery();
if(resultSet.next()==true)
{
resultSet.close();
preparedStatement.close();
connection.close();
throw new DAOException("Item : "+itemDTOInterface.getName()+" exists.");
}
resultSet.close();
preparedStatement.close();
preparedStatement=connection.prepareStatement("insert into item (name,category,price) values(?,?,?)");
preparedStatement.setString(1,itemDTOInterface.getName());
preparedStatement.setString(2,itemDTOInterface.getCategory());
preparedStatement.setInt(3,itemDTOInterface.getPrice());
preparedStatement.executeUpdate();
resultSet=preparedStatement.getGeneratedKeys();
resultSet.next();
int generatedCode=resultSet.getInt(1);
resultSet.close();
preparedStatement.close();
connection.close();
itemDTOInterface.setCode(generatedCode);
}catch(SQLException sqlException)
{
throw new DAOException("com.thinking.machines.inventory.dl.ItemDAO : public void add(ItemDTOInterface itemDTOInterface) : "+sqlException.getMessage());
}
}
public void update(ItemDTOInterface itemDTOInterface) throws DAOException
{
try
{
Connection connection=DAOConnection.getConnection();
PreparedStatement preparedStatement;
preparedStatement=connection.prepareStatement("select * from item where code=?");
preparedStatement.setInt(1,itemDTOInterface.getCode());
ResultSet resultSet;
resultSet=preparedStatement.executeQuery();
if(resultSet.next()==false)
{
resultSet.close();
preparedStatement.close();
connection.close();
throw new DAOException("Item code : "+itemDTOInterface.getCode()+" does not exist.");
}
resultSet.close();

preparedStatement.close();
preparedStatement=connection.prepareStatement("select * from item where name=? and code<>?");
preparedStatement.setString(1,itemDTOInterface.getName());
preparedStatement.setInt(2,itemDTOInterface.getCode());
resultSet=preparedStatement.executeQuery();
if(resultSet.next())
{
resultSet.close();
preparedStatement.close();
connection.close();
throw new DAOException("Item : "+itemDTOInterface.getName()+" exists.");
}
resultSet.close();
preparedStatement.close();
preparedStatement=connection.prepareStatement("update item set name=?,category=?,price=? where code=?");
preparedStatement.setString(1,itemDTOInterface.getName());
preparedStatement.setString(2,itemDTOInterface.getCategory());
preparedStatement.setInt(3,itemDTOInterface.getPrice());
preparedStatement.setInt(4,itemDTOInterface.getCode());
preparedStatement.executeUpdate();
preparedStatement.close();
connection.close();
}catch(SQLException sqlException)
{
throw new DAOException("com.thinking.machines.inventory.dl.ItemDAO : public void update(ItemDTOInterface itemDTOInterface) : "+sqlException.getMessage());
}
}
public void delete(int code) throws DAOException
{
try
{
Connection connection=DAOConnection.getConnection();
PreparedStatement preparedStatement;
preparedStatement=connection.prepareStatement("select * from item where code=?");
preparedStatement.setInt(1,code);
ResultSet resultSet;
resultSet=preparedStatement.executeQuery();
if(resultSet.next()==false)
{
resultSet.close();
preparedStatement.close();
connection.close();
throw new DAOException("Item code : "+code+" does not exist.");
}
resultSet.close();
preparedStatement.close();
preparedStatement=connection.prepareStatement("delete from item where code=?");
preparedStatement.setInt(1,code);
preparedStatement.executeUpdate();
preparedStatement.close();
connection.close();
}catch(SQLException sqlException)
{
throw new DAOException("com.thinking.machines.inventory.dl.ItemDAO : public void delete(intcode) : "+sqlException.getMessage());
}
}
public ItemDTOInterface get(int code) throws DAOException
{
ItemDTOInterface itemDTOInterface=null;
try
{
Connection connection=DAOConnection.getConnection();
PreparedStatement preparedStatement;
preparedStatement=connection.prepareStatement("select * from item where code=?");
preparedStatement.setInt(1,code);
ResultSet resultSet;
resultSet=preparedStatement.executeQuery();
if(resultSet.next()==false)
{
resultSet.close();
preparedStatement.close();
connection.close();
throw new DAOException("Item code : "+code+" does not exist.");
}
itemDTOInterface=new ItemDTO();
itemDTOInterface.setCode(resultSet.getInt("code"));
itemDTOInterface.setName(resultSet.getString("name").trim());
itemDTOInterface.setCategory(resultSet.getString("category").trim());
itemDTOInterface.setPrice(resultSet.getInt("price"));
resultSet.close();
preparedStatement.close();
connection.close();
}catch(SQLException sqlException)
{
throw new DAOException("com.thinking.machines.inventory.dl.ItemDAO : public ItemDTOInterface get(int code) : "+sqlException.getMessage());
}
return itemDTOInterface;
}
public ArrayList<ItemDTOInterface> getAll() throws DAOException
{
ArrayList<ItemDTOInterface> items;
ItemDTOInterface itemDTOInterface;
try
{
Connection connection=DAOConnection.getConnection();
Statement statement=connection.createStatement();
ResultSet resultSet;
resultSet=statement.executeQuery("select * from item order by name");
if(resultSet.next()==false)
{
resultSet.close();
statement.close();
connection.close();
throw new DAOException("No Items");
}
items=new ArrayList<ItemDTOInterface>();
do
{
itemDTOInterface=new ItemDTO();
itemDTOInterface.setCode(resultSet.getInt("code"));
itemDTOInterface.setName(resultSet.getString("name").trim());
itemDTOInterface.setCategory(resultSet.getString("category").trim());
itemDTOInterface.setPrice(resultSet.getInt("price"));
items.add(itemDTOInterface);
}while(resultSet.next());
resultSet.close();
statement.close();
connection.close();
}catch(SQLException sqlException)
{
throw new DAOException("com.thinking.machines.inventory.dl.ItemDAO : public ArrayList<ItemDTOInterface> getAll() : "+sqlException.getMessage());
}
return items;
}
public long getCount() throws DAOException
{
long count;
try
{
Connection connection;
connection=DAOConnection.getConnection();
Statement statement;
statement=connection.createStatement();
ResultSet resultSet;
resultSet=statement.executeQuery("select count(*) as cnt from item");
resultSet.next();
count=resultSet.getLong("cnt");
resultSet.close();
statement.close();
connection.close();
}catch(SQLException sqlException)
{
throw new DAOException("com.thinking.machines.inventory.dl.ItemDAO : public long getCount() :"+sqlException.getMessage());
}
return count;
}
public boolean codeExists(int code) throws DAOException
{
boolean exists=false;
try
{
Connection connection;
connection=DAOConnection.getConnection();
PreparedStatement preparedStatement;
preparedStatement=connection.prepareStatement("select * from item where code=?");
preparedStatement.setInt(1,code);
ResultSet resultSet;
resultSet=preparedStatement.executeQuery();
exists=resultSet.next();
resultSet.close();
preparedStatement.close();
connection.close();
}catch(SQLException sqlException)
{
throw new DAOException("com.thinking.machines.inventory.dl.ItemDAO : public booleancodeExists(int code) : "+sqlException.getMessage());
}
return exists;
}
public boolean nameExists(String name) throws DAOException
{
boolean exists=false;
try
{
Connection connection;
connection=DAOConnection.getConnection();
PreparedStatement preparedStatement;
preparedStatement=connection.prepareStatement("select * from item where name=?");
preparedStatement.setString(1,name);
ResultSet resultSet;
resultSet=preparedStatement.executeQuery();
exists=resultSet.next();
resultSet.close();
preparedStatement.close();
connection.close();
}catch(SQLException sqlException)
{
throw new DAOException("com.thinking.machines.inventory.dl.ItemDAO : public booleannameExists(String name) : "+sqlException.getMessage());
}
return exists;
}
}