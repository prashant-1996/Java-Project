package com.thinking.machines.inventory.pl.model.exceptions;
 public class ModelException extends Exception 
{ 
public ModelException(String message)
 { 
super(message); 
} 
} 