import com.thinking.machines.inventory.pl.ui.*;
class ItemUITestCase
 {
 public static void main(String gg[]) 
{
 ItemFrame itemFrame=new ItemFrame();
}
 }