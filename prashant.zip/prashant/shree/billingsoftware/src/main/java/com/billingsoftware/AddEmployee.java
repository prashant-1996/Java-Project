package com.billingsoftware;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;

public class AddEmployee extends javax.swing.JFrame implements Resources {

    public AddEmployee() {
        initComponents();
        AddEmployee.this.setIconImage(new ImageIcon(getClass().getResource(APPLICATION_ICON)).getImage());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Name = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        MobileNumber = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        Salary = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        Department = new javax.swing.JTextField();
        AddButton = new javax.swing.JButton();
        ResetButton = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        Address = new javax.swing.JTextArea();
        jLabel8 = new javax.swing.JLabel();
        ReturnButton = new javax.swing.JButton();
        Male = new javax.swing.JRadioButton();
        Female = new javax.swing.JRadioButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Add Employee");
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }

            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        Name.setToolTipText("Enter Name");

        jLabel2.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel2.setText("Name");

        jLabel3.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel3.setText("Gender");

        jLabel4.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel4.setText("Address");

        jLabel5.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel5.setText("Mobile Number");

        MobileNumber.setToolTipText("Enter Mobile Number");

        jLabel6.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel6.setText("Department");

        Salary.setToolTipText("Enter Salary");

        jLabel7.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel7.setText("Salary");

        Department.setToolTipText("Enter Department");

        AddButton.setText("Add");
        AddButton.setToolTipText("Click to Add New Employee");
        AddButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        AddButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddButtonActionPerformed(evt);
            }
        });

        ResetButton.setText("Reset");
        ResetButton.setToolTipText("Click to Reset Entries");
        ResetButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ResetButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ResetButtonActionPerformed(evt);
            }
        });

        Address.setColumns(20);
        Address.setLineWrap(true);
        Address.setRows(5);
        Address.setTabSize(2);
        Address.setToolTipText("Enter Address");
        jScrollPane1.setViewportView(Address);

        jLabel8.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel8.setText("Add Employee");

        ReturnButton.setIcon(new javax.swing.ImageIcon(getClass().getResource(BACK_ICON)));
        ReturnButton.setMnemonic('B');
        ReturnButton.setToolTipText(OK_ICON_STRING);
        ReturnButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ReturnButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ReturnButtonActionPerformed(evt);
            }
        });

        Male.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        Male.setText("Male");
        Male.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                MaleItemStateChanged(evt);
            }
        });

        Female.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        Female.setText("Female");
        Female.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                FemaleItemStateChanged(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                        .addComponent(ReturnButton, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(209, 209, 209)
                                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createSequentialGroup()
                                        .addGap(58, 58, 58)
                                        .addComponent(jLabel5)
                                        .addGap(80, 80, 80)
                                        .addComponent(MobileNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createSequentialGroup()
                                        .addGap(58, 58, 58)
                                        .addComponent(jLabel6)
                                        .addGap(102, 102, 102)
                                        .addComponent(Department, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createSequentialGroup()
                                        .addGap(58, 58, 58)
                                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(102, 102, 102)
                                        .addComponent(Salary, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createSequentialGroup()
                                        .addGap(58, 58, 58)
                                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(102, 102, 102)
                                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createSequentialGroup()
                                        .addGap(174, 174, 174)
                                        .addComponent(AddButton)
                                        .addGap(27, 27, 27)
                                        .addComponent(ResetButton))
                                .addGroup(layout.createSequentialGroup()
                                        .addGap(58, 58, 58)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(103, 103, 103)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addGroup(layout.createSequentialGroup()
                                                        .addComponent(Male)
                                                        .addGap(18, 18, 18)
                                                        .addComponent(Female))
                                                .addComponent(Name, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(89, 89, 89))
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                        .addGap(24, 24, 24)
                                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(ReturnButton, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                        .addGap(1, 1, 1)
                                        .addComponent(jLabel2))
                                .addComponent(Name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                        .addGap(18, 18, 18)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                .addComponent(Male)
                                                .addComponent(Female)
                                                .addComponent(jLabel3))
                                        .addGap(52, 52, 52)
                                        .addComponent(jLabel4))
                                .addGroup(layout.createSequentialGroup()
                                        .addGap(58, 58, 58)
                                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(29, 29, 29)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(MobileNumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel5))
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(Department, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel6))
                        .addGap(21, 21, 21)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                        .addGap(1, 1, 1)
                                        .addComponent(jLabel7))
                                .addComponent(Salary, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(AddButton)
                                .addComponent(ResetButton))
                        .addContainerGap(92, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void ResetButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ResetButtonActionPerformed
        Name.setText(null);
        Address.setText(null);
        MobileNumber.setText(null);
        Department.setText(null);
        Salary.setText(null);
        Name.requestFocus();
    }//GEN-LAST:event_ResetButtonActionPerformed

    private void AddButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddButtonActionPerformed
        String name = Name.getText().trim();
        if (name.length() == 0) {
            JOptionPane.showMessageDialog(AddEmployee.this, "Enter Name!!", "Error", 0);
            Name.requestFocus();
            return;
        }
        String gender = "";
        if (Male.isSelected()) {
            gender = "Male";
        } else if (Female.isSelected()) {
            gender = "Female";
        }
        if (gender.trim().isEmpty()) {
            JOptionPane.showMessageDialog(AddEmployee.this, "Enter Gender!!", "Error", 0);
            return;
        }
        String address = Address.getText().trim().toUpperCase();
        if (address.length() == 0) {
            JOptionPane.showMessageDialog(AddEmployee.this, "Enter Address!!", "Error", 0);
            Address.requestFocus();
            return;
        }
        if (MobileNumber.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(AddEmployee.this, "Enter Mobile Number!!", "Error", 0);
            MobileNumber.requestFocus();
            return;
        }
        Long mobileNumber;
        try {
            mobileNumber = Long.parseLong(MobileNumber.getText().trim());
        } catch (NumberFormatException nfe) {
            JOptionPane.showMessageDialog(AddEmployee.this, "Invalid Mobile Number!", "Error", 0);
            MobileNumber.requestFocus();
            return;
        }
        String numberCheck = "([0-9]+[0-9]+[0-9]+[0-9]+[0-9]+[0-9]+[0-9]+[0-9]+[0-9]+[0-9])";
        if (!(MobileNumber.getText().trim().matches(numberCheck))) {
            JOptionPane.showMessageDialog(AddEmployee.this, "Invalid Mobile Number!", "Error", 0);
            MobileNumber.requestFocus();
            return;
        }
        String department = Department.getText().trim().toUpperCase();
        if (department.length() == 0) {
            JOptionPane.showMessageDialog(AddEmployee.this, "Enter Department!!", "Error", 0);
            Department.requestFocus();
            return;
        }
        Double salary = 0.0;
        try {
            salary = Double.parseDouble(Salary.getText().trim());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(AddEmployee.this, "Invalid Salary", "Error", 0);
            Salary.requestFocus();
            return;
        }
        try {
            Connection connection = DAOConnection.getConnection(0);
            PreparedStatement preparedStatement = connection.prepareStatement("select Code from Employee where name = ?  ");
            preparedStatement.setString(1, name);
            ResultSet resultSet;
            resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                resultSet.close();
                preparedStatement.close();
                preparedStatement = connection.prepareStatement("update employee set address=? ,mobile_number =  ?, department = ? ,salary=? where name = ?");
                preparedStatement.setString(1, address);
                preparedStatement.setLong(2, mobileNumber);
                preparedStatement.setString(3, department);
                preparedStatement.setDouble(4, salary);
                preparedStatement.setString(5, name);
                preparedStatement.executeUpdate();
                JOptionPane.showMessageDialog(AddEmployee.this, "Employee Information Updated!!!", "Update Successful", 1);
                preparedStatement.close();
            } else {
                resultSet.close();
                preparedStatement.close();
                preparedStatement = connection.prepareStatement("insert into employee (Name,Gender,Address,Mobile_Number,Department,Salary)values (?,?,?,?,?,?)");
                preparedStatement.setString(1, name);
                preparedStatement.setString(2, gender);
                preparedStatement.setString(3, address);
                preparedStatement.setLong(4, mobileNumber);
                preparedStatement.setString(5, department);
                preparedStatement.setDouble(6, salary);
                preparedStatement.executeUpdate();
                resultSet = preparedStatement.getGeneratedKeys();
                if (resultSet.next()) {
                    Long Code = resultSet.getLong(1);
                    resultSet.close();
                    preparedStatement.close();
                    preparedStatement = connection.prepareStatement("update Employee set code = ? where Name = ?");
                    preparedStatement.setLong(1, Code);
                    preparedStatement.setString(2, name);
                    preparedStatement.executeUpdate();
                    preparedStatement.close();
                }
                resultSet.close();
                JOptionPane.showMessageDialog(AddEmployee.this, "Employee Added!!!", "Update Successful", 1);
                Name.setText(null);
                Address.setText(null);
                MobileNumber.setText(null);
                Male.setSelected(false);
                Female.setSelected(false);
                Department.setText(null);
                Salary.setText(null);
                Name.requestFocus();
            }
            preparedStatement.close();
            connection.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(AddEmployee.this, e.getMessage(), "Error", 0);
        }
    }//GEN-LAST:event_AddButtonActionPerformed

    private void ReturnButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ReturnButtonActionPerformed
        new AdminPanel().setVisible(true);
        AddEmployee.this.dispose();
    }//GEN-LAST:event_ReturnButtonActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        Name.requestFocus();
    }//GEN-LAST:event_formWindowOpened

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        new AdminPanel().setVisible(true);
        AddEmployee.this.dispose();
    }//GEN-LAST:event_formWindowClosing

    private void MaleItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_MaleItemStateChanged
        if (evt.getStateChange() == 1) {
            Female.setSelected(false);
        }
    }//GEN-LAST:event_MaleItemStateChanged

    private void FemaleItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_FemaleItemStateChanged
        if (evt.getStateChange() == 1) {
            Male.setSelected(false);
        }
    }//GEN-LAST:event_FemaleItemStateChanged

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AddEmployee.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AddEmployee.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AddEmployee.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AddEmployee.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AddEmployee().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AddButton;
    private javax.swing.JTextArea Address;
    private javax.swing.JTextField Department;
    private javax.swing.JRadioButton Female;
    private javax.swing.JRadioButton Male;
    private javax.swing.JTextField MobileNumber;
    private javax.swing.JTextField Name;
    private javax.swing.JButton ResetButton;
    private javax.swing.JButton ReturnButton;
    private javax.swing.JTextField Salary;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
