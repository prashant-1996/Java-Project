package com.billingsoftware;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;

public class AddOffers extends javax.swing.JFrame implements Resources {

    public AddOffers() {
        AddOffers.this.setIconImage(new ImageIcon(getClass().getResource(APPLICATION_ICON)).getImage());
        initComponents();

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        AddOffersTabbedPane = new javax.swing.JTabbedPane();
        Freebies = new javax.swing.JPanel();
        RemoveButton1 = new javax.swing.JButton();
        AddButton1 = new javax.swing.JButton();
        Quantity1 = new javax.swing.JTextField();
        Quantity2 = new javax.swing.JTextField();
        jScrollPane11 = new javax.swing.JScrollPane();
        RateTable1 = new javax.swing.JTable();
        jScrollPane12 = new javax.swing.JScrollPane();
        ItemTable1 = new javax.swing.JTable();
        jScrollPane13 = new javax.swing.JScrollPane();
        OfferTable1 = new javax.swing.JTable();
        jScrollPane18 = new javax.swing.JScrollPane();
        ItemTable2 = new javax.swing.JTable();
        ItemName1 = new javax.swing.JTextField();
        ItemName2 = new javax.swing.JTextField();
        OfferName1 = new javax.swing.JTextField();
        Rupees1 = new javax.swing.JTextField();
        Rupees2 = new javax.swing.JTextField();
        Discount2 = new javax.swing.JTextField();
        Discount1 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane14 = new javax.swing.JScrollPane();
        Item1 = new javax.swing.JTable();
        jScrollPane15 = new javax.swing.JScrollPane();
        Item2 = new javax.swing.JTable();
        DiscountOffers = new javax.swing.JPanel();
        RemoveButton2 = new javax.swing.JButton();
        AddButton2 = new javax.swing.JButton();
        Quantity3 = new javax.swing.JTextField();
        Quantity4 = new javax.swing.JTextField();
        SaveButton2 = new javax.swing.JButton();
        jScrollPane17 = new javax.swing.JScrollPane();
        RateTable2 = new javax.swing.JTable();
        jScrollPane20 = new javax.swing.JScrollPane();
        ItemTable3 = new javax.swing.JTable();
        jScrollPane21 = new javax.swing.JScrollPane();
        OfferTable2 = new javax.swing.JTable();
        jScrollPane22 = new javax.swing.JScrollPane();
        ItemTable4 = new javax.swing.JTable();
        ItemName3 = new javax.swing.JTextField();
        ItemName4 = new javax.swing.JTextField();
        OfferName2 = new javax.swing.JTextField();
        Rupees3 = new javax.swing.JTextField();
        Rupees4 = new javax.swing.JTextField();
        Discount4 = new javax.swing.JTextField();
        Discount3 = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        ReturnButton = new javax.swing.JButton();
        message = new javax.swing.JLabel();
        OffersMessage = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Add Offers");
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }

            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        AddOffersTabbedPane.setToolTipText("See Offers");
        AddOffersTabbedPane.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                AddOffersTabbedPaneStateChanged(evt);
            }
        });

        Freebies.setToolTipText("See Freebies Offers");

        RemoveButton1.setText("Remove");
        RemoveButton1.setToolTipText("Click Here To Remove Offer From Offer Table");
        RemoveButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        RemoveButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RemoveButton1ActionPerformed(evt);
            }
        });

        AddButton1.setText("Add");
        AddButton1.setToolTipText("Click Here To Add Items To Offer Table");
        AddButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        AddButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddButton1ActionPerformed(evt);
            }
        });

        Quantity1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                Quantity1KeyReleased(evt);
            }
        });

        Quantity2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                Quantity2KeyReleased(evt);
            }
        });

        RateTable1.setModel(new javax.swing.table.DefaultTableModel(
                new Object[][]{},
                new String[]{
                    "            Rate"
                }
        ) {
            boolean[] canEdit = new boolean[]{
                false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit[columnIndex];
            }
        });
        RateTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                RateTable1MouseClicked(evt);
            }
        });
        jScrollPane11.setViewportView(RateTable1);
        if (RateTable1.getColumnModel().getColumnCount() > 0) {
            RateTable1.getColumnModel().getColumn(0).setResizable(false);
        }

        ItemTable1.setModel(new javax.swing.table.DefaultTableModel(
                new Object[][]{},
                new String[]{
                    "          Items"
                }
        ) {
            boolean[] canEdit = new boolean[]{
                false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit[columnIndex];
            }
        });
        ItemTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ItemTable1MouseClicked(evt);
            }
        });
        jScrollPane12.setViewportView(ItemTable1);
        if (ItemTable1.getColumnModel().getColumnCount() > 0) {
            ItemTable1.getColumnModel().getColumn(0).setResizable(false);
        }

        OfferTable1.setModel(new javax.swing.table.DefaultTableModel(
                new Object[][]{},
                new String[]{
                    "                       Offers"
                }
        ) {
            boolean[] canEdit = new boolean[]{
                false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit[columnIndex];
            }
        });
        OfferTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                OfferTable1MouseClicked(evt);
            }
        });
        jScrollPane13.setViewportView(OfferTable1);
        if (OfferTable1.getColumnModel().getColumnCount() > 0) {
            OfferTable1.getColumnModel().getColumn(0).setResizable(false);
        }

        ItemTable2.setModel(new javax.swing.table.DefaultTableModel(
                new Object[][]{},
                new String[]{
                    "          Items"
                }
        ) {
            boolean[] canEdit = new boolean[]{
                false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit[columnIndex];
            }
        });
        ItemTable2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ItemTable2MouseClicked(evt);
            }
        });
        jScrollPane18.setViewportView(ItemTable2);
        if (ItemTable2.getColumnModel().getColumnCount() > 0) {
            ItemTable2.getColumnModel().getColumn(0).setResizable(false);
        }

        ItemName1.setToolTipText("Enter Item Name To Search");
        ItemName1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                ItemName1KeyReleased(evt);
            }
        });

        ItemName2.setToolTipText("Enter Item Name To Search");
        ItemName2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                ItemName2KeyReleased(evt);
            }
        });

        OfferName1.setToolTipText("Enter Offer Name To Search");
        OfferName1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                OfferName1KeyReleased(evt);
            }
        });

        Rupees1.setEditable(false);

        Rupees2.setEditable(false);

        Discount2.setEditable(false);

        Discount1.setEditable(false);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel1.setText("Quantity");

        jLabel2.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel2.setText("Amount Deduct");

        jLabel3.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel3.setText("Discount");

        Item1.setModel(new javax.swing.table.DefaultTableModel(
                new Object[][]{},
                new String[]{
                    "          Item1"
                }
        ) {
            boolean[] canEdit = new boolean[]{
                false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit[columnIndex];
            }
        });
        Item1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Item1MouseClicked(evt);
            }
        });
        jScrollPane14.setViewportView(Item1);
        if (Item1.getColumnModel().getColumnCount() > 0) {
            Item1.getColumnModel().getColumn(0).setResizable(false);
        }

        Item2.setModel(new javax.swing.table.DefaultTableModel(
                new Object[][]{},
                new String[]{
                    "          Item2"
                }
        ) {
            boolean[] canEdit = new boolean[]{
                false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit[columnIndex];
            }
        });
        Item2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Item2MouseClicked(evt);
            }
        });
        jScrollPane15.setViewportView(Item2);
        if (Item2.getColumnModel().getColumnCount() > 0) {
            Item2.getColumnModel().getColumn(0).setResizable(false);
        }

        javax.swing.GroupLayout FreebiesLayout = new javax.swing.GroupLayout(Freebies);
        Freebies.setLayout(FreebiesLayout);
        FreebiesLayout.setHorizontalGroup(
                FreebiesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(FreebiesLayout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addGroup(FreebiesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel2)
                                .addGroup(FreebiesLayout.createSequentialGroup()
                                        .addComponent(jLabel1)
                                        .addGap(15, 15, 15))
                                .addGroup(FreebiesLayout.createSequentialGroup()
                                        .addComponent(jLabel3)
                                        .addGap(14, 14, 14)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(FreebiesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(Quantity1)
                                .addComponent(jScrollPane12, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                                .addComponent(ItemName1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(Rupees1)
                                .addComponent(Discount1, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(FreebiesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(ItemName2, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jScrollPane18, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(Rupees2)
                                .addComponent(Quantity2)
                                .addComponent(Discount2))
                        .addGap(26, 26, 26)
                        .addGroup(FreebiesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(FreebiesLayout.createSequentialGroup()
                                        .addGroup(FreebiesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(jScrollPane13, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                                                .addComponent(OfferName1, javax.swing.GroupLayout.DEFAULT_SIZE, 214, Short.MAX_VALUE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jScrollPane14, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jScrollPane15, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(FreebiesLayout.createSequentialGroup()
                                        .addGap(38, 38, 38)
                                        .addComponent(AddButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(RemoveButton1)
                                        .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap())
        );

        FreebiesLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[]{Discount1, Discount2, ItemName1, ItemName2, Quantity1, Quantity2, Rupees1, Rupees2, jScrollPane11, jScrollPane12, jScrollPane18});

        FreebiesLayout.setVerticalGroup(
                FreebiesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(FreebiesLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(FreebiesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(FreebiesLayout.createSequentialGroup()
                                        .addComponent(OfferName1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(FreebiesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, 333, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGroup(FreebiesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(jScrollPane13, javax.swing.GroupLayout.PREFERRED_SIZE, 333, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(jScrollPane14, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 334, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(jScrollPane15, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 334, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGap(26, 26, 26)
                                        .addGroup(FreebiesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                .addComponent(AddButton1)
                                                .addComponent(RemoveButton1)))
                                .addGroup(FreebiesLayout.createSequentialGroup()
                                        .addGroup(FreebiesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                .addComponent(ItemName1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(ItemName2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(FreebiesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                .addComponent(jScrollPane18, javax.swing.GroupLayout.PREFERRED_SIZE, 332, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jScrollPane12, javax.swing.GroupLayout.PREFERRED_SIZE, 334, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(FreebiesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                .addComponent(Quantity2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(Quantity1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jLabel1))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(FreebiesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                .addComponent(Rupees1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(Rupees2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jLabel2))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(FreebiesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(Discount2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(Discount1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel3))
                        .addContainerGap())
        );

        AddOffersTabbedPane.addTab("Freebies", Freebies);

        DiscountOffers.setToolTipText("See Discount Offers");

        RemoveButton2.setText("Remove");
        RemoveButton2.setToolTipText("Click Here To Remove Offer From Offer Table");
        RemoveButton2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        RemoveButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RemoveButton2ActionPerformed(evt);
            }
        });

        AddButton2.setText("Add");
        AddButton2.setToolTipText("Click Here To Add Items To Offer Table");
        AddButton2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        AddButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddButton2ActionPerformed(evt);
            }
        });

        Quantity3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                Quantity3KeyReleased(evt);
            }
        });

        Quantity4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                Quantity4KeyReleased(evt);
            }
        });

        SaveButton2.setText("Save");
        SaveButton2.setToolTipText("Click Here To Update Offers");
        SaveButton2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        SaveButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SaveButton2ActionPerformed(evt);
            }
        });

        RateTable2.setModel(new javax.swing.table.DefaultTableModel(
                new Object[][]{},
                new String[]{
                    "            Rate"
                }
        ) {
            boolean[] canEdit = new boolean[]{
                false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit[columnIndex];
            }
        });
        RateTable2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                RateTable2MouseClicked(evt);
            }
        });
        jScrollPane17.setViewportView(RateTable2);
        if (RateTable2.getColumnModel().getColumnCount() > 0) {
            RateTable2.getColumnModel().getColumn(0).setResizable(false);
        }

        ItemTable3.setModel(new javax.swing.table.DefaultTableModel(
                new Object[][]{},
                new String[]{
                    "          Items"
                }
        ) {
            boolean[] canEdit = new boolean[]{
                false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit[columnIndex];
            }
        });
        ItemTable3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ItemTable3MouseClicked(evt);
            }
        });
        jScrollPane20.setViewportView(ItemTable3);
        if (ItemTable3.getColumnModel().getColumnCount() > 0) {
            ItemTable3.getColumnModel().getColumn(0).setResizable(false);
        }

        OfferTable2.setModel(new javax.swing.table.DefaultTableModel(
                new Object[][]{},
                new String[]{
                    "                                          Offers"
                }
        ) {
            boolean[] canEdit = new boolean[]{
                false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit[columnIndex];
            }
        });
        OfferTable2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                OfferTable2MouseClicked(evt);
            }
        });
        jScrollPane21.setViewportView(OfferTable2);
        if (OfferTable2.getColumnModel().getColumnCount() > 0) {
            OfferTable2.getColumnModel().getColumn(0).setResizable(false);
        }

        ItemTable4.setModel(new javax.swing.table.DefaultTableModel(
                new Object[][]{},
                new String[]{
                    "          Items"
                }
        ) {
            boolean[] canEdit = new boolean[]{
                false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit[columnIndex];
            }
        });
        ItemTable4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ItemTable4MouseClicked(evt);
            }
        });
        jScrollPane22.setViewportView(ItemTable4);
        if (ItemTable4.getColumnModel().getColumnCount() > 0) {
            ItemTable4.getColumnModel().getColumn(0).setResizable(false);
        }

        ItemName3.setToolTipText("Enter Item Name To Search");
        ItemName3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                ItemName3KeyReleased(evt);
            }
        });

        ItemName4.setToolTipText("Enter Item Name To Search");
        ItemName4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                ItemName4KeyReleased(evt);
            }
        });

        OfferName2.setToolTipText("Enter Offer Name To Search");
        OfferName2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                OfferName2KeyReleased(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel4.setText("Quantity");

        jLabel5.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel5.setText("Amount Deduct");

        jLabel6.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel6.setText("Discount");

        javax.swing.GroupLayout DiscountOffersLayout = new javax.swing.GroupLayout(DiscountOffers);
        DiscountOffers.setLayout(DiscountOffersLayout);
        DiscountOffersLayout.setHorizontalGroup(
                DiscountOffersLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(DiscountOffersLayout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addGroup(DiscountOffersLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel5)
                                .addGroup(DiscountOffersLayout.createSequentialGroup()
                                        .addComponent(jLabel4)
                                        .addGap(15, 15, 15))
                                .addGroup(DiscountOffersLayout.createSequentialGroup()
                                        .addComponent(jLabel6)
                                        .addGap(14, 14, 14)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(DiscountOffersLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(Quantity3)
                                .addComponent(jScrollPane20, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                                .addComponent(ItemName3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(Rupees3)
                                .addComponent(Discount3, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(DiscountOffersLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(ItemName4, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jScrollPane22, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(Rupees4)
                                .addComponent(Quantity4, javax.swing.GroupLayout.DEFAULT_SIZE, 108, Short.MAX_VALUE)
                                .addComponent(Discount4))
                        .addGap(26, 26, 26)
                        .addGroup(DiscountOffersLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(DiscountOffersLayout.createSequentialGroup()
                                        .addGroup(DiscountOffersLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                .addComponent(jScrollPane21, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                                                .addComponent(OfferName2, javax.swing.GroupLayout.PREFERRED_SIZE, 305, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(18, 18, 18)
                                        .addComponent(jScrollPane17, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(DiscountOffersLayout.createSequentialGroup()
                                        .addGap(38, 38, 38)
                                        .addComponent(AddButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(RemoveButton2)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(SaveButton2)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        DiscountOffersLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[]{Discount4, ItemName3, ItemName4, Quantity4, Rupees4, jScrollPane17, jScrollPane20, jScrollPane22});

        DiscountOffersLayout.setVerticalGroup(
                DiscountOffersLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(DiscountOffersLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(DiscountOffersLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(DiscountOffersLayout.createSequentialGroup()
                                        .addComponent(OfferName2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(DiscountOffersLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addGroup(DiscountOffersLayout.createSequentialGroup()
                                                        .addComponent(jScrollPane21, javax.swing.GroupLayout.PREFERRED_SIZE, 333, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addGap(26, 26, 26)
                                                        .addGroup(DiscountOffersLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                                .addComponent(AddButton2)
                                                                .addComponent(RemoveButton2)
                                                                .addComponent(SaveButton2)))
                                                .addComponent(jScrollPane17, javax.swing.GroupLayout.PREFERRED_SIZE, 333, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGroup(DiscountOffersLayout.createSequentialGroup()
                                        .addGroup(DiscountOffersLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                .addComponent(ItemName3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(ItemName4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(DiscountOffersLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                .addComponent(jScrollPane22, javax.swing.GroupLayout.PREFERRED_SIZE, 332, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jScrollPane20, javax.swing.GroupLayout.PREFERRED_SIZE, 334, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(DiscountOffersLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                .addComponent(Quantity4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(Quantity3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jLabel4))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(DiscountOffersLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                .addComponent(Rupees3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(Rupees4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jLabel5))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(DiscountOffersLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(Discount4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(Discount3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel6))
                        .addContainerGap())
        );

        AddOffersTabbedPane.addTab("Discount Offers", DiscountOffers);

        ReturnButton.setIcon(new javax.swing.ImageIcon(getClass().getResource(BACK_ICON)));
        ReturnButton.setMnemonic('B');
        ReturnButton.setToolTipText(BACK_ICON_STRING);
        ReturnButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ReturnButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ReturnButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                        .addComponent(ReturnButton, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(114, 114, 114)
                                        .addComponent(message, javax.swing.GroupLayout.PREFERRED_SIZE, 383, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(OffersMessage, javax.swing.GroupLayout.PREFERRED_SIZE, 256, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(AddOffersTabbedPane, javax.swing.GroupLayout.PREFERRED_SIZE, 944, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(ReturnButton, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(layout.createSequentialGroup()
                                        .addContainerGap()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(OffersMessage, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(message, javax.swing.GroupLayout.DEFAULT_SIZE, 36, Short.MAX_VALUE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(AddOffersTabbedPane))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void ReturnButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ReturnButtonActionPerformed
        new AdminPanel().setVisible(true);
        AddOffers.this.dispose();
    }//GEN-LAST:event_ReturnButtonActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        RemoveButton1.setEnabled(false);
        OfferName1.setEnabled(false);
        AddButton1.setEnabled(false);
        Quantity1.setEnabled(false);
        Quantity2.setEnabled(false);
        Quantity1.setEnabled(false);
        load();
    }//GEN-LAST:event_formWindowOpened

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        new AdminPanel().setVisible(true);
        AddOffers.this.dispose();
    }//GEN-LAST:event_formWindowClosing

    private void RemoveButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RemoveButton1ActionPerformed
        RemoveButtonActionPerformed(OfferTable1, RateTable1, RemoveButton1);
    }//GEN-LAST:event_RemoveButton1ActionPerformed

    private void AddButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddButton1ActionPerformed
        String quantity1 = Quantity1.getText().trim();
        String quantity2 = Quantity2.getText().trim();
        if (Quantity1.getText().trim().isEmpty()) {
            quantity1 = "1";
        }
        if (Quantity2.getText().trim().isEmpty()) {
            quantity2 = "1";
        }
        String buy = "Buy " + quantity1 + " " + ItemTable1.getValueAt(ItemTable1.getSelectedRow(), ItemTable1.getSelectedColumn()) + " And get " + quantity2 + " " + ItemTable2.getValueAt(ItemTable2.getSelectedRow(), ItemTable2.getSelectedColumn()) + " Free";
        int i = 0;

        while (i < OfferTable1.getRowCount()) {
            if (buy.equalsIgnoreCase((String) OfferTable1.getValueAt(i, 0))) {
                JOptionPane.showMessageDialog(AddOffers.this, "Offer Exists.");
                OfferTable1.setRowSelectionInterval(i, i);
                OfferTable1.scrollRectToVisible(OfferTable1.getCellRect(i, i, false));
                RateTable1.setRowSelectionInterval(i, i);
                RateTable1.scrollRectToVisible(RateTable1.getCellRect(i, i, false));
                Item1.setRowSelectionInterval(i, i);
                Item1.scrollRectToVisible(RateTable1.getCellRect(i, i, false));
                AddButton1.setEnabled(false);
                Item2.setRowSelectionInterval(i, i);
                Item2.scrollRectToVisible(RateTable1.getCellRect(i, i, false));
                return;
            }
            i++;
        }

        try {
            Connection connection = DAOConnection.getConnection(0);
            PreparedStatement preparedStatement = connection.prepareStatement("select Sell_Price from item where description  = ?");
            preparedStatement.setString(1, (String) ItemTable1.getValueAt(ItemTable1.getSelectedRow(), ItemTable1.getSelectedColumn()));
            ResultSet resultSet = preparedStatement.executeQuery();
            resultSet.next();

            float value = resultSet.getFloat(1);
            resultSet.close();
            preparedStatement.close();

            DefaultTableModel rate = (DefaultTableModel) RateTable1.getModel();
            String et = quantity1;
            char temp[] = quantity1.toCharArray();
            quantity1 = "";
            while (i < temp.length) {
                if ((temp[i] >= '0' && temp[i] <= '9') || (temp[i] == '.')) {
                    quantity1 += temp[i];
                }
                i++;
            }

            if (quantity1.trim().isEmpty()) {
                quantity1 = et;
            }
            value *= Float.parseFloat(quantity1);
            Object rowdata[] = {value};
            rate.addRow(rowdata);
            preparedStatement = null;
            preparedStatement = connection.prepareStatement("delete from offers where Offer_Code like 'FREEBIES%'");
            preparedStatement.executeUpdate();
            preparedStatement.close();
            i = 0;
            int j = 1;

            DefaultTableModel dtm = (DefaultTableModel) OfferTable1.getModel();
            Object rowData[] = {buy};
            dtm.addRow(rowData);

            DefaultTableModel dtm1 = (DefaultTableModel) Item1.getModel();
            Object rowData1[] = {ItemTable1.getValueAt(ItemTable1.getSelectedRow(), ItemTable1.getSelectedColumn())};
            dtm1.addRow(rowData1);

            DefaultTableModel dtm2 = (DefaultTableModel) Item2.getModel();
            Object rowData2[] = {ItemTable2.getValueAt(ItemTable2.getSelectedRow(), ItemTable2.getSelectedColumn())};
            dtm2.addRow(rowData2);

            while (i < OfferTable1.getRowCount()) {
                preparedStatement = connection.prepareStatement("insert into offers(Offer_Code,Description,ItemName1,ItemName2,Item1Quantity,Item2Quantity,Rate) values(?,?,?,?,?,?,?)");
                preparedStatement.setString(1, "FREEBIES" + j);
                preparedStatement.setString(2, (String) OfferTable1.getValueAt(i, 0));
                preparedStatement.setString(3, (String) Item1.getValueAt(i, 0));
                preparedStatement.setString(4, (String) Item2.getValueAt(i, 0));
                preparedStatement.setFloat(5, Float.parseFloat(quantity1));
                preparedStatement.setFloat(6, Float.parseFloat(quantity2));
                preparedStatement.setFloat(7, (Float) RateTable1.getValueAt(i, 0));
                preparedStatement.executeUpdate();
                preparedStatement.close();
                i++;
                j++;
            }
            connection.close();
            JOptionPane.showMessageDialog(AddOffers.this, "Offers Saved!!!", "Update Successful", 1);
            OfferName1.setEnabled(true);
            AddButton1.setEnabled(false);
            Quantity1.setEnabled(false);
            Quantity2.setEnabled(false);
            Quantity1.setText(null);
            Quantity2.setText(null);
            ItemTable1.clearSelection();
            ItemTable2.clearSelection();
            Item1.clearSelection();
            Item2.clearSelection();
            ItemName1.setText(null);
            ItemName2.setText(null);
            RateTable1.clearSelection();
            OfferTable1.clearSelection();
            OfferName1.setText(null);
            OffersMessage.setText(null);
        } catch (ClassNotFoundException | SQLException | NumberFormatException ex) {
            JOptionPane.showMessageDialog(AddOffers.this, ex.getMessage(), "Error", 0);
        }
    }//GEN-LAST:event_AddButton1ActionPerformed

    private void Quantity1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Quantity1KeyReleased
        QuantityKeyReleased(Quantity1, Quantity2, ItemTable1, ItemTable2, AddButton1);
    }//GEN-LAST:event_Quantity1KeyReleased

    private void Quantity2KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Quantity2KeyReleased
        QuantityKeyReleased(Quantity1, Quantity2, ItemTable1, ItemTable2, AddButton1);
    }//GEN-LAST:event_Quantity2KeyReleased

    private void RateTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_RateTable1MouseClicked
        RateTableMouseClicked(RateTable1, RemoveButton1);
    }//GEN-LAST:event_RateTable1MouseClicked

    private void ItemTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ItemTable1MouseClicked
        ItemTableMouseClicked(ItemTable1, Quantity1);
    }//GEN-LAST:event_ItemTable1MouseClicked

    private void OfferTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_OfferTable1MouseClicked
        OfferTableMouseClicked(OfferTable1, RemoveButton1);
        int selectedRow = OfferTable1.getSelectedRow();
        if (selectedRow >= 0) {
            OfferTable1.setRowSelectionInterval(selectedRow, selectedRow);
            RateTable1.setRowSelectionInterval(selectedRow, selectedRow);
            Item1.setRowSelectionInterval(selectedRow, selectedRow);
            Item2.setRowSelectionInterval(selectedRow, selectedRow);
            OfferTable1.scrollRectToVisible(OfferTable1.getCellRect(selectedRow, selectedRow, false));
            RateTable1.scrollRectToVisible(RateTable1.getCellRect(selectedRow, selectedRow, false));
            Item1.scrollRectToVisible(Item1.getCellRect(selectedRow, selectedRow, false));
            Item2.scrollRectToVisible(Item2.getCellRect(selectedRow, selectedRow, false));
            RemoveButton1.setEnabled(true);
        } else {
            RemoveButton1.setEnabled(false);
        }
    }//GEN-LAST:event_OfferTable1MouseClicked

    private void ItemTable2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ItemTable2MouseClicked
        ItemTableMouseClicked(ItemTable2, Quantity2);
    }//GEN-LAST:event_ItemTable2MouseClicked

    private void ItemName1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ItemName1KeyReleased
        Quantity1.setText(null);
        ItemNameKeyReleased(ItemTable1, ItemName1);

    }//GEN-LAST:event_ItemName1KeyReleased

    private void ItemName2KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ItemName2KeyReleased
        Quantity2.setText(null);
        ItemNameKeyReleased(ItemTable2, ItemName2);
    }//GEN-LAST:event_ItemName2KeyReleased

    private void OfferName1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_OfferName1KeyReleased
        OfferNameKeyReleased(OfferTable1, OfferName1, RateTable1, Item1, Item2, 1);
    }//GEN-LAST:event_OfferName1KeyReleased

    private void RemoveButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RemoveButton2ActionPerformed
//        RemoveButtonActionPerformed(OfferTable2,RateTable2,RemoveButton2);
        JOptionPane.showMessageDialog(AddOffers.this, "Not Yet Implemented", "Error", 0);
    }//GEN-LAST:event_RemoveButton2ActionPerformed

    private void Quantity3KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Quantity3KeyReleased
        QuantityKeyReleased(Quantity3, Quantity4, ItemTable3, ItemTable4, AddButton2);
    }//GEN-LAST:event_Quantity3KeyReleased

    private void Quantity4KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Quantity4KeyReleased
        QuantityKeyReleased(Quantity3, Quantity4, ItemTable3, ItemTable4, AddButton2);
    }//GEN-LAST:event_Quantity4KeyReleased

    private void RateTable2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_RateTable2MouseClicked
        RateTableMouseClicked(RateTable2, RemoveButton2);
    }//GEN-LAST:event_RateTable2MouseClicked

    private void ItemTable3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ItemTable3MouseClicked
        ItemTableMouseClicked(ItemTable3, Quantity3);
    }//GEN-LAST:event_ItemTable3MouseClicked

    private void OfferTable2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_OfferTable2MouseClicked
        OfferTableMouseClicked(OfferTable2, RemoveButton2);
    }//GEN-LAST:event_OfferTable2MouseClicked

    private void ItemTable4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ItemTable4MouseClicked
        ItemTableMouseClicked(ItemTable4, Quantity4);
    }//GEN-LAST:event_ItemTable4MouseClicked

    private void ItemName3KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ItemName3KeyReleased
        ItemNameKeyReleased(ItemTable3, ItemName3);
    }//GEN-LAST:event_ItemName3KeyReleased

    private void ItemName4KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ItemName4KeyReleased
        ItemNameKeyReleased(ItemTable4, ItemName4);
    }//GEN-LAST:event_ItemName4KeyReleased

    private void OfferName2KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_OfferName2KeyReleased
        OfferNameKeyReleased(OfferTable2, OfferName2, RateTable2, Item1, Item2, 2);
    }//GEN-LAST:event_OfferName2KeyReleased

    private void AddOffersTabbedPaneStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_AddOffersTabbedPaneStateChanged
        if (AddOffersTabbedPane.getSelectedIndex() == 1) {
            JOptionPane.showMessageDialog(AddOffers.this, "Not Yet Implemented", "Error", 0);
        }
    }//GEN-LAST:event_AddOffersTabbedPaneStateChanged

    private void AddButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddButton2ActionPerformed
        JOptionPane.showMessageDialog(AddOffers.this, "Not Yet Implemented", "Error", 0);
        /*
         String quantity3 = Quantity3.getText().trim();
         String quantity2 = Quantity2.getText().trim();
         int row=ItemTable2.getSelectedRow();
         int col=ItemTable2.getSelectedColumn();
         String buy = "Buy "+quantity3+" " +ItemTable1.getValueAt(ItemTable1.getSelectedRow(),ItemTable1.getSelectedColumn());
         if(row==-1)
         {
        
         }
         String amtDeduct="";
         if(Rupees3.getText().trim().isEmpty()==false)
         amtDeduct=" And get Rs."+Rupees3.getText()+" Off";
        
         DefaultTableModel dtm = (DefaultTableModel)OfferTable1.getModel();
         Object rowData[] = {buy}        ;
         dtm.addRow(rowData);
         try
         {
         Connection connection = DAOConnection.getConnection(0);
         PreparedStatement preparedStatement = connection.prepareStatement("select Sell_Price from item where description  = ?");
         preparedStatement.setString(1,(String)ItemTable1.getValueAt(ItemTable1.getSelectedRow(),ItemTable1.getSelectedColumn()));
         ResultSet resultSet = preparedStatement.executeQuery();
         resultSet.next();
         float value = resultSet.getFloat(1);
         resultSet.close();
         preparedStatement.close();
         connection.close();
         DefaultTableModel rate = (DefaultTableModel) RateTable1.getModel();
         char temp[] = quantity3.toCharArray();
         int i = 0;
         quantity3 = "";
         while(i<temp.length)
         {
         if(temp[i]>= '0' && temp[i]<= '9')
         {
         quantity3+= temp[i];
         }
         i++;
         }
         value*= Float.parseFloat(quantity3);
         Object rowdata[] = {value};
         rate.addRow(rowdata);
         AddButton1.setEnabled(false);
         Quantity1.setEnabled(false);
         Quantity2.setEnabled(false);
         Quantity1.setText(null);
         Quantity2.setText(null);
         ItemTable1.clearSelection();
         Item1.clearSelection();
         Item2.clearSelection();
         ItemTable2.clearSelection();
         ItemName1.setText(null);
         ItemName2.setText(null);
         RateTable1.clearSelection();
         OfferTable1.clearSelection();
         }catch (ClassNotFoundException | SQLException ex ) {
         JOptionPane.showMessageDialog(AddOffers.this,ex.getMessage(),"Error",0);
         }*/
    }//GEN-LAST:event_AddButton2ActionPerformed

    private void Item1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Item1MouseClicked
        int selectedRow = Item1.getSelectedRow();
        if (selectedRow < 0) {
            return;
        }
        OfferTable1.setRowSelectionInterval(selectedRow, selectedRow);
        RateTable1.setRowSelectionInterval(selectedRow, selectedRow);
        Item1.setRowSelectionInterval(selectedRow, selectedRow);
        Item2.setRowSelectionInterval(selectedRow, selectedRow);
        OfferTable1.scrollRectToVisible(OfferTable1.getCellRect(selectedRow, selectedRow, false));
        RateTable1.scrollRectToVisible(RateTable1.getCellRect(selectedRow, selectedRow, false));
        Item1.scrollRectToVisible(Item1.getCellRect(selectedRow, selectedRow, false));
        Item2.scrollRectToVisible(Item2.getCellRect(selectedRow, selectedRow, false));
    }//GEN-LAST:event_Item1MouseClicked

    private void Item2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Item2MouseClicked
        int selectedRow = Item2.getSelectedRow();
        if (selectedRow < 0) {
            return;
        }
        OfferTable1.setRowSelectionInterval(selectedRow, selectedRow);
        RateTable1.setRowSelectionInterval(selectedRow, selectedRow);
        Item1.setRowSelectionInterval(selectedRow, selectedRow);
        Item2.setRowSelectionInterval(selectedRow, selectedRow);
        OfferTable1.scrollRectToVisible(OfferTable1.getCellRect(selectedRow, selectedRow, false));
        RateTable1.scrollRectToVisible(RateTable1.getCellRect(selectedRow, selectedRow, false));
        Item1.scrollRectToVisible(Item1.getCellRect(selectedRow, selectedRow, false));
        Item2.scrollRectToVisible(Item2.getCellRect(selectedRow, selectedRow, false));
    }//GEN-LAST:event_Item2MouseClicked

    private void SaveButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SaveButton2ActionPerformed
        JOptionPane.showMessageDialog(AddOffers.this, "Not Yet Implemented", "Error", 0);
    }//GEN-LAST:event_SaveButton2ActionPerformed

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AddOffers.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AddOffers.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AddOffers.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AddOffers.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AddOffers().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AddButton1;
    private javax.swing.JButton AddButton2;
    private javax.swing.JTabbedPane AddOffersTabbedPane;
    private javax.swing.JTextField Discount1;
    private javax.swing.JTextField Discount2;
    private javax.swing.JTextField Discount3;
    private javax.swing.JTextField Discount4;
    private javax.swing.JPanel DiscountOffers;
    private javax.swing.JPanel Freebies;
    private javax.swing.JTable Item1;
    private javax.swing.JTable Item2;
    private javax.swing.JTextField ItemName1;
    private javax.swing.JTextField ItemName2;
    private javax.swing.JTextField ItemName3;
    private javax.swing.JTextField ItemName4;
    private javax.swing.JTable ItemTable1;
    private javax.swing.JTable ItemTable2;
    private javax.swing.JTable ItemTable3;
    private javax.swing.JTable ItemTable4;
    private javax.swing.JTextField OfferName1;
    private javax.swing.JTextField OfferName2;
    private javax.swing.JTable OfferTable1;
    private javax.swing.JTable OfferTable2;
    private javax.swing.JLabel OffersMessage;
    private javax.swing.JTextField Quantity1;
    private javax.swing.JTextField Quantity2;
    private javax.swing.JTextField Quantity3;
    private javax.swing.JTextField Quantity4;
    private javax.swing.JTable RateTable1;
    private javax.swing.JTable RateTable2;
    private javax.swing.JButton RemoveButton1;
    private javax.swing.JButton RemoveButton2;
    private javax.swing.JButton ReturnButton;
    private javax.swing.JTextField Rupees1;
    private javax.swing.JTextField Rupees2;
    private javax.swing.JTextField Rupees3;
    private javax.swing.JTextField Rupees4;
    private javax.swing.JButton SaveButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JScrollPane jScrollPane12;
    private javax.swing.JScrollPane jScrollPane13;
    private javax.swing.JScrollPane jScrollPane14;
    private javax.swing.JScrollPane jScrollPane15;
    private javax.swing.JScrollPane jScrollPane17;
    private javax.swing.JScrollPane jScrollPane18;
    private javax.swing.JScrollPane jScrollPane20;
    private javax.swing.JScrollPane jScrollPane21;
    private javax.swing.JScrollPane jScrollPane22;
    private javax.swing.JLabel message;

    // End of variables declaration//GEN-END:variables

    private void load() {
        Long countItems;
        try {
            Connection connection = DAOConnection.getConnection(0);
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("select count(*) from item");
            resultSet.next();
            if (resultSet.getLong(1) <= 0) {
                resultSet.close();
                statement.close();
                connection.close();
                message.setText("No Items!!!");
                JOptionPane.showMessageDialog(AddOffers.this, "No Items!!!", "No Items!!!", -1);
                return;
            }
            countItems = resultSet.getLong(1);
            message.setText("Total Items :" + countItems);
            resultSet.close();
            resultSet = statement.executeQuery("select description from item order by description");
            DefaultTableModel dtm1 = (DefaultTableModel) ItemTable1.getModel();
            DefaultTableModel dtm2 = (DefaultTableModel) ItemTable2.getModel();
            DefaultTableModel dtm3 = (DefaultTableModel) ItemTable3.getModel();
            DefaultTableModel dtm4 = (DefaultTableModel) ItemTable4.getModel();
            while (resultSet.next()) {
                String desc = resultSet.getString("description");
                Object rowData[] = {desc};
                dtm1.addRow(rowData);
                dtm2.addRow(rowData);
                dtm3.addRow(rowData);
                dtm4.addRow(rowData);
            }
            resultSet = statement.executeQuery("select description,ItemName1,ItemName2 from offers where Offer_Code like 'FREEBIES%' order by ItemName1 ");
            DefaultTableModel de = (DefaultTableModel) OfferTable1.getModel();
            DefaultTableModel deq = (DefaultTableModel) Item1.getModel();
            DefaultTableModel dew = (DefaultTableModel) Item2.getModel();
            while (resultSet.next()) {

                Object rowData[] = {resultSet.getString("description")};
                de.addRow(rowData);
                Object rowData1[] = {resultSet.getString("ItemName1")};
                deq.addRow(rowData1);
                Object rowData2[] = {resultSet.getString("ItemName2")};
                dew.addRow(rowData2);
            }
            resultSet.close();
            resultSet = statement.executeQuery("select rate from offers where Offer_Code like 'FREEBIES%' order by ItemName1");
            DefaultTableModel rate = (DefaultTableModel) RateTable1.getModel();
            while (resultSet.next()) {
                Float r = resultSet.getFloat("rate");
                Object rowData[] = {r};
                rate.addRow(rowData);
            }
            OfferName1.setEnabled(true);

            resultSet = statement.executeQuery("select description from offers where Offer_Code like 'OFFER%' order by ItemName1");
            DefaultTableModel de2 = (DefaultTableModel) OfferTable2.getModel();
            while (resultSet.next()) {
                String desc = resultSet.getString("description");
                Object rowData[] = {desc};
                de2.addRow(rowData);
            }
            resultSet.close();
            resultSet = statement.executeQuery("select rate from offers where Offer_Code like 'OFFER%' order by ItemName1");
            DefaultTableModel rate2 = (DefaultTableModel) RateTable2.getModel();
            while (resultSet.next()) {
                Float r = resultSet.getFloat("rate");
                Object rowData[] = {r};
                rate2.addRow(rowData);
            }

            resultSet.close();
            statement.close();
            connection.close();
        } catch (ClassNotFoundException | SQLException ex) {
            JOptionPane.showMessageDialog(AddOffers.this, ex.getMessage(), "Error", 0);
        }
    }

    private void ItemTableMouseClicked(javax.swing.JTable ItemTable, javax.swing.JTextField Quantity) {
        int selectedRow = ItemTable.getSelectedRow();
        if (selectedRow >= 0) {
            Quantity.setEnabled(true);
            Quantity.requestFocus();
        } else {
            Quantity.setEnabled(false);
        }
        Quantity.setText(null);
    }

    private void OfferNameKeyReleased(javax.swing.JTable OfferTable, javax.swing.JTextField OfferName, javax.swing.JTable RateTable, javax.swing.JTable Item1, javax.swing.JTable Item2, int yy) {
        int i = 0;
        String offerName = (OfferName.getText().trim());
        if (offerName.length() == 0) {
            return;
        }
        if (yy != 2) {
            int y = 0;
            int l = 0;
            int a, b;
            while (i < OfferTable.getRowCount()) {
                String desc = (String) OfferTable.getValueAt(i, 0);
                if (offerName.length() <= desc.length()) {
                    l = offerName.length();
                    y = 0;
                    while (y < l) {
                        a = offerName.charAt(y);
                        if (a >= 97 && a <= 122) {
                            a = a - 32;
                        }
                        b = desc.charAt(y);
                        if (b >= 97 && b <= 122) {
                            b = b - 32;
                        }
                        if (a != b) {
                            break;
                        }
                        y++;
                    }
                    if (y == l) {
                        OfferTable.setRowSelectionInterval(i, i);
                        OfferTable.scrollRectToVisible(OfferTable.getCellRect(i, i, false));
                        RateTable.setRowSelectionInterval(i, i);
                        RateTable.scrollRectToVisible(RateTable.getCellRect(i, i, false));
                        Item1.setRowSelectionInterval(i, i);
                        Item1.scrollRectToVisible(Item1.getCellRect(i, i, false));
                        Item2.setRowSelectionInterval(i, i);
                        Item2.scrollRectToVisible(Item2.getCellRect(i, i, false));

                        break;
                    }
                }
                i++;
            }
            if (i == OfferTable.getRowCount()) {
                OfferTable.clearSelection();
                RateTable.clearSelection();
                Item1.clearSelection();
                Item2.clearSelection();
            }
        }
    }

    private void ItemNameKeyReleased(javax.swing.JTable ItemTable, javax.swing.JTextField ItemName) {
        int i = 0;
        String itemName = (ItemName.getText().trim());
        if (itemName.length() == 0) {
            return;
        }
        int y = 0;
        int l = 0;
        int a, b;
        while (i < ItemTable.getRowCount()) {
            String desc = (String) ItemTable.getValueAt(i, 0);
            if (itemName.length() <= desc.length()) {
                l = itemName.length();
                y = 0;
                while (y < l) {
                    a = itemName.charAt(y);
                    if (a >= 97 && a <= 122) {
                        a = a - 32;
                    }
                    b = desc.charAt(y);
                    if (b >= 97 && b <= 122) {
                        b = b - 32;
                    }
                    if (a != b) {
                        break;
                    }
                    y++;
                }
                if (y == l) {
                    ItemTable.setRowSelectionInterval(i, i);
                    ItemTable.scrollRectToVisible(ItemTable.getCellRect(i, i, false));
                    message.setText(null);

                    break;
                }
            }
            i++;
        }
        if (i == ItemTable.getRowCount()) {
            ItemTable.clearSelection();
        }
    }

    private void OfferTableMouseClicked(javax.swing.JTable OfferTable, javax.swing.JButton RemoveButton) {
        int selectedRow = OfferTable.getSelectedRow();
        if (selectedRow >= 0) {
            RemoveButton.setEnabled(true);
        } else {
            RemoveButton.setEnabled(false);
        }
    }

    private void RemoveButtonActionPerformed(javax.swing.JTable OfferTable, javax.swing.JTable RateTable, javax.swing.JButton RemoveButton) {
        int selectedRow = OfferTable.getSelectedRow();
        if (selectedRow < 0) {
            selectedRow = RateTable.getSelectedRow();
        }
        if (selectedRow >= 0) {
            try {
                Connection connection = DAOConnection.getConnection(0);
                PreparedStatement preparedStatement = connection.prepareStatement("delete from offers where description=?");
                preparedStatement.setString(1, (String) OfferTable.getValueAt(selectedRow, 0));
                preparedStatement.executeUpdate();
                preparedStatement.close();
                connection.close();

            } catch (Exception e) {
                JOptionPane.showMessageDialog(AddOffers.this, e.getMessage(), "Error", 0);
            }
            DefaultTableModel dtm = (DefaultTableModel) OfferTable.getModel();
            dtm.removeRow(selectedRow);
            DefaultTableModel dtm1 = (DefaultTableModel) RateTable.getModel();
            dtm1.removeRow(selectedRow);
            DefaultTableModel dtm12 = (DefaultTableModel) Item1.getModel();
            dtm12.removeRow(selectedRow);
            DefaultTableModel dtm13 = (DefaultTableModel) Item2.getModel();
            dtm13.removeRow(selectedRow);
            JOptionPane.showMessageDialog(AddOffers.this, "Removed Saved", "Removed Offer", 1);
        }
        RemoveButton.setEnabled(false);
        if (OfferTable.getRowCount() < 0) {
            OfferName1.setEnabled(false);
        }
    }

    private void QuantityKeyReleased(javax.swing.JTextField Quantityx, javax.swing.JTextField Quantityy, javax.swing.JTable ItemTablex, javax.swing.JTable ItemTabley, javax.swing.JButton AddButton) {
        if (Quantityx.getText().trim().isEmpty() == false && Quantityy.getText().trim().isEmpty() == false) {
            int selectedRow = ItemTablex.getSelectedRow();
            if (selectedRow < 0) {
                return;
            }
            selectedRow = ItemTabley.getSelectedRow();
            if (selectedRow < 0) {
                return;
            }
            AddButton.setEnabled(true);
        } else {
            AddButton.setEnabled(false);
        }
    }

    private void RateTableMouseClicked(javax.swing.JTable RateTable, javax.swing.JButton RemoveButton) {
        int selectedRow = RateTable.getSelectedRow();
        if (selectedRow >= 0) {
            OfferTable1.setRowSelectionInterval(selectedRow, selectedRow);
            OfferTable1.scrollRectToVisible(OfferTable1.getCellRect(selectedRow, selectedRow, false));
            RateTable.setRowSelectionInterval(selectedRow, selectedRow);
            RateTable.scrollRectToVisible(RateTable.getCellRect(selectedRow, selectedRow, false));
            Item1.setRowSelectionInterval(selectedRow, selectedRow);
            Item1.scrollRectToVisible(Item1.getCellRect(selectedRow, selectedRow, false));
            Item2.setRowSelectionInterval(selectedRow, selectedRow);
            Item2.scrollRectToVisible(Item2.getCellRect(selectedRow, selectedRow, false));
            RemoveButton.setEnabled(true);
        } else {
            RemoveButton.setEnabled(false);
        }
    }
}
