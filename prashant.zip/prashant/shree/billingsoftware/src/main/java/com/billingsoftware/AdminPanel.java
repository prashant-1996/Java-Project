package com.billingsoftware;

import java.awt.Dimension;
import javax.swing.ImageIcon;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.io.IOException;
import static java.lang.Runtime.getRuntime;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;

public class AdminPanel extends javax.swing.JFrame implements Resources {

    static String username;
    public static int open = 0;

    public AdminPanel() {
        initComponents();
        open++;
        AdminPanel.this.setIconImage(new ImageIcon(getClass().getResource(APPLICATION_ICON)).getImage());

    }

    public AdminPanel(String username) {
        AdminPanel.this.setIconImage(new ImageIcon(getClass().getResource(APPLICATION_ICON)).getImage());
        this.username = username;
        initComponents();
        open++;
    }

    public static void Backup(String username, String password) {
        Properties props = new Properties();
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.socketFactory.port", "465");
        props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.port", "465");

        Session session = Session.getDefaultInstance(props, new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
        });

        //2) compose message   
        try {
            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(username));
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(username));
            message.setSubject("Database Backup");

            //3) create MimeBodyPart object and set your message content    
            BodyPart messageBodyPart1 = new MimeBodyPart();
            messageBodyPart1.setText("Database Backup");

            //4) create new MimeBodyPart object and set DataHandler object to this object    
            MimeBodyPart messageBodyPart2 = new MimeBodyPart();

            String filename = (System.getenv("HOMEDRIVE") + "/Database/info.db");//change accordingly
            FileDataSource source = new FileDataSource(filename);
            messageBodyPart2.setDataHandler(new DataHandler(source));
            messageBodyPart2.setFileName(filename);

            //5) create Multipart object and add MimeBodyPart objects to this object    
            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(messageBodyPart1);
            multipart.addBodyPart(messageBodyPart2);

            //6) set the multiplart object to the message object
            message.setContent(multipart);

            //7) send message
            Transport.send(message);

            JOptionPane.showMessageDialog(null, "Backup Successful", "Backup Successful", 1);
        } catch (MessagingException ex) {
            Toolkit.getDefaultToolkit().beep();
            JOptionPane.showMessageDialog(null, "Backup Failed", "Backup Failed", 0);

        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        jOptionPane1 = new javax.swing.JOptionPane();
        mailDialog = new javax.swing.JDialog();
        jLabel2 = new javax.swing.JLabel();
        UsernameCaption = new javax.swing.JLabel();
        SendButton = new javax.swing.JButton();
        Password = new javax.swing.JPasswordField();
        Username = new javax.swing.JTextField();
        PasswordCaption = new javax.swing.JLabel();
        ResetButton = new javax.swing.JButton();
        CancelButton = new javax.swing.JButton();
        ChangePasswordDialog = new javax.swing.JDialog();
        newPasswordCaption = new javax.swing.JLabel();
        confirmNewPasswordCaption = new javax.swing.JLabel();
        ConfirmNewPassword = new javax.swing.JPasswordField();
        ResetButton1 = new javax.swing.JButton();
        Change = new javax.swing.JButton();
        ReturnChangePassword = new javax.swing.JButton();
        message = new javax.swing.JLabel();
        usernameCaption = new javax.swing.JLabel();
        Username1 = new javax.swing.JTextField();
        oldPasswordCaption = new javax.swing.JLabel();
        OldPassword = new javax.swing.JPasswordField();
        NewPassword = new javax.swing.JPasswordField();
        TimeCaption = new javax.swing.JLabel();
        DayCaption = new javax.swing.JLabel();
        Lock = new javax.swing.JButton();
        WelcomeFrameMenuBar = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();
        PurchaseMenu = new javax.swing.JMenu();
        PurchaseNewItemMenuItem = new javax.swing.JMenuItem();
        SalesMenu = new javax.swing.JMenu();
        ViewBillsMenuItem = new javax.swing.JMenuItem();
        EmployeesMenu = new javax.swing.JMenu();
        AddEmployeeMenuItem = new javax.swing.JMenuItem();
        ViewEmployeesMenuItem = new javax.swing.JMenuItem();
        CustomersMenu = new javax.swing.JMenu();
        ViewAllCustomersMenuItem = new javax.swing.JMenuItem();
        OwnerMenu = new javax.swing.JMenu();
        ChangePasswordMenuItem = new javax.swing.JMenuItem();
        LoggingInformationMenuItem = new javax.swing.JMenuItem();
        UpdateDatabaseMenuItem = new javax.swing.JMenuItem();
        DeleteInformationMenu = new javax.swing.JMenu();
        DeleteAllAboutEmployeesMenuItem = new javax.swing.JMenuItem();
        DeleteAllAboutItemsMenuItem = new javax.swing.JMenuItem();
        DeleteAllAboutCustomersMenuItem = new javax.swing.JMenuItem();
        DeleteDatabaseMenuItem = new javax.swing.JMenuItem();
        TakeBackupToMailMenuItem = new javax.swing.JMenuItem();
        StoresMenu = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        OffersMenu = new javax.swing.JMenu();
        AddOfferMenuItem = new javax.swing.JMenuItem();
        ViewOffersMenuItem = new javax.swing.JMenuItem();

        mailDialog.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        mailDialog.setTitle("Send Backup To Mail");
        mailDialog.setAutoRequestFocus(false);
        mailDialog.setIconImage(null);
        mailDialog.setMinimumSize(new java.awt.Dimension(357, 249));
        mailDialog.setResizable(false);
        mailDialog.getContentPane().setLayout(new java.awt.GridBagLayout());
        mailDialog.getContentPane().add(jLabel2, new java.awt.GridBagConstraints());

        UsernameCaption.setText("Enter Username");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(26, 19, 0, 0);
        mailDialog.getContentPane().add(UsernameCaption, gridBagConstraints);

        SendButton.setText("Send");
        SendButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        SendButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SendButtonActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(18, 81, 25, 0);
        mailDialog.getContentPane().add(SendButton, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.gridheight = 2;
        gridBagConstraints.ipadx = 115;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(6, 51, 0, 25);
        mailDialog.getContentPane().add(Password, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.gridheight = 2;
        gridBagConstraints.ipadx = 115;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(23, 51, 0, 25);
        mailDialog.getContentPane().add(Username, gridBagConstraints);

        PasswordCaption.setText("Enter Password");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(6, 19, 0, 0);
        mailDialog.getContentPane().add(PasswordCaption, gridBagConstraints);

        ResetButton.setText("Reset");
        ResetButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ResetButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ResetButtonActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(18, 18, 25, 0);
        mailDialog.getContentPane().add(ResetButton, gridBagConstraints);

        CancelButton.setText("Cancel");
        CancelButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        CancelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelButtonActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(18, 18, 25, 0);
        mailDialog.getContentPane().add(CancelButton, gridBagConstraints);

        ChangePasswordDialog.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        ChangePasswordDialog.setTitle("Change Password");
        ChangePasswordDialog.setAutoRequestFocus(false);
        ChangePasswordDialog.setIconImage(null);
        ChangePasswordDialog.setMinimumSize(new java.awt.Dimension(400, 331));
        ChangePasswordDialog.setResizable(false);

        newPasswordCaption.setText("New Password");

        confirmNewPasswordCaption.setText("Confirm New Password");

        ResetButton1.setText("Reset");
        ResetButton1.setToolTipText("Click Here To Reset Fields");
        ResetButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ResetButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ResetButton1ActionPerformed(evt);
            }
        });

        Change.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        Change.setIcon(new javax.swing.ImageIcon(getClass().getResource(OK_ICON)));
        Change.setToolTipText("Click Here To Change Password");
        Change.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Change.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ChangeActionPerformed(evt);
            }
        });

        ReturnChangePassword.setIcon(new javax.swing.ImageIcon(getClass().getResource(BACK_ICON)));
        ReturnChangePassword.setToolTipText(BACK_ICON_STRING);
        ReturnChangePassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ReturnChangePasswordActionPerformed(evt);
            }
        });

        message.setForeground(java.awt.Color.blue);
        message.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        usernameCaption.setText("Username");

        oldPasswordCaption.setText("Old Password");

        javax.swing.GroupLayout ChangePasswordDialogLayout = new javax.swing.GroupLayout(ChangePasswordDialog.getContentPane());
        ChangePasswordDialog.getContentPane().setLayout(ChangePasswordDialogLayout);
        ChangePasswordDialogLayout.setHorizontalGroup(
            ChangePasswordDialogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ChangePasswordDialogLayout.createSequentialGroup()
                .addGroup(ChangePasswordDialogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(ChangePasswordDialogLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(message, javax.swing.GroupLayout.PREFERRED_SIZE, 313, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, ChangePasswordDialogLayout.createSequentialGroup()
                        .addGap(39, 39, 39)
                        .addGroup(ChangePasswordDialogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(usernameCaption, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(confirmNewPasswordCaption)
                            .addComponent(newPasswordCaption, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(oldPasswordCaption, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(ChangePasswordDialogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(OldPassword)
                            .addComponent(NewPassword)
                            .addComponent(ConfirmNewPassword)
                            .addComponent(Username1, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(48, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ChangePasswordDialogLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(Change, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ResetButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(ReturnChangePassword, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(61, 61, 61))
        );
        ChangePasswordDialogLayout.setVerticalGroup(
            ChangePasswordDialogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ChangePasswordDialogLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(ChangePasswordDialogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(usernameCaption, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Username1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(ChangePasswordDialogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(oldPasswordCaption, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(OldPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(19, 19, 19)
                .addGroup(ChangePasswordDialogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(newPasswordCaption, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(NewPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(19, 19, 19)
                .addGroup(ChangePasswordDialogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(confirmNewPasswordCaption, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ConfirmNewPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addComponent(message, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(ChangePasswordDialogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(ReturnChangePassword, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Change, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ResetButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33))
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Admin Zone");
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        Lock.setBackground(new java.awt.Color(0, 0, 0));
        Lock.setIcon(new javax.swing.ImageIcon(getClass().getResource(LOCK_ICON)));
        Lock.setMnemonic('L');
        Lock.setToolTipText(LOCK_ICON_STRING);
        Lock.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Lock.setBorderPainted(false);
        Lock.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Lock.setDoubleBuffered(true);
        Lock.setRolloverEnabled(false);
        Lock.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LockActionPerformed(evt);
            }
        });

        WelcomeFrameMenuBar.setAlignmentY(0.5F);

        jMenu1.setMnemonic('k');
        jMenu1.setText("Stocks");
        jMenu1.setToolTipText("See Stocks Left");

        jMenuItem2.setMnemonic('K');
        jMenuItem2.setText("View Stocks");
        jMenuItem2.setToolTipText("Click Here To View Stocks Information");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem2);

        jMenuItem3.setText("Stock Division");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem3);

        WelcomeFrameMenuBar.add(jMenu1);

        PurchaseMenu.setMnemonic('P');
        PurchaseMenu.setText("Purchase");
        PurchaseMenu.setToolTipText("Go For Purchase");

        PurchaseNewItemMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_N, java.awt.event.InputEvent.CTRL_MASK));
        PurchaseNewItemMenuItem.setMnemonic('P');
        PurchaseNewItemMenuItem.setText("Purchase Information");
        PurchaseNewItemMenuItem.setToolTipText("Click Here To View Purchase Information");
        PurchaseNewItemMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PurchaseNewItemMenuItemActionPerformed(evt);
            }
        });
        PurchaseMenu.add(PurchaseNewItemMenuItem);

        WelcomeFrameMenuBar.add(PurchaseMenu);

        SalesMenu.setMnemonic('S');
        SalesMenu.setText("Sales");
        SalesMenu.setToolTipText("Go For Sales");

        ViewBillsMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_B, java.awt.event.InputEvent.CTRL_MASK));
        ViewBillsMenuItem.setMnemonic('B');
        ViewBillsMenuItem.setText("View Bills");
        ViewBillsMenuItem.setToolTipText("Click Here To View Bills");
        ViewBillsMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ViewBillsMenuItemActionPerformed(evt);
            }
        });
        SalesMenu.add(ViewBillsMenuItem);

        WelcomeFrameMenuBar.add(SalesMenu);

        EmployeesMenu.setMnemonic('E');
        EmployeesMenu.setText("Employees");
        EmployeesMenu.setToolTipText("Go For Employees");

        AddEmployeeMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_A, java.awt.event.InputEvent.ALT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        AddEmployeeMenuItem.setMnemonic('A');
        AddEmployeeMenuItem.setText("Add Employee");
        AddEmployeeMenuItem.setToolTipText("Click Here To Add Employee");
        AddEmployeeMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddEmployeeMenuItemActionPerformed(evt);
            }
        });
        EmployeesMenu.add(AddEmployeeMenuItem);

        ViewEmployeesMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_E, java.awt.event.InputEvent.ALT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        ViewEmployeesMenuItem.setText("View Employees");
        ViewEmployeesMenuItem.setToolTipText("Click Here To View Employees");
        ViewEmployeesMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ViewEmployeesMenuItemActionPerformed(evt);
            }
        });
        EmployeesMenu.add(ViewEmployeesMenuItem);

        WelcomeFrameMenuBar.add(EmployeesMenu);

        CustomersMenu.setMnemonic('C');
        CustomersMenu.setText("Customers");
        CustomersMenu.setToolTipText("Go For Customers");

        ViewAllCustomersMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, java.awt.event.InputEvent.CTRL_MASK));
        ViewAllCustomersMenuItem.setMnemonic('V');
        ViewAllCustomersMenuItem.setText("View All Customers");
        ViewAllCustomersMenuItem.setToolTipText("Click Here To View All Customers");
        ViewAllCustomersMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ViewAllCustomersMenuItemActionPerformed(evt);
            }
        });
        CustomersMenu.add(ViewAllCustomersMenuItem);

        WelcomeFrameMenuBar.add(CustomersMenu);

        OwnerMenu.setMnemonic('O');
        OwnerMenu.setText("Owner");
        OwnerMenu.setToolTipText("Go To Settings");

        ChangePasswordMenuItem.setMnemonic('P');
        ChangePasswordMenuItem.setText("Change Password");
        ChangePasswordMenuItem.setToolTipText("Click To Change Password");
        ChangePasswordMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ChangePasswordMenuItemActionPerformed(evt);
            }
        });
        OwnerMenu.add(ChangePasswordMenuItem);

        LoggingInformationMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_L, java.awt.event.InputEvent.CTRL_MASK));
        LoggingInformationMenuItem.setText("Logging Information");
        LoggingInformationMenuItem.setToolTipText("Click Here To See Logger");
        LoggingInformationMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LoggingInformationMenuItemActionPerformed(evt);
            }
        });
        OwnerMenu.add(LoggingInformationMenuItem);

        UpdateDatabaseMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_U, java.awt.event.InputEvent.CTRL_MASK));
        UpdateDatabaseMenuItem.setText("Update Database");
        UpdateDatabaseMenuItem.setToolTipText("Click Here To Update Database");
        UpdateDatabaseMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdateDatabaseMenuItemActionPerformed(evt);
            }
        });
        OwnerMenu.add(UpdateDatabaseMenuItem);

        DeleteInformationMenu.setText("Delete Information");
        DeleteInformationMenu.setToolTipText("Go For Deletion");

        DeleteAllAboutEmployeesMenuItem.setText("Delete All About Employees");
        DeleteAllAboutEmployeesMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteAllAboutEmployeesMenuItemActionPerformed(evt);
            }
        });
        DeleteInformationMenu.add(DeleteAllAboutEmployeesMenuItem);

        DeleteAllAboutItemsMenuItem.setText("Delete All About Items");
        DeleteAllAboutItemsMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteAllAboutItemsMenuItemActionPerformed(evt);
            }
        });
        DeleteInformationMenu.add(DeleteAllAboutItemsMenuItem);

        DeleteAllAboutCustomersMenuItem.setText("Delete All About Customers");
        DeleteAllAboutCustomersMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteAllAboutCustomersMenuItemActionPerformed(evt);
            }
        });
        DeleteInformationMenu.add(DeleteAllAboutCustomersMenuItem);

        DeleteDatabaseMenuItem.setText("Delete Database");
        DeleteDatabaseMenuItem.setToolTipText("Delete Whole Database Except Administrator Information");
        DeleteDatabaseMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteDatabaseMenuItemActionPerformed(evt);
            }
        });
        DeleteInformationMenu.add(DeleteDatabaseMenuItem);

        OwnerMenu.add(DeleteInformationMenu);

        TakeBackupToMailMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_M, java.awt.event.InputEvent.CTRL_MASK));
        TakeBackupToMailMenuItem.setText("Take Backup to Mail");
        TakeBackupToMailMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TakeBackupToMailMenuItemActionPerformed(evt);
            }
        });
        OwnerMenu.add(TakeBackupToMailMenuItem);

        WelcomeFrameMenuBar.add(OwnerMenu);

        StoresMenu.setText("Stores");
        StoresMenu.setToolTipText("Go To Store");

        jMenuItem1.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.ALT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem1.setText("Add New Store");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        StoresMenu.add(jMenuItem1);

        WelcomeFrameMenuBar.add(StoresMenu);

        OffersMenu.setText("Offers");
        OffersMenu.setToolTipText("Go To Offers");

        AddOfferMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_O, java.awt.event.InputEvent.CTRL_MASK));
        AddOfferMenuItem.setText("Add Offer");
        AddOfferMenuItem.setToolTipText("Click Here To Add Offers");
        AddOfferMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddOfferMenuItemActionPerformed(evt);
            }
        });
        OffersMenu.add(AddOfferMenuItem);

        ViewOffersMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_O, java.awt.event.InputEvent.ALT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        ViewOffersMenuItem.setText("View Offers");
        ViewOffersMenuItem.setToolTipText("Click Here To View Offers");
        ViewOffersMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ViewOffersMenuItemActionPerformed(evt);
            }
        });
        OffersMenu.add(ViewOffersMenuItem);

        WelcomeFrameMenuBar.add(OffersMenu);

        setJMenuBar(WelcomeFrameMenuBar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(623, 623, 623)
                .addComponent(Lock, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(TimeCaption, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(DayCaption, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addComponent(Lock, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(217, 217, 217)
                .addComponent(TimeCaption, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6)
                .addComponent(DayCaption, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void PurchaseNewItemMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PurchaseNewItemMenuItemActionPerformed
        new ViewPurchase().setVisible(true);
        AdminPanel.this.setVisible(false);
    }//GEN-LAST:event_PurchaseNewItemMenuItemActionPerformed

    private void LockActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LockActionPerformed
        String info = username + " Logged Out";
        Utility.setConsoleLogging(true);
        Utility.addToLog(info);
        new LoginFrame().setVisible(true);
        open--;
        String j[] = {"1"};
        Load.main(j);
        AdminPanel.this.dispose();
    }//GEN-LAST:event_LockActionPerformed

    private void AddEmployeeMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddEmployeeMenuItemActionPerformed
        new AddEmployee().setVisible(true);
        open--;
        AdminPanel.this.dispose();
    }//GEN-LAST:event_AddEmployeeMenuItemActionPerformed

    private void ViewBillsMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ViewBillsMenuItemActionPerformed
        new ViewBills(0).setVisible(true);
        open--;
        AdminPanel.this.dispose();
    }//GEN-LAST:event_ViewBillsMenuItemActionPerformed

    private void ViewEmployeesMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ViewEmployeesMenuItemActionPerformed
        new Employees().setVisible(true);
        open--;
        AdminPanel.this.dispose();
    }//GEN-LAST:event_ViewEmployeesMenuItemActionPerformed

    private void ChangePasswordMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ChangePasswordMenuItemActionPerformed
        ChangePasswordDialog.show();
    }//GEN-LAST:event_ChangePasswordMenuItemActionPerformed

    private void LoggingInformationMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LoggingInformationMenuItemActionPerformed
        String documents = System.getenv("USERPROFILE");
        String send = "cmd /c start " + documents + "\\.billingsoftware\\.log\\2014\\";
        try {
            getRuntime().exec(send);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(AdminPanel.this, ex.getMessage(), "Error", 0);
        }
    }//GEN-LAST:event_LoggingInformationMenuItemActionPerformed

    private void ViewAllCustomersMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ViewAllCustomersMenuItemActionPerformed
        new ViewAllCustomers(0).setVisible(true);
        open--;
        AdminPanel.this.dispose();
    }//GEN-LAST:event_ViewAllCustomersMenuItemActionPerformed

    private void UpdateDatabaseMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UpdateDatabaseMenuItemActionPerformed
        JOptionPane.showMessageDialog(AdminPanel.this, "Not Yet Implemented", "Error", 0);
    }//GEN-LAST:event_UpdateDatabaseMenuItemActionPerformed

    private void DeleteDatabaseMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteDatabaseMenuItemActionPerformed
        int showConfirmDialog = jOptionPane1.showConfirmDialog(AdminPanel.this, "Are you sure?", "Confirm :" + DeleteDatabaseMenuItem.getText(), 0);
        if (showConfirmDialog == JOptionPane.CANCEL_OPTION) {
            jOptionPane1.showMessageDialog(AdminPanel.this, "Choice Cancelled !!!", "", 0);
        }
        if (showConfirmDialog == JOptionPane.NO_OPTION) {
            jOptionPane1.showMessageDialog(AdminPanel.this, "Database Not Deleted !!!", "Database Not Deleted !!!", 1);
        }
        if (showConfirmDialog == JOptionPane.YES_OPTION) {
            try {
                Connection connection = DAOConnection.getConnection(0);
                try (Statement statement = connection.createStatement()) {
                    statement.executeUpdate("delete from bill");
                    statement.executeUpdate("delete from employee");
                    statement.executeUpdate("delete from custominfo");
                    statement.executeUpdate("delete from customer");
                    statement.executeUpdate("delete from item");
                    statement.executeUpdate("delete from users");
                    statement.executeUpdate("delete from offers");
                    statement.executeUpdate("insert into users values('Shagun','Shagun',2)");
                    jOptionPane1.showMessageDialog(AdminPanel.this, "Database Deleted !!!", "Database Deleted !!!", 2);
                }
                connection.close();
            } catch (ClassNotFoundException | SQLException ex) {
                jOptionPane1.showMessageDialog(AdminPanel.this, ex.getMessage(), "Error", 0);
            }
        }
    }//GEN-LAST:event_DeleteDatabaseMenuItemActionPerformed

    private void DeleteAllAboutCustomersMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteAllAboutCustomersMenuItemActionPerformed
        // TODO add your handling code here:
        int showConfirmDialog = jOptionPane1.showConfirmDialog(AdminPanel.this, "Are you sure?", "Confirm :" + DeleteAllAboutCustomersMenuItem.getText(), 0);
        if (showConfirmDialog == JOptionPane.CANCEL_OPTION) {
            jOptionPane1.showMessageDialog(AdminPanel.this, "Choice Cancelled !!!", "", 0);
        }
        if (showConfirmDialog == JOptionPane.NO_OPTION) {
            jOptionPane1.showMessageDialog(AdminPanel.this, "Customer Information Not Deleted !!!", "Customer Information Not Deleted !!!", 1);
        }
        if (showConfirmDialog == JOptionPane.YES_OPTION) {
            try {
                Connection connection = DAOConnection.getConnection(0);
                try (Statement statement = connection.createStatement()) {
                    statement.executeUpdate("delete from custominfo");
                    statement.executeUpdate("delete from customer");
                    jOptionPane1.showMessageDialog(AdminPanel.this, "Customers Information Deleted !!!", "Customers Information Deleted !!!", 2);
                }
                connection.close();
            } catch (ClassNotFoundException | SQLException ex) {
                jOptionPane1.showMessageDialog(AdminPanel.this, ex.getMessage(), "Error", 0);
            }
        }
    }//GEN-LAST:event_DeleteAllAboutCustomersMenuItemActionPerformed

    private void DeleteAllAboutItemsMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteAllAboutItemsMenuItemActionPerformed
        int showConfirmDialog = jOptionPane1.showConfirmDialog(AdminPanel.this, "Are you sure?", "Confirm :" + DeleteAllAboutItemsMenuItem.getText(), 0);
        if (showConfirmDialog == JOptionPane.CANCEL_OPTION) {
            jOptionPane1.showMessageDialog(AdminPanel.this, "Choice Cancelled !!!", "", 0);
        }
        if (showConfirmDialog == JOptionPane.NO_OPTION) {
            jOptionPane1.showMessageDialog(AdminPanel.this, "Items Information Not Deleted !!!", "Items Information Not Deleted !!!", 1);
        }
        if (showConfirmDialog == JOptionPane.YES_OPTION) {
            try {
                Connection connection = DAOConnection.getConnection(0);
                try (Statement statement = connection.createStatement()) {
                    statement.executeUpdate("delete from item");
                    statement.executeUpdate("delete from offers");
                    jOptionPane1.showMessageDialog(AdminPanel.this, "Items Information Deleted !!!", "Items Information Deleted !!!", 2);
                }
                connection.close();
            } catch (ClassNotFoundException | SQLException ex) {
                jOptionPane1.showMessageDialog(AdminPanel.this, ex.getMessage(), "Error", 0);
            }
        }

    }//GEN-LAST:event_DeleteAllAboutItemsMenuItemActionPerformed

    private void DeleteAllAboutEmployeesMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteAllAboutEmployeesMenuItemActionPerformed
        int showConfirmDialog = jOptionPane1.showConfirmDialog(AdminPanel.this, "Are you sure?", "Confirm :" + DeleteAllAboutEmployeesMenuItem.getText(), 0);
        if (showConfirmDialog == JOptionPane.CANCEL_OPTION) {
            jOptionPane1.showMessageDialog(AdminPanel.this, "Choice Cancelled !!!", "", 0);
        }
        if (showConfirmDialog == JOptionPane.NO_OPTION) {
            jOptionPane1.showMessageDialog(AdminPanel.this, "Employees Information Not Deleted !!!", "Employees Information Not Deleted !!!", 1);
        }
        if (showConfirmDialog == JOptionPane.YES_OPTION) {
            try {
                Connection connection = DAOConnection.getConnection(0);
                try (Statement statement = connection.createStatement()) {
                    statement.executeUpdate("delete from user_del");
                    jOptionPane1.showMessageDialog(AdminPanel.this, "Employees Information Deleted !!!", "Employees Information Deleted !!!", 2);
                }
                connection.close();
            } catch (ClassNotFoundException | SQLException ex) {
                jOptionPane1.showMessageDialog(AdminPanel.this, ex.getMessage(), "Error", 0);
            }
        }
    }//GEN-LAST:event_DeleteAllAboutEmployeesMenuItemActionPerformed

    private void TakeBackupToMailMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TakeBackupToMailMenuItemActionPerformed
        mailDialog.show();
    }//GEN-LAST:event_TakeBackupToMailMenuItemActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        Utility.setConsoleLogging(true);
        String info = username + " Logged Out";
        Utility.addToLog(info);
        new LoginFrame().setVisible(true);
        open--;
        String j[] = {"1"};
        Load.main(j);
        AdminPanel.this.dispose();
    }//GEN-LAST:event_formWindowClosing

    private void ViewOffersMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ViewOffersMenuItemActionPerformed
        new ViewOffers().setVisible(true);
        open--;
        AdminPanel.this.dispose();
    }//GEN-LAST:event_ViewOffersMenuItemActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        menu();
        JMenu gg = new JMenu(StoreMenuItemNumber);
        StoresMenu.add(gg);
        addMenuItems(gg);
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void AddOfferMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddOfferMenuItemActionPerformed
        new AddOffers().setVisible(true);
        open--;
        AdminPanel.this.dispose();

    }//GEN-LAST:event_AddOfferMenuItemActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
  /*      try {
            Connection connection = DAOConnection.getConnection(0);
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("select count(*) from stores");
            resultSet.next();
            long storeNumber = resultSet.getLong(1);
            resultSet.close();
            statement.close();
            statement = connection.createStatement();
            statement.executeUpdate("delete from stores");
            statement.close();
            connection.close();
            while (storeNumber > 0) {
                menu();
                JMenu gg = new JMenu(StoreMenuItemNumber);
                StoresMenu.add(gg);
                addMenuItems(gg);
                storeNumber--;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(AdminPanel.this, e.getMessage(), "Error", 0);
        }
*/
    }//GEN-LAST:event_formWindowOpened

    private void SendButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SendButtonActionPerformed
        String password = Password.getText();
        String username = Username.getText().trim();
        Backup(username, password);
    }//GEN-LAST:event_SendButtonActionPerformed

    private void ResetButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ResetButtonActionPerformed
        Username.setText(null);
        Password.setText(null);
        Username.requestFocus();
    }//GEN-LAST:event_ResetButtonActionPerformed

    private void CancelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelButtonActionPerformed
        mailDialog.dispose();
    }//GEN-LAST:event_CancelButtonActionPerformed

    private void ResetButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ResetButton1ActionPerformed
        Username.setText(null);
        OldPassword.setText(null);
        NewPassword.setText(null);
        ConfirmNewPassword.setText(null);
        message.setText(null);
        Username.requestFocus();
    }//GEN-LAST:event_ResetButton1ActionPerformed

    private void ChangeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ChangeActionPerformed
        try {
            String username = Username1.getText().trim();
            if (username.length() == 0) {
                Username1.requestFocus();
                throw new Exception("Enter Username");
            }
            String oldPassword = OldPassword.getText();
            if (oldPassword.length() == 0) {
                OldPassword.requestFocus();
                throw new Exception("Enter Old Password");
            }
            String newPassword = NewPassword.getText();
            if (newPassword.length() == 0) {
                NewPassword.requestFocus();
                throw new Exception("Enter New Password");
            }
            String confirmNewPassword = ConfirmNewPassword.getText();
            if (confirmNewPassword.length() == 0) {
                ConfirmNewPassword.requestFocus();
                throw new Exception("Please Confirm Password");
            }
            if (!(newPassword.equals(confirmNewPassword))) {
                NewPassword.selectAll();
                ConfirmNewPassword.selectAll();
                throw new Exception("Passwords Do not Match");
            }
            Connection connection = DAOConnection.getConnection(0);
            PreparedStatement preparedStatement = connection.prepareStatement("select * from users where username= ? and password = ?");
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, oldPassword);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (!(resultSet.next())) {
                resultSet.close();
                preparedStatement.close();
                connection.close();
                Username.requestFocus();
                throw new Exception("Invalid Login Credentials");
            }
            resultSet.close();
            preparedStatement.close();
            preparedStatement = connection.prepareStatement("update users set password = ? where username = ?");
            preparedStatement.setString(1, newPassword);
            preparedStatement.setString(2, username);
            preparedStatement.executeUpdate();
            JOptionPane.showMessageDialog(AdminPanel.this, "Password Changed Successfully", "Update Successful", 1);
            Username.setText(null);
            OldPassword.setText(null);
            NewPassword.setText(null);
            ConfirmNewPassword.setText(null);
            ChangePasswordDialog.dispose();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(AdminPanel.this, e.getMessage(), "Error", 0);
        }
    }//GEN-LAST:event_ChangeActionPerformed

    private void ReturnChangePasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ReturnChangePasswordActionPerformed
        ChangePasswordDialog.dispose();
    }//GEN-LAST:event_ReturnChangePasswordActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        new ViewStock();        
AdminPanel.this.dispose();
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
new ItemStoreDivision().setVisible(true);
AdminPanel.this.dispose();
// TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem3ActionPerformed

    public static void main(String args[]) {
//<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
/* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AdminPanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AdminPanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AdminPanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AdminPanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
//</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AdminPanel().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem AddEmployeeMenuItem;
    private javax.swing.JMenuItem AddOfferMenuItem;
    private javax.swing.JButton CancelButton;
    private javax.swing.JButton Change;
    private javax.swing.JDialog ChangePasswordDialog;
    private javax.swing.JMenuItem ChangePasswordMenuItem;
    private javax.swing.JPasswordField ConfirmNewPassword;
    private javax.swing.JMenu CustomersMenu;
    public static javax.swing.JLabel DayCaption;
    private javax.swing.JMenuItem DeleteAllAboutCustomersMenuItem;
    private javax.swing.JMenuItem DeleteAllAboutEmployeesMenuItem;
    private javax.swing.JMenuItem DeleteAllAboutItemsMenuItem;
    private javax.swing.JMenuItem DeleteDatabaseMenuItem;
    private javax.swing.JMenu DeleteInformationMenu;
    private javax.swing.JMenu EmployeesMenu;
    private javax.swing.JButton Lock;
    private javax.swing.JMenuItem LoggingInformationMenuItem;
    private javax.swing.JPasswordField NewPassword;
    private javax.swing.JMenu OffersMenu;
    private javax.swing.JPasswordField OldPassword;
    private javax.swing.JMenu OwnerMenu;
    private javax.swing.JPasswordField Password;
    private javax.swing.JLabel PasswordCaption;
    private javax.swing.JMenu PurchaseMenu;
    private javax.swing.JMenuItem PurchaseNewItemMenuItem;
    private javax.swing.JButton ResetButton;
    private javax.swing.JButton ResetButton1;
    private javax.swing.JButton ReturnChangePassword;
    private javax.swing.JMenu SalesMenu;
    private javax.swing.JButton SendButton;
    private javax.swing.JMenu StoresMenu;
    private javax.swing.JMenuItem TakeBackupToMailMenuItem;
    public static javax.swing.JLabel TimeCaption;
    private javax.swing.JMenuItem UpdateDatabaseMenuItem;
    private javax.swing.JTextField Username;
    private javax.swing.JTextField Username1;
    private javax.swing.JLabel UsernameCaption;
    private javax.swing.JMenuItem ViewAllCustomersMenuItem;
    private javax.swing.JMenuItem ViewBillsMenuItem;
    private javax.swing.JMenuItem ViewEmployeesMenuItem;
    private javax.swing.JMenuItem ViewOffersMenuItem;
    private javax.swing.JMenuBar WelcomeFrameMenuBar;
    private javax.swing.JLabel confirmNewPasswordCaption;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JOptionPane jOptionPane1;
    private javax.swing.JDialog mailDialog;
    private javax.swing.JLabel message;
    private javax.swing.JLabel newPasswordCaption;
    private javax.swing.JLabel oldPasswordCaption;
    private javax.swing.JLabel usernameCaption;
    // End of variables declaration//GEN-END:variables
    String StoreMenuItemName, StoreMenuItemNumber;
    int menuItems;

    private void menu() {
        menuItems = StoresMenu.getItemCount();
        StoreMenuItemName = "Store" + menuItems + "MenuItem";
        StoreMenuItemNumber = "Store " + menuItems;
    }

    private void addMenuItems(javax.swing.JMenu menu) {
        JMenuItem viewPurchase = new JMenuItem("View Stocks");
//JMenuItem viewPurchase = new JMenuItem("View Purchase");
        JMenuItem viewBills = new JMenuItem("View Bills");
//JMenuItem viewCustomers = new JMenuItem("View Customers");
//JMenuItem viewEmployees = new JMenuItem("View Employees");

        menu.add(viewPurchase);
//menu.add(viewPurchase);
        menu.add(viewBills);
//menu.add(viewCustomers);
//menu.add(viewEmployees);

        viewPurchase.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                viewPurchaseMenuItemActionPerformed(evt);
            }

            private void viewPurchaseMenuItemActionPerformed(ActionEvent evt) {
                JMenuItem jmi = (JMenuItem) evt.getSource();
                JPopupMenu jpm = (JPopupMenu) jmi.getParent();
                JMenu mmenu = (JMenu) jpm.getInvoker();
                String i = (mmenu.getText());
                char ii[] = i.toCharArray();
                i = "";
                int j = ii.length - 1;
                while (j > 0) {
                    if (ii[j] == ' ') {
                        break;

                    }
                    i += ii[j];
                    j--;
                }
                i = i.trim();
                StringBuffer a = new StringBuffer(i);
                a = a.reverse();
                String storeNumber = a.toString();

                new ViewPurchase().setVisible(true);
                open--;
                AdminPanel.this.dispose();

            }
        });

        viewBills.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                viewBillsMenuItemActionPerformed(evt);
            }

            private void viewBillsMenuItemActionPerformed(ActionEvent evt) {
                JMenuItem jmi = (JMenuItem) evt.getSource();
                JPopupMenu jpm = (JPopupMenu) jmi.getParent();
                JMenu mmenu = (JMenu) jpm.getInvoker();
                String i = (mmenu.getText());
                char ii[] = i.toCharArray();
                i = "";
                int j = ii.length - 1;
                while (j > 0) {
                    if (ii[j] == ' ') {
                        break;

                    }
                    i += ii[j];
                    j--;
                }
                i = i.trim();
                StringBuffer a = new StringBuffer(i);
                a = a.reverse();
                String storeNumber = a.toString();

                new ViewBills(Integer.parseInt(storeNumber)).setVisible(true);
                open--;
                AdminPanel.this.dispose();

            }
        });

        try {
            Connection connection = DAOConnection.getConnection(0);
            PreparedStatement preparedStatement = connection.prepareStatement("insert into stores values(?)");
            preparedStatement.setLong(1, StoresMenu.getItemCount() - 1);
            preparedStatement.executeUpdate();
            preparedStatement.close();
            connection.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(AdminPanel.this, e.getMessage(), "Error", 0);
        }

        try {
            Connection connection = DAOConnection.getConnection(StoresMenu.getItemCount() - 1);
            Statement statement = connection.createStatement();
            statement.addBatch("CREATE TABLE users (\n"
                    + "username varchar(20),\n"
                    + "password varchar(20),\n"
                    + "forgot_password varchar(20)");
            statement.addBatch("CREATE TABLE item (\n"
                    + "Code long primary key,\n"
                    + "Description varchar(30) not null,\n"
                    + "Rate Long not null,\n"
                    + "Margin double not null,\n"
                    + "Sell_Price double,\n"
                    + "Stock_Left double not null)");

            statement.addBatch("CREATE TABLE offers (\n"
                    + "Offer_Code varchar(10),\n"
                    + "Description varchar(100),\n"
                    + "ItemName1 varchar(20),\n"
                    + "ItemName2 varchar(20),\n"
                    + "Item1Quantity float,\n"
                    + "Item2Quantity float,\n"
                    + "Rate Float)");

            statement.addBatch("CREATE TABLE bill (Bill_Number long primary key,\n"
                    + "Bill_Date varchar(10),\n"
                    + "Customer_Code long references customer(Code),\n"
                    + "Billed_Amount long,\n"
                    + "Bill_Payment varchar(6),\n"
                    + "Billed_Credit_Debit_Card_Number varchar(17) default 0)");

            statement.addBatch("CREATE TABLE stores(\n"
                    + "Store_Number long)");

            statement.addBatch("CREATE TABLE employee (Code long,\n"
                    + "Name varchar(20),\n"
                    + "Gender char(6),\n"
                    + "Address varchar(40),\n"
                    + "Mobile_Number char(11),\n"
                    + "Department varchar(20),\n"
                    + "Salary double");

            statement.addBatch("CREATE TABLE custominfo(\n"
                    + "Bill_Number long references bill(Bill_Number),\n"
                    + "Customer_Code long references customer(code),\n"
                    + "Bill_Date varchar(10) references bill(Bill_Date),\n"
                    + "Total_Shopping Long,\n"
                    + "desc varchar(4000)");

            statement.addBatch("CREATE TABLE customer (Code long primary key,\n"
                    + "Name varchar(30) not null,\n"
                    + "Address varchar(50),\n"
                    + "City varchar(20),\n"
                    + "Mobile_Number varchar(11) not null unique)");

            int y[] = statement.executeBatch();
            int i = 0;
            while (i < y.length) {
                System.out.println(y[i]);
                i++;
            }
            statement.close();

            PreparedStatement preparedStatement = null;
            Connection c = DAOConnection.getConnection(0);
            statement = c.createStatement();
            ResultSet resultSet = statement.executeQuery("select * from item");
            while (resultSet.next()) {
                preparedStatement = connection.prepareStatement("insert into item values (?,?,?,?,?,?)");
                preparedStatement.setLong(1, resultSet.getLong(1));
                preparedStatement.setString(2, resultSet.getString(2));
                preparedStatement.setLong(3, resultSet.getLong(3));
                preparedStatement.setDouble(4, resultSet.getDouble(4));
                preparedStatement.setDouble(5, resultSet.getDouble(5));
                preparedStatement.setDouble(6, resultSet.getDouble(6));
                preparedStatement.executeUpdate();
                preparedStatement.close();
            }
            resultSet.close();

            resultSet = statement.executeQuery("select * from users");
            while (resultSet.next()) {
                preparedStatement = connection.prepareStatement("insert into users values (?,?,?)");
                preparedStatement.setString(1, resultSet.getString(1));
                preparedStatement.setString(2, resultSet.getString(2));
                preparedStatement.setString(3, resultSet.getString(3));
                preparedStatement.executeUpdate();
                preparedStatement.close();
            }
            resultSet.close();
            resultSet = statement.executeQuery("select * from offers");
            while (resultSet.next()) {
                preparedStatement = connection.prepareStatement("insert into offers values (?,?,?,?,?,?,?)");
                preparedStatement.setString(1, resultSet.getString(1));
                preparedStatement.setString(2, resultSet.getString(2));
                preparedStatement.setString(3, resultSet.getString(3));
                preparedStatement.setString(4, resultSet.getString(4));
                preparedStatement.setFloat(5, resultSet.getFloat(5));
                preparedStatement.setFloat(6, resultSet.getFloat(6));
                preparedStatement.setFloat(7, resultSet.getFloat(7));
                preparedStatement.executeUpdate();
                preparedStatement.close();
            }
            resultSet.close();
            statement.close();
            c.close();
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {

        }
    }
}
