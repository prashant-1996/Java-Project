package com.billingsoftware;

import javax.swing.ImageIcon;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;

public class BillNumber extends javax.swing.JFrame implements Resources {

    String name;
    long code;
    private static int storeNumber;

    public BillNumber() {
        initComponents();
        BillNumber.this.setIconImage(new ImageIcon(getClass().getResource(BILL_ICON)).getImage());
    }

    public BillNumber(String name, long code, int storeNumber) {
        initComponents();
        this.name = name;
        this.code = code;
        this.storeNumber = storeNumber;
        BillNumber.this.setIconImage(new ImageIcon(getClass().getResource(BILL_ICON)).getImage());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        BillItems = new javax.swing.JTextArea();
        jScrollPane3 = new javax.swing.JScrollPane();
        BillNumberTable = new javax.swing.JTable();
        message = new javax.swing.JLabel();
        ReturnButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Bill Details");
        setMaximumSize(new java.awt.Dimension(825, 417));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        BillItems.setEditable(false);
        BillItems.setColumns(30);
        BillItems.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        BillItems.setRows(8);
        BillItems.setWrapStyleWord(true);
        jScrollPane2.setViewportView(BillItems);

        BillNumberTable.setAutoCreateRowSorter(true);
        BillNumberTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Bill Number"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        BillNumberTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BillNumberTableMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(BillNumberTable);
        if (BillNumberTable.getColumnModel().getColumnCount() > 0) {
            BillNumberTable.getColumnModel().getColumn(0).setResizable(false);
        }

        message.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        ReturnButton.setIcon(new javax.swing.ImageIcon(getClass().getResource(BACK_ICON)));
        ReturnButton.setMnemonic('B');
        ReturnButton.setToolTipText(BACK_ICON_STRING);
        ReturnButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ReturnButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ReturnButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(ReturnButton, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(124, 124, 124)
                        .addComponent(message, javax.swing.GroupLayout.PREFERRED_SIZE, 608, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 658, javax.swing.GroupLayout.PREFERRED_SIZE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(message, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ReturnButton, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 455, Short.MAX_VALUE))
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        try {
            Connection connection = DAOConnection.getConnection(storeNumber);

            PreparedStatement preparedStatement = connection.prepareStatement("select Bill_Number from Bill where Customer_Code= ? ");
            preparedStatement.setLong(1, code);
            ResultSet resultSet = preparedStatement.executeQuery();
            DefaultTableModel dtm = (DefaultTableModel) BillNumberTable.getModel();
            while (resultSet.next()) {
                Object[] rowData = {resultSet.getLong(1)};
                dtm.addRow(rowData);

            }

            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(BillNumber.this, e.getMessage(), "Error", 0);
        }
    }//GEN-LAST:event_formWindowOpened

    private void BillNumberTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BillNumberTableMouseClicked
        BillItems.setText(null);
        try {
            Connection connection = DAOConnection.getConnection(storeNumber);

            PreparedStatement preparedStatement = connection.prepareStatement("select desc from custominfo where Bill_Number = ?");
            int row = BillNumberTable.getSelectedRow();
            long r = (long) BillNumberTable.getValueAt(row, 0);
            preparedStatement.setLong(1, r);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                BillItems.setText("" + resultSet.getString(1));
            }
            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(BillNumber.this, e.getMessage(), "Error", 0);
        }

    }//GEN-LAST:event_BillNumberTableMouseClicked

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        new ParticularCustomer(name, code, storeNumber).setVisible(true);
        BillNumber.this.dispose();
    }//GEN-LAST:event_formWindowClosing

    private void ReturnButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ReturnButtonActionPerformed
        new ParticularCustomer(name, code, storeNumber).setVisible(true);
        BillNumber.this.dispose();
    }//GEN-LAST:event_ReturnButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BillNumber.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BillNumber.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BillNumber.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BillNumber.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BillNumber().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea BillItems;
    private javax.swing.JTable BillNumberTable;
    private javax.swing.JButton ReturnButton;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JLabel message;
    // End of variables declaration//GEN-END:variables
}
