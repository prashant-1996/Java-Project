package com.billingsoftware;

import java.awt.Component;
import java.awt.Desktop;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import static java.awt.event.KeyEvent.VK_ENTER;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.NumberFormat;
import java.util.Calendar;
import java.util.Date;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.ImageIcon;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

class CustomerClock implements java.awt.event.ActionListener {

    public synchronized void actionPerformed(ActionEvent e) {
        Calendar now = Calendar.getInstance();
        int dd = now.get(Calendar.DATE);
        int mm = now.get(Calendar.MONTH);
        int yy = now.get(Calendar.YEAR);
        int h = now.get(Calendar.HOUR_OF_DAY);
        int m = now.get(Calendar.MINUTE);
        int s = now.get(Calendar.SECOND);
        int hours = h;
        int pm = 0;
        String hour = String.valueOf(hours);
        if (hours >= 0 && hours <= 9) {
            hour = "0" + hours;
        } else {
            if (hours > 12 && hours <= 24) {
                hours = hours - 12;
                hour = "" + hours;
                pm++;
            }
            if (hours >= 0 && hours <= 9) {
                hour = "0" + hours;
            }
        }
        String meridian = "";
        if ((hours >= 0 && hours < 12) && pm == 0) {
            meridian = "AM";
        } else {
            meridian = "PM";
        }
        int minutes = m;
        String minute = String.valueOf(minutes);
        if (minutes >= 0 && minutes <= 9) {
            minute = "0" + minutes;
        }
        int seconds = s;
        String second = String.valueOf(seconds);
        if (seconds >= 0 && seconds <= 9) {
            second = "0" + seconds;
        }

        Date d = new Date();
        String day = "";

        switch (d.getDay()) {
            case 0: {
                day = "Sunday";
                break;
            }
            case 1: {
                day = "Monday";
                break;
            }
            case 2: {
                day = "Tuesday";
                break;
            }
            case 3: {
                day = "Wednesday";
                break;
            }
            case 4: {
                day = "Thursday";
                break;
            }
            case 5: {
                day = "Friday";
                break;
            }
            case 6: {
                day = "Saturday";
                break;
            }
        }
        int date = d.getDate();
        String dat = String.valueOf(date);
        if (date > 0 && date < 10) {
            dat = "0" + date;
        }

        int month = (d.getMonth() + 1);
        String mont = String.valueOf(month);
        if (month > 0 && month < 10) {
            mont = "0" + month;
        }
        int year = (d.getYear() + 1900);
        CustomerFrame.BillDate.setText(day + ":" + dat + "/" + mont + "/" + year + " " + hour + ":" + minute + ":" + second + meridian);
        new CustomerFrame(dat, mont, year);
        try {
            try (Connection connection = DAOConnection.getConnection(0); PreparedStatement preparedStatement = connection.prepareStatement("select count(*) from bill")) {
                ResultSet resultSet = preparedStatement.executeQuery();
                if (resultSet.next()) {
                    Long Bill = resultSet.getLong(1);
                    if (Bill == 0) {
                        Bill = 1L;
                    } else {
                        Bill++;
                    }
                    CustomerFrame.BillNumberr.setText("" + Bill);
                }
                resultSet.close();
            }
        } catch (ClassNotFoundException | SQLException exx) {
            JOptionPane.showMessageDialog(null, exx.getMessage(), "Error", 0);

        }
    }
}

class HeaderRenderer implements TableCellRenderer {

    DefaultTableCellRenderer renderer;

    public HeaderRenderer(JTable CustomerTable) {
        renderer = (DefaultTableCellRenderer) CustomerTable.getTableHeader().getDefaultRenderer();
        renderer.setHorizontalAlignment(JLabel.CENTER);
    }

    @Override
    public Component getTableCellRendererComponent(JTable CustomerTable, Object value, boolean isSelected, boolean hasFocus, int row, int col) {
        return renderer.getTableCellRendererComponent(CustomerTable, value, isSelected, hasFocus, row, col);
    }
}

public class CustomerFrame extends javax.swing.JFrame implements Resources, ListSelectionListener {

    NumberFormat nf = NumberFormat.getNumberInstance();
    static int t = 0, l = 0, open = 0, i = 0;

    {
        nf.setMaximumFractionDigits(2);
        nf.setMinimumFractionDigits(0);
    }
    static String date;
    static String month;
    static int year;
    static String desc = "";
    static javax.swing.Timer timer;
    static String name;
    Connection connection = null;
    Statement statement = null;
    PreparedStatement preparedStatement = null;
    ResultSet r = null, resultSet = null;
    private static int storeNumber;

    public void valueChanged(ListSelectionEvent ev) {
        int selectedRow = ev.getLastIndex();
        if (selectedRow >= 0) {
            try {
                quantity.setText("" + (Float) CustomerTable.getValueAt(CustomerTable.getSelectedRow(), 4));
            } catch (ArrayIndexOutOfBoundsException ex) {
            }

            DeleteItemFromListButton.setEnabled(true);
        } else {
            DeleteItemFromListButton.setEnabled(false);
        }
    }

    public CustomerFrame() {
        initComponents();
        CustomerFrame.storeNumber = storeNumber;
        CustomerFrame.name = name;
        timer = new javax.swing.Timer(1000, new CustomerClock());
        timer.start();
        open++;
        CustomerTable.getSelectionModel().addListSelectionListener(this);
        CustomerFrame.this.setIconImage(new ImageIcon(getClass().getResource(TRANSACTION_ICON_1)).getImage());
    }

    public CustomerFrame(String name, int storeNumber) {
        initComponents();
        CustomerFrame.storeNumber = storeNumber;
        CustomerFrame.name = name;
        timer = new javax.swing.Timer(1000, new CustomerClock());
        timer.start();
        open++;
        CustomerTable.getSelectionModel().addListSelectionListener(this);
        CustomerFrame.this.setIconImage(new ImageIcon(getClass().getResource(TRANSACTION_ICON_1)).getImage());
    }

    public CustomerFrame(String date, String month, int year) {
        CustomerFrame.date = date;
        CustomerFrame.month = month;
        CustomerFrame.year = year;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Exit = new javax.swing.JOptionPane();
        TabbedPane = new javax.swing.JTabbedPane();
        TransactionPanel = new javax.swing.JPanel();
        CustomerPanel = new javax.swing.JPanel();
        BillingInformation = new javax.swing.JPanel();
        SalesBillCaption = new javax.swing.JLabel();
        SeparatorBetweenSalesBillAndBillNumber = new javax.swing.JSeparator();
        BillNumberCaption = new javax.swing.JLabel();
        BillNumberr = new javax.swing.JTextField();
        SeparatorBetweenBillNumberrAndBillDate = new javax.swing.JSeparator();
        BillDateCaption = new javax.swing.JLabel();
        BillDate = new javax.swing.JLabel();
        CustomerInformation = new javax.swing.JPanel();
        CustomerName = new javax.swing.JTextField();
        CustomerNameCaption = new javax.swing.JLabel();
        GeneratedCode = new javax.swing.JTextField();
        CodeCaption = new javax.swing.JLabel();
        CityCaption = new javax.swing.JLabel();
        City = new javax.swing.JTextField();
        CustomerAddress = new javax.swing.JTextField();
        CustomerAddressCaption = new javax.swing.JLabel();
        MobileNumberCaption = new javax.swing.JLabel();
        MobileNumber = new javax.swing.JTextField();
        InformationPanel = new javax.swing.JPanel();
        message = new javax.swing.JLabel();
        quantity = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        EnteredCodeCaption = new javax.swing.JLabel();
        EnteredCode = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        CustomerTable = new javax.swing.JTable();
        ButtonPanel = new javax.swing.JPanel();
        ClearAllButton = new javax.swing.JButton();
        HoldButton = new javax.swing.JButton();
        CancelButton = new javax.swing.JButton();
        DeleteItemFromListButton = new javax.swing.JButton();
        BillingAmountInformation = new javax.swing.JPanel();
        TotalAmountPayable = new javax.swing.JLabel();
        SubTotal = new javax.swing.JTextField();
        SubTotalCaption = new javax.swing.JLabel();
        NettAmountCaption = new javax.swing.JLabel();
        NettAmount = new javax.swing.JTextField();
        AmountPaidByCustomerCaption = new javax.swing.JLabel();
        AmountPaidToCustomerCaption = new javax.swing.JLabel();
        AmountPaidToCustomer = new javax.swing.JTextField();
        mode = new javax.swing.JComboBox();
        AmountPaidByCustomer = new javax.swing.JTextField();
        user = new javax.swing.JLabel();
        PrintLastBillButton = new javax.swing.JButton();
        PayBillButton = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        ItemTable = new javax.swing.JTable();
        SearchItemCodeCaption = new javax.swing.JLabel();
        ItemCode = new javax.swing.JTextField();
        ItemName = new javax.swing.JTextField();
        SearchItemNameCaption = new javax.swing.JLabel();
        OffersPanel = new javax.swing.JPanel();
        OffersMessage = new javax.swing.JLabel();
        AvailOffersButton = new javax.swing.JButton();
        jScrollPane9 = new javax.swing.JScrollPane();
        OfferTable2 = new javax.swing.JTable();
        jScrollPane10 = new javax.swing.JScrollPane();
        OfferTable1 = new javax.swing.JTable();
        jScrollPane11 = new javax.swing.JScrollPane();
        OfferTable3 = new javax.swing.JTable();

        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Transaction");
        setMinimumSize(new java.awt.Dimension(1053, 647));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        TabbedPane.setTabLayoutPolicy(javax.swing.JTabbedPane.SCROLL_TAB_LAYOUT);
        TabbedPane.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        TabbedPane.setMinimumSize(new java.awt.Dimension(1098, 510));

        BillingInformation.setBackground(javax.swing.UIManager.getDefaults().getColor("CheckBox.shadow"));

        SalesBillCaption.setFont(SalesBillCaption.getFont().deriveFont(SalesBillCaption.getFont().getSize()+3f));
        SalesBillCaption.setText("Sales Bill");

        SeparatorBetweenSalesBillAndBillNumber.setOrientation(javax.swing.SwingConstants.VERTICAL);

        BillNumberCaption.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        BillNumberCaption.setText("Bill Number");

        BillNumberr.setEditable(false);

        SeparatorBetweenBillNumberrAndBillDate.setOrientation(javax.swing.SwingConstants.VERTICAL);

        BillDateCaption.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        BillDateCaption.setText("Bill Date");

        BillDate.setBackground(new java.awt.Color(255, 255, 255));
        BillDate.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        BillDate.setVerticalAlignment(javax.swing.SwingConstants.TOP);

        javax.swing.GroupLayout BillingInformationLayout = new javax.swing.GroupLayout(BillingInformation);
        BillingInformation.setLayout(BillingInformationLayout);
        BillingInformationLayout.setHorizontalGroup(
            BillingInformationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(BillingInformationLayout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(SalesBillCaption)
                .addGap(18, 18, 18)
                .addComponent(SeparatorBetweenSalesBillAndBillNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(4, 4, 4)
                .addComponent(BillNumberCaption)
                .addGap(10, 10, 10)
                .addComponent(BillNumberr, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(SeparatorBetweenBillNumberrAndBillDate, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(4, 4, 4)
                .addComponent(BillDateCaption)
                .addGap(18, 18, 18)
                .addComponent(BillDate, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(144, Short.MAX_VALUE))
        );
        BillingInformationLayout.setVerticalGroup(
            BillingInformationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(SeparatorBetweenSalesBillAndBillNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addComponent(SeparatorBetweenBillNumberrAndBillDate, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGroup(BillingInformationLayout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(BillingInformationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(SalesBillCaption)
                    .addComponent(BillNumberCaption)
                    .addComponent(BillNumberr, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BillDateCaption)
                    .addComponent(BillDate, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        CustomerInformation.setBackground(javax.swing.UIManager.getDefaults().getColor("Button.light"));

        CustomerName.setToolTipText("Enter Name");

        CustomerNameCaption.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        CustomerNameCaption.setText("Customer's Name *");

        GeneratedCode.setEditable(false);
        GeneratedCode.setToolTipText("Generated Code For Customer");
        GeneratedCode.setFocusable(false);

        CodeCaption.setText("Code");

        CityCaption.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        CityCaption.setText("City");

        City.setToolTipText("Enter City");

        CustomerAddress.setToolTipText("Enter Address");

        CustomerAddressCaption.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        CustomerAddressCaption.setText("Customer's Address");

        MobileNumberCaption.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        MobileNumberCaption.setText("Mobile Number *");
        MobileNumberCaption.setToolTipText("");

        MobileNumber.setToolTipText("Enter Mobile Number");
        MobileNumber.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                MobileNumberKeyReleased(evt);
            }
        });

        InformationPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Information Panel", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 12))); // NOI18N

        message.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        message.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        quantity.setToolTipText("Enter Quantity");
        quantity.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                quantityKeyReleased(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel6.setText("Quantity");

        javax.swing.GroupLayout InformationPanelLayout = new javax.swing.GroupLayout(InformationPanel);
        InformationPanel.setLayout(InformationPanelLayout);
        InformationPanelLayout.setHorizontalGroup(
            InformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(InformationPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(message, javax.swing.GroupLayout.PREFERRED_SIZE, 433, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 79, Short.MAX_VALUE)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(quantity, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        InformationPanelLayout.setVerticalGroup(
            InformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(message, javax.swing.GroupLayout.DEFAULT_SIZE, 31, Short.MAX_VALUE)
            .addGroup(InformationPanelLayout.createSequentialGroup()
                .addGroup(InformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(quantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        EnteredCodeCaption.setText("Code");

        EnteredCode.setToolTipText("Enter Code For Customer");
        EnteredCode.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                EnteredCodeKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout CustomerInformationLayout = new javax.swing.GroupLayout(CustomerInformation);
        CustomerInformation.setLayout(CustomerInformationLayout);
        CustomerInformationLayout.setHorizontalGroup(
            CustomerInformationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CustomerInformationLayout.createSequentialGroup()
                .addGroup(CustomerInformationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(CustomerInformationLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(CustomerInformationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(CustomerNameCaption)
                            .addComponent(CustomerAddressCaption))
                        .addGap(18, 18, 18)
                        .addGroup(CustomerInformationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(CustomerInformationLayout.createSequentialGroup()
                                .addComponent(CustomerName, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(MobileNumberCaption))
                            .addGroup(CustomerInformationLayout.createSequentialGroup()
                                .addComponent(CustomerAddress, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(CityCaption)))
                        .addGap(18, 18, 18)
                        .addGroup(CustomerInformationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(CustomerInformationLayout.createSequentialGroup()
                                .addComponent(City, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(EnteredCodeCaption))
                            .addGroup(CustomerInformationLayout.createSequentialGroup()
                                .addComponent(MobileNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(CodeCaption)))
                        .addGap(23, 23, 23)
                        .addGroup(CustomerInformationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(GeneratedCode, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(EnteredCode, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(CustomerInformationLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(InformationPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        CustomerInformationLayout.setVerticalGroup(
            CustomerInformationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CustomerInformationLayout.createSequentialGroup()
                .addGroup(CustomerInformationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(CustomerInformationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(CustomerName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(MobileNumberCaption)
                        .addComponent(MobileNumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(CodeCaption)
                        .addComponent(GeneratedCode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(CustomerInformationLayout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addComponent(CustomerNameCaption)))
                .addGroup(CustomerInformationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(CustomerInformationLayout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(CustomerAddressCaption))
                    .addGroup(CustomerInformationLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(CustomerAddress, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(CustomerInformationLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(CustomerInformationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(City, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(CityCaption)
                            .addComponent(EnteredCodeCaption)
                            .addComponent(EnteredCode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 14, Short.MAX_VALUE)
                .addComponent(InformationPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        CustomerTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Item Number", "    Item Code", "      Description", "     Rate", "    Quantity", "    Total"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Long.class, java.lang.Long.class, java.lang.String.class, java.lang.Integer.class, java.lang.Double.class, java.lang.Double.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        CustomerTable.setToolTipText("Add Items From Items List ");
        CustomerTable.setDoubleBuffered(true);
        CustomerTable.setFillsViewportHeight(true);
        CustomerTable.setFocusCycleRoot(true);
        CustomerTable.setFocusTraversalPolicyProvider(true);
        CustomerTable.setSelectionBackground(java.awt.Color.lightGray);
        CustomerTable.setSelectionForeground(java.awt.Color.black);
        CustomerTable.setSurrendersFocusOnKeystroke(true);
        CustomerTable.getTableHeader().setReorderingAllowed(false);
        CustomerTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CustomerTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(CustomerTable);
        if (CustomerTable.getColumnModel().getColumnCount() > 0) {
            CustomerTable.getColumnModel().getColumn(0).setMinWidth(80);
            CustomerTable.getColumnModel().getColumn(0).setPreferredWidth(80);
            CustomerTable.getColumnModel().getColumn(0).setMaxWidth(80);
            CustomerTable.getColumnModel().getColumn(1).setMinWidth(100);
            CustomerTable.getColumnModel().getColumn(1).setPreferredWidth(100);
            CustomerTable.getColumnModel().getColumn(1).setMaxWidth(100);
            CustomerTable.getColumnModel().getColumn(3).setMinWidth(70);
            CustomerTable.getColumnModel().getColumn(3).setPreferredWidth(70);
            CustomerTable.getColumnModel().getColumn(3).setMaxWidth(70);
            CustomerTable.getColumnModel().getColumn(4).setMinWidth(90);
            CustomerTable.getColumnModel().getColumn(4).setPreferredWidth(90);
            CustomerTable.getColumnModel().getColumn(4).setMaxWidth(90);
            CustomerTable.getColumnModel().getColumn(5).setMinWidth(70);
            CustomerTable.getColumnModel().getColumn(5).setPreferredWidth(70);
            CustomerTable.getColumnModel().getColumn(5).setMaxWidth(70);
        }

        javax.swing.GroupLayout CustomerPanelLayout = new javax.swing.GroupLayout(CustomerPanel);
        CustomerPanel.setLayout(CustomerPanelLayout);
        CustomerPanelLayout.setHorizontalGroup(
            CustomerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CustomerPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(CustomerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(CustomerInformation, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane1)
                    .addComponent(BillingInformation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        CustomerPanelLayout.setVerticalGroup(
            CustomerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CustomerPanelLayout.createSequentialGroup()
                .addComponent(BillingInformation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(CustomerInformation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22))
        );

        ButtonPanel.setBackground(javax.swing.UIManager.getDefaults().getColor("Button.shadow"));

        ClearAllButton.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        ClearAllButton.setMnemonic('C');
        ClearAllButton.setText("Clear All");
        ClearAllButton.setToolTipText("Clear All Details");
        ClearAllButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ClearAllButtonActionPerformed(evt);
            }
        });

        HoldButton.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        HoldButton.setMnemonic('H');
        HoldButton.setText("Hold");
        HoldButton.setToolTipText("Launch New Frame");
        HoldButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                HoldButtonActionPerformed(evt);
            }
        });

        CancelButton.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        CancelButton.setMnemonic('X');
        CancelButton.setText("Cancel");
        CancelButton.setToolTipText("Logout From Current Frame");
        CancelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelButtonActionPerformed(evt);
            }
        });

        DeleteItemFromListButton.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        DeleteItemFromListButton.setMnemonic('D');
        DeleteItemFromListButton.setText("Delete Item From List");
        DeleteItemFromListButton.setToolTipText("Delete Item From List");
        DeleteItemFromListButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        DeleteItemFromListButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteItemFromListButtonActionPerformed(evt);
            }
        });

        BillingAmountInformation.setBackground(javax.swing.UIManager.getDefaults().getColor("Button.light"));

        TotalAmountPayable.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        TotalAmountPayable.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        TotalAmountPayable.setText("Rs 0.00");

        SubTotal.setEditable(false);
        SubTotal.setFocusable(false);

        SubTotalCaption.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        SubTotalCaption.setText("Sub Total");

        NettAmountCaption.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        NettAmountCaption.setText("Nett Amount");

        NettAmount.setEditable(false);
        NettAmount.setFocusable(false);

        AmountPaidByCustomerCaption.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        AmountPaidByCustomerCaption.setText("Amount Paid By");

        AmountPaidToCustomerCaption.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        AmountPaidToCustomerCaption.setText("Amount Returned To Customer");

        AmountPaidToCustomer.setEditable(false);
        AmountPaidToCustomer.setFocusable(false);

        mode.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Cash", "Debit/Credit Card" }));

        AmountPaidByCustomer.setToolTipText("Enter Amount Paid OR Debit/Credit 16-digit Card Number");

        javax.swing.GroupLayout BillingAmountInformationLayout = new javax.swing.GroupLayout(BillingAmountInformation);
        BillingAmountInformation.setLayout(BillingAmountInformationLayout);
        BillingAmountInformationLayout.setHorizontalGroup(
            BillingAmountInformationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(BillingAmountInformationLayout.createSequentialGroup()
                .addGap(194, 194, 194)
                .addComponent(TotalAmountPayable, javax.swing.GroupLayout.PREFERRED_SIZE, 224, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(BillingAmountInformationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(BillingAmountInformationLayout.createSequentialGroup()
                        .addComponent(SubTotalCaption)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(SubTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(BillingAmountInformationLayout.createSequentialGroup()
                        .addGroup(BillingAmountInformationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(NettAmountCaption)
                            .addComponent(AmountPaidByCustomerCaption)
                            .addComponent(AmountPaidToCustomerCaption))
                        .addGap(10, 10, 10)
                        .addGroup(BillingAmountInformationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(AmountPaidByCustomer)
                            .addComponent(mode, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(NettAmount)
                            .addComponent(AmountPaidToCustomer, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        BillingAmountInformationLayout.setVerticalGroup(
            BillingAmountInformationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(BillingAmountInformationLayout.createSequentialGroup()
                .addGroup(BillingAmountInformationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(BillingAmountInformationLayout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addGroup(BillingAmountInformationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(SubTotalCaption)
                            .addComponent(SubTotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(10, 10, 10)
                        .addGroup(BillingAmountInformationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(NettAmountCaption)
                            .addComponent(NettAmount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(BillingAmountInformationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(BillingAmountInformationLayout.createSequentialGroup()
                                .addGap(3, 3, 3)
                                .addComponent(AmountPaidByCustomerCaption))
                            .addComponent(mode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(AmountPaidByCustomer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(BillingAmountInformationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(AmountPaidToCustomerCaption)
                            .addComponent(AmountPaidToCustomer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(BillingAmountInformationLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(TotalAmountPayable, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(50, 50, 50))
        );

        user.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        user.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        PrintLastBillButton.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        PrintLastBillButton.setText("Print");
        PrintLastBillButton.setToolTipText("Print Last Bill");
        PrintLastBillButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PrintLastBillButtonActionPerformed(evt);
            }
        });

        PayBillButton.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        PayBillButton.setMnemonic('P');
        PayBillButton.setText("Pay Bill");
        PayBillButton.setToolTipText("Go For Payment");
        PayBillButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PayBillButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout ButtonPanelLayout = new javax.swing.GroupLayout(ButtonPanel);
        ButtonPanel.setLayout(ButtonPanelLayout);
        ButtonPanelLayout.setHorizontalGroup(
            ButtonPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ButtonPanelLayout.createSequentialGroup()
                .addGroup(ButtonPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(ButtonPanelLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(ClearAllButton, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(DeleteItemFromListButton)
                        .addGap(2, 2, 2)
                        .addComponent(HoldButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(CancelButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(user, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(PrintLastBillButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(PayBillButton))
                    .addGroup(ButtonPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(BillingAmountInformation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        ButtonPanelLayout.setVerticalGroup(
            ButtonPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ButtonPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(BillingAmountInformation, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(ButtonPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(user, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(ButtonPanelLayout.createSequentialGroup()
                        .addGap(0, 1, Short.MAX_VALUE)
                        .addGroup(ButtonPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(PrintLastBillButton)
                            .addComponent(PayBillButton)))
                    .addGroup(ButtonPanelLayout.createSequentialGroup()
                        .addGroup(ButtonPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(ButtonPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(CancelButton)
                                .addComponent(HoldButton)
                                .addComponent(DeleteItemFromListButton))
                            .addComponent(ClearAllButton, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );

        ItemTable.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        ItemTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Item Code", "Description"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        ItemTable.getTableHeader().setReorderingAllowed(false);
        ItemTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ItemTableMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(ItemTable);
        if (ItemTable.getColumnModel().getColumnCount() > 0) {
            ItemTable.getColumnModel().getColumn(0).setResizable(false);
            ItemTable.getColumnModel().getColumn(1).setResizable(false);
        }

        SearchItemCodeCaption.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        SearchItemCodeCaption.setText("Search Item Code");

        ItemCode.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                ItemCodeKeyReleased(evt);
            }
        });

        ItemName.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                ItemNameKeyReleased(evt);
            }
        });

        SearchItemNameCaption.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        SearchItemNameCaption.setText("Search Item Name");

        javax.swing.GroupLayout TransactionPanelLayout = new javax.swing.GroupLayout(TransactionPanel);
        TransactionPanel.setLayout(TransactionPanelLayout);
        TransactionPanelLayout.setHorizontalGroup(
            TransactionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TransactionPanelLayout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(TransactionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(CustomerPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ButtonPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 766, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(13, 13, 13)
                .addGroup(TransactionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 226, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(TransactionPanelLayout.createSequentialGroup()
                        .addGroup(TransactionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(SearchItemCodeCaption)
                            .addComponent(SearchItemNameCaption))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(TransactionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(ItemName)
                            .addComponent(ItemCode, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        TransactionPanelLayout.setVerticalGroup(
            TransactionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TransactionPanelLayout.createSequentialGroup()
                .addGroup(TransactionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(TransactionPanelLayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(CustomerPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 356, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(6, 6, 6)
                        .addComponent(ButtonPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(TransactionPanelLayout.createSequentialGroup()
                        .addGroup(TransactionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(ItemCode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(SearchItemCodeCaption))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(TransactionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(ItemName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(SearchItemNameCaption))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 538, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        TransactionPanelLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {ItemCode, ItemName});

        TabbedPane.addTab("Transaction", TransactionPanel);

        OffersMessage.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        AvailOffersButton.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        AvailOffersButton.setText("Avail Offers");
        AvailOffersButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AvailOffersButtonActionPerformed(evt);
            }
        });

        OfferTable2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        OfferTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "                                          Offers"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        OfferTable2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                OfferTable2MouseClicked(evt);
            }
        });
        jScrollPane9.setViewportView(OfferTable2);

        OfferTable1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        OfferTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "                                          Offers"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        OfferTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                OfferTable1MouseClicked(evt);
            }
        });
        jScrollPane10.setViewportView(OfferTable1);

        OfferTable3.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        OfferTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "                                          Offers"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        OfferTable3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                OfferTable3MouseClicked(evt);
            }
        });
        jScrollPane11.setViewportView(OfferTable3);

        javax.swing.GroupLayout OffersPanelLayout = new javax.swing.GroupLayout(OffersPanel);
        OffersPanel.setLayout(OffersPanelLayout);
        OffersPanelLayout.setHorizontalGroup(
            OffersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(OffersPanelLayout.createSequentialGroup()
                .addGroup(OffersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(OffersPanelLayout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(OffersMessage, javax.swing.GroupLayout.PREFERRED_SIZE, 322, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(519, 519, 519)
                        .addComponent(AvailOffersButton, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(OffersPanelLayout.createSequentialGroup()
                        .addGap(353, 353, 353)
                        .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 305, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, 305, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(36, Short.MAX_VALUE))
            .addGroup(OffersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(OffersPanelLayout.createSequentialGroup()
                    .addGap(27, 27, 27)
                    .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, 305, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(690, Short.MAX_VALUE)))
        );
        OffersPanelLayout.setVerticalGroup(
            OffersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, OffersPanelLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(OffersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane11, javax.swing.GroupLayout.DEFAULT_SIZE, 494, Short.MAX_VALUE)
                    .addComponent(jScrollPane9))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 58, Short.MAX_VALUE)
                .addGroup(OffersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(OffersMessage, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(AvailOffersButton)))
            .addGroup(OffersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(OffersPanelLayout.createSequentialGroup()
                    .addGap(29, 29, 29)
                    .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, 492, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(84, Short.MAX_VALUE)))
        );

        TabbedPane.addTab("Offers", OffersPanel);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(TabbedPane, javax.swing.GroupLayout.PREFERRED_SIZE, 1027, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 20, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(TabbedPane, javax.swing.GroupLayout.PREFERRED_SIZE, 636, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 11, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void ClearAllButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ClearAllButtonActionPerformed
        DefaultTableModel tm = (DefaultTableModel) CustomerTable.getModel();
        tm.setRowCount(0);
        DeleteItemFromListButton.setEnabled(false);
        AmountPaidByCustomer.setText(null);
        mode.setSelectedIndex(0);
        EnteredCode.setText(null);
        quantity.setText(null);
        message.setText(null);
        ItemName.setText(null);
        ItemCode.setText(null);
        CustomerName.setText(null);
        CustomerAddress.setText(null);
        GeneratedCode.setText(null);
        MobileNumber.setText(null);
        City.setText(null);
        SubTotal.setText(null);
        NettAmount.setText(null);
        TotalAmountPayable.setText("Rs 0.00");
        AmountPaidToCustomer.setText(null);
    }//GEN-LAST:event_ClearAllButtonActionPerformed
    private void HoldButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_HoldButtonActionPerformed
        try {
            CustomerFrame newInstance = CustomerFrame.class.newInstance();
            newInstance.setVisible(true);
        } catch (InstantiationException | IllegalAccessException ex) {
            JOptionPane.showMessageDialog(CustomerFrame.this, ex.getMessage(), "Error", 0);
        }
    }//GEN-LAST:event_HoldButtonActionPerformed

    private void CancelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelButtonActionPerformed
        close();
    }//GEN-LAST:event_CancelButtonActionPerformed

    private void DeleteItemFromListButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteItemFromListButtonActionPerformed
        DefaultTableModel tm = (DefaultTableModel) CustomerTable.getModel();
        int row = CustomerTable.getSelectedRow();
        if (row >= 0) {
            tm.removeRow(row);
        }
        int i = 0;
        float te = 0f;
        while (i < tm.getRowCount()) {
            te += (float) tm.getValueAt(i, 5);
            i++;
        }
        i = 0;
        while (i < tm.getRowCount()) {
            tm.setValueAt(i + 1, i, 0);
            i++;
        }
        SubTotal.setText("" + nf.format(te));
        NettAmount.setText("" + Math.round(te));
        TotalAmountPayable.setText("Rs " + nf.format(Float.parseFloat(NettAmount.getText())));
        DeleteItemFromListButton.setEnabled(false);
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        for (i = 0; i < CustomerTable.getColumnCount(); i++) {
            CustomerTable.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }
        quantity.setText(null);
    }//GEN-LAST:event_DeleteItemFromListButtonActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        PrintLastBillButton.setEnabled(false);
        getOffers();
        AvailOffersButton.setEnabled(false);
        DeleteItemFromListButton.setEnabled(false);
        user.setText("Counter Handled By : " + name);
        try {
            connection = DAOConnection.getConnection(storeNumber);
            statement = connection.createStatement();
            resultSet = statement.executeQuery("select code,description from item order by Description");
            DefaultTableModel dtm = (DefaultTableModel) ItemTable.getModel();
            while (resultSet.next()) {
                Object[] newRow = {resultSet.getLong("Code"), resultSet.getString("Description")};
                dtm.addRow(newRow);
            }
            resultSet.close();
            statement.close();
            connection.close();
            if (ItemTable.getRowCount() <= 0) {
                JOptionPane.showMessageDialog(CustomerFrame.this, "No Item In Stock...", "Error", 0);
            }
        } catch (ClassNotFoundException | SQLException | HeadlessException e) {
            message.setText(e.getMessage());
        }
    }//GEN-LAST:event_formWindowOpened

    private void ItemTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ItemTableMouseClicked
        int selectedRow = ItemTable.getSelectedRow();
        if (selectedRow >= 0) {
            long code = (long) ItemTable.getValueAt(selectedRow, 0);
            String itemName = (String) ItemTable.getValueAt(selectedRow, 1);
            int i = 0;
            DefaultTableModel dtm = (DefaultTableModel) CustomerTable.getModel();
            while (i < CustomerTable.getRowCount()) {
                try {
                    if (code == (long) CustomerTable.getValueAt(i, 1)) {
                        float q = (float) CustomerTable.getValueAt(i, 4);
                        q = q + 1;
                        float sellPrice = (float) dtm.getValueAt(i, 3);
                        dtm.setValueAt(q, i, 4);
                        quantity.setText("" + q);
                        String temp = nf.format(sellPrice * q).replace(",", "");

                        float total = Float.parseFloat(temp);
                        dtm.setValueAt(total, i, 5);
                        CustomerTable.setRowSelectionInterval(i, i);
                        CustomerTable.scrollRectToVisible(CustomerTable.getCellRect(i, i, false));
                        align();
                        return;
                    } else {
                        quantity.setText("1.0");
                    }
                } catch (Exception e) {

                }
                i++;
            }
            try {
                connection = DAOConnection.getConnection(0);
                statement = connection.createStatement();
                resultSet = statement.executeQuery("select sell_price from item where code = " + code);
                resultSet.next();
                float sell_price = resultSet.getFloat(1);
                resultSet.close();
                statement.close();
                connection.close();
                float q = 1;
                String temp = nf.format(sell_price * q).replace(",", "");
                float total = Float.parseFloat(temp);
                Object newRow[] = {dtm.getRowCount() + 1, code, itemName, sell_price, q, total};
                dtm.addRow(newRow);
                CustomerTable.setRowSelectionInterval(CustomerTable.getRowCount() - 1, CustomerTable.getRowCount() - 1);
                CustomerTable.scrollRectToVisible(CustomerTable.getCellRect(dtm.getRowCount() - 1, dtm.getRowCount() - 1, false));
                align();
            } catch (ClassNotFoundException | SQLException | NumberFormatException e) {
                JOptionPane.showMessageDialog(CustomerFrame.this, e.getMessage(), "Error", 0);
            }
        }
    }//GEN-LAST:event_ItemTableMouseClicked

    private void PayBillButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PayBillButtonActionPerformed
        if (CustomerTable.getRowCount() <= 0) {
            return;
        }
        String vName = CustomerName.getText().trim();
        String stringCheck = "([a-zA-Z ]+[\\w ]*)";
        String numberCheck = "([0-9]+[0-9]+[0-9]+[0-9]+[0-9]+[0-9]+[0-9]+[0-9]+[0-9]+[0-9])";
        if (vName.length() == 0 || (!(CustomerName.getText().trim().matches(stringCheck)))) {
            if (MobileNumber.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(CustomerFrame.this, "Customer Name required!!!", "Fill Details", 0);
                CustomerName.requestFocus();
                return;
            } else {
                try {
                    String number = MobileNumber.getText().trim();
                    if ((!(number.matches(numberCheck)))) {
                        JOptionPane.showMessageDialog(CustomerFrame.this, "Mobile Number required!!!", "Fill Details", 0);
                        MobileNumber.setText(null);
                        MobileNumber.requestFocus();
                        return;
                    }
                    if (number.length() != 10) {
                        JOptionPane.showMessageDialog(CustomerFrame.this, "Invalid Mobile Number!! If It is a Landline Number Enter the Landline Number without '0'", "Fill Details", 0);
                        MobileNumber.setText(null);
                        MobileNumber.requestFocus();
                        return;
                    }
                    connection = DAOConnection.getConnection(0);
                    preparedStatement = connection.prepareStatement("select Name,Address,City from Customer where Mobile_number = ?");
                    preparedStatement.setString(1, number);
                    resultSet = preparedStatement.executeQuery();
                    if (resultSet.next()) {
                        CustomerName.setText(resultSet.getString("Name"));
                        CustomerAddress.setText(resultSet.getString("Address"));
                        City.setText(resultSet.getString("City"));
                    } else {
                        JOptionPane.showMessageDialog(CustomerFrame.this, "Customer Name required!!!", "Fill Details", 0);
                        CustomerName.requestFocus();
                        resultSet.close();
                        preparedStatement.close();
                        connection.close();
                        return;
                    }
                    resultSet.close();
                    preparedStatement.close();
                    connection.close();
                } catch (ClassNotFoundException | SQLException e) {
                    JOptionPane.showMessageDialog(CustomerFrame.this, e.getMessage(), "Error", 0);
                }
            }
        }
        if ((!(MobileNumber.getText().trim().matches(numberCheck))) || (MobileNumber.getText().trim().length() != 10)) {
            JOptionPane.showMessageDialog(CustomerFrame.this, "Invalid Mobile Number!! If It is a Landline Number Enter the Landline Number without '0'", "Fill Details", 0);
            MobileNumber.setText(null);
            MobileNumber.requestFocus();
            return;
        }
        String number = MobileNumber.getText().trim();
        if ((!(number.matches(numberCheck)))) {
            JOptionPane.showMessageDialog(CustomerFrame.this, "Mobile Number required!!!", "Fill Details", 0);
            MobileNumber.requestFocus();
            return;
        }
        String vMobileNumber = (number);
        String vAddress = CustomerAddress.getText().trim();
        if (vAddress.length() == 0) {
            vAddress = "No Information";
        }
        String vCity = City.getText().trim();
        if (vCity.length() == 0) {
            vCity = "No Information";
        }
        long vCode = 0;
        message.setText(null);
        boolean found = false;
        try {
            connection = DAOConnection.getConnection(storeNumber);
            statement = connection.createStatement();
            r = statement.executeQuery("select * from customer");
            int y = 0;
            while (r.next()) {
                String t = r.getString("Name");
                String m = r.getString("Mobile_Number");
                if (t.equalsIgnoreCase(vName) && m.equals(vMobileNumber)) {
                    found = true;
                    r.close();
                    statement.close();
                    y = 1;
                    break;
                }
                if (!(t.equalsIgnoreCase(CustomerName.getText().trim())) && m.equals(MobileNumber.getText().trim())) {
                    r.close();
                    statement.close();
MobileNumber.requestFocus();
                   throw new Exception("Mobile Number is Of Some Other Customer" + ".Cannot Generate Bill");
                }
            }
            if (y != 1) {
                r.close();
            }
            if (y != 1) {
                statement.close();
            }
            y = 0;
            if (found == true) {
                try {
                    preparedStatement = connection.prepareStatement("select code,Address,City from customer where mobile_number=?");
                    preparedStatement.setString(1, vMobileNumber);
                    resultSet = preparedStatement.executeQuery();
                    resultSet.next();
                    vCode = resultSet.getLong("Code");
                    EnteredCode.setText("" + vCode);
                    String add = resultSet.getString("Address");
                    String cit = resultSet.getString("City");
                    resultSet.close();
                    preparedStatement.close();
                    if (!(add.equalsIgnoreCase(vAddress))) {
                        preparedStatement = connection.prepareStatement("update customer set Address=? where code=?");
                        preparedStatement.setString(1, CustomerAddress.getText().trim());
                        preparedStatement.setLong(2, vCode);
                        preparedStatement.executeUpdate();
                        preparedStatement.close();
                        y++;
                    }
                    if (!(cit.equalsIgnoreCase(vCity))) {
                        preparedStatement = connection.prepareStatement("update customer set City=? where code=?");
                        preparedStatement.setString(1, vCity);
                        preparedStatement.setLong(2, vCode);
                        preparedStatement.executeUpdate();
                        preparedStatement.close();
                        y++;
                    }
                    if (y > 0) {
                        JOptionPane.showMessageDialog(CustomerFrame.this, "Updated Successfully!!!", "Update Successful", 1);
                    }
                } catch (SQLException | HeadlessException e) {
                    JOptionPane.showMessageDialog(CustomerFrame.this, e.getMessage(), "Error", 0);
                }
            }
            if (found == false) {
                try {
                    preparedStatement = connection.prepareStatement("select mobile_number from customer where mobile_number = ?");
                    preparedStatement.setString(1, vMobileNumber);
                    resultSet = preparedStatement.executeQuery();
                    if (resultSet.next()) {
                        resultSet.close();
                        preparedStatement.close();
                        preparedStatement = connection.prepareStatement("update customer set address= ? and city = ? where mobile_number = ?");
                        preparedStatement.setString(1, CustomerAddress.getText().trim());
                        preparedStatement.setString(1, vCity);
                        preparedStatement.setString(3, vMobileNumber);
                        preparedStatement.executeUpdate();
                        preparedStatement.close();
                        JOptionPane.showMessageDialog(CustomerFrame.this, "Updated Successfully!!!", "Update Successful", 1);
                    } else {
                        resultSet.close();
                        preparedStatement.close();
                        preparedStatement = connection.prepareStatement("insert into customer(Name,Address,City,Mobile_Number) values(?,?,?,?)");
                        preparedStatement.setString(1, vName);
                        String as = CustomerAddress.getText().trim();
                        if (as.length() == 0) {
                            as = "No Information";
                        }
                        preparedStatement.setString(2, as);
                        preparedStatement.setString(3, vCity);
                        preparedStatement.setString(4, vMobileNumber);
                        preparedStatement.executeUpdate();
                        y = 0;
                        resultSet = preparedStatement.getGeneratedKeys();
                        if (resultSet.next()) {
                            vCode = resultSet.getLong(1);
                            GeneratedCode.setText("" + vCode);
                            resultSet.close();
                            y = 1;
                            preparedStatement.close();
                            preparedStatement = connection.prepareStatement("update customer set code = ? where mobile_number=?");
                            preparedStatement.setLong(1, vCode);

                            preparedStatement.setString(2, vMobileNumber);
                            preparedStatement.executeUpdate();
                        }
                        if (y != 1) {
                            resultSet.close();
                        }
                        preparedStatement.close();
                        JOptionPane.showMessageDialog(CustomerFrame.this, "Added Successfully!!! With Code :" + vCode, "Update Successful", 1);
                    }
                } catch (SQLException | HeadlessException e) {
                    JOptionPane.showMessageDialog(CustomerFrame.this, e.getMessage(), "Error", 0);
                }
            }
            String datee = date;
            String monthh = month;
            int yearr = year;
            String dateee = datee + "-" + monthh + "-" + yearr;
            int amount = 0;
            long yy = 0L;
            String Mode = (String) mode.getSelectedItem();
            try {
                if (!Mode.equals("Cash")) {
                    yy = Long.parseLong(AmountPaidByCustomer.getText().trim());
                    if (AmountPaidByCustomer.getText().trim().length() != 16) {
                        throw new Exception();
                    }
                } else {
                    amount = Integer.parseInt(AmountPaidByCustomer.getText().trim());
                }
            } catch (Exception e) {
                if (!Mode.equals("Cash")) {
                    JOptionPane.showMessageDialog(CustomerFrame.this, "Enter Debit/Credit Card Number", "Fill Details", 0);
                } else {
                    JOptionPane.showMessageDialog(CustomerFrame.this, "Enter Amount Paid", "Fill Details", 0);
                }
                AmountPaidByCustomer.requestFocus();
                return;
            }
            if (!(EnteredCode.getText().trim().isEmpty())) {
                try {
                    vCode = Long.parseLong(EnteredCode.getText().trim());
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(CustomerFrame.this, "Invalid Code :" + EnteredCode.getText().trim(), "Error", 0);
                    EnteredCode.requestFocus();
                    return;
                }
            } else {
                if (!(GeneratedCode.getText().trim().isEmpty())) {
                    vCode = Long.parseLong(GeneratedCode.getText().trim());
                } else {
                    preparedStatement = connection.prepareStatement("select code from customer where mobile_number=?");

                    preparedStatement.setString(1, vMobileNumber);
                    resultSet = preparedStatement.executeQuery();
                    resultSet.next();
                    vCode = resultSet.getLong(1);
GeneratedCode.setText(""+vCode);
                    resultSet.close();
                    preparedStatement.close();
                }
            }

            int amt = amount;
            int nett = Integer.parseInt(NettAmount.getText());
            int ret = amt - nett;
            if (!Mode.equals("Cash")) {

            } else {
                if (ret < 0) {
                    JOptionPane.showMessageDialog(CustomerFrame.this, "Payment Cannot be less than " + nett, "Fill Details", 0);
                    AmountPaidByCustomer.requestFocus();
                    return;
                }
            }
            preparedStatement = connection.prepareStatement("insert into bill(Bill_Number,Bill_Date,Customer_Code,Billed_Amount,Bill_Payment,Billed_Credit_Debit_Card_Number) values (?,?,?,?,?,?)");
            preparedStatement.setLong(1, Long.parseLong(BillNumberr.getText()));
            preparedStatement.setString(2, dateee);
            preparedStatement.setLong(3, Long.parseLong(GeneratedCode.getText().trim()));
            preparedStatement.setInt(4, Integer.parseInt(NettAmount.getText()));
            preparedStatement.setString(5, Mode);
            if (Mode.equals("Cash")) {
                preparedStatement.setInt(6, amount);
            } else {
                preparedStatement.setLong(6, Long.parseLong(AmountPaidByCustomer.getText().trim()));
            }
            preparedStatement.executeUpdate();
            preparedStatement.close();
            if ((!Mode.equals("Cash"))) {
                AmountPaidToCustomer.setText("NULL");
            } else {
                AmountPaidToCustomer.setText("" + ret);
            }
            preparedStatement = connection.prepareStatement("insert into custominfo values(?,?)");
            preparedStatement.setLong(1, Long.parseLong(BillNumberr.getText()));
            if (!(GeneratedCode.getText().trim().isEmpty())) {
                vCode = Long.parseLong(GeneratedCode.getText().trim());
            } else {
                if (!(EnteredCode.getText().trim().isEmpty())) {
                    vCode = Long.parseLong(EnteredCode.getText().trim());
                }
            }
            DefaultTableModel dtm = (DefaultTableModel) CustomerTable.getModel();
            int i = 0;
            desc = "";
            desc += "*************************************\r\n";
            desc += "-------------------------------------";
            desc += "\r\nSALES BILL\r\n";
            desc += "-------------------------------------\r\n";
            desc += "Staff : " + name;
            desc += "\r\n";
            desc += "Bill Number :" + BillNumberr.getText();
            desc += "\r\n";
            desc += "Customer Code :" + vCode;
            desc += "\r\n";
            desc += "Customer Name :" + vName;
            desc += "\r\n";
            desc += "Mobile Number :" + vMobileNumber;
            desc += "\r\n";
            desc += BillDate.getText();
            desc += "\r\n";
            desc += "-------------------------------------\r\n";
            desc += "Code Desc\tRate  Qty    Total\r\n";
            while (i < dtm.getRowCount()) {

                try {
                    desc += " ";
                    desc += (Long) CustomerTable.getValueAt(i, 1);
                } catch (Exception e) {

                    String hhh = (String) CustomerTable.getValueAt(i, 1);
                    if (hhh.contains("FREE") || hhh.contains("OFFER")) {
                        desc += hhh + " ";
                    }
                }
                desc += "   ";
                String rrr = (String) CustomerTable.getValueAt(i, 2);
                if (rrr.contains("And get")) {

                } else {
                    desc += (String) CustomerTable.getValueAt(i, 2);
                    rrr = (String) CustomerTable.getValueAt(i, 2);
                    if (rrr.length() == 1) {
                        desc += "   ";
                    }
                    if (rrr.length() == 2) {
                        desc += "         ";
                    } else if (rrr.length() != 2) {
                        desc += "\t";
                    }
                }

                desc += (float) CustomerTable.getValueAt(i, 3);
                float rr = (float) CustomerTable.getValueAt(i, 3);
                if (rr >= 0 && rr <= 9) {
                    desc += "     ";
                }
                if (rr < 100 && rr > 9) {
                    desc += "    ";
                }
                if (rr >= 100 && rr <= 999) {
                    desc += "   ";
                }
                if (rr >= 1000) {
                    desc += "  ";
                }
                desc += (float) CustomerTable.getValueAt(i, 4);//quantity
                float qu = (float) CustomerTable.getValueAt(i, 4);//quantity
                String qq = String.valueOf(qu);
                int dot = qq.indexOf(".");
                int digits = qq.codePointCount(dot, qq.length());
                if (digits == 2) {
                    desc += "    ";
                }
                if (digits == 3) {
                    desc += "   ";
                }
                if (digits == 4) {
                    desc += "  ";
                }
                desc += (Float) CustomerTable.getValueAt(i, 5);
                desc += "\r\n";
                i++;
            }
            desc += "-------------------------------------\r\n";
            desc += "Items :" + i;
            String subTotal = SubTotal.getText().replace(",", "");
            Float roundOff = (Float) (Float.parseFloat(NettAmount.getText())) - Float.parseFloat(subTotal);
            String ro = "";

            desc += "            Round Off:" + nf.format(roundOff);
            desc += "\r\n";
            desc += "-------------------------------------\r\n";
            desc += "Nett Amount Payable :...... :" + NettAmount.getText();
            desc += "\r\n";
            if (Mode.equals("Cash")) {
                desc += "Amount Paid By Cash........ :" + amount;
            } else {
                desc += "Debit/Credit Card Number :   " + (AmountPaidByCustomer.getText().trim().substring(12));
            }
            if (Mode.equals("Cash")) {
                desc += "\r\nAmount Returned To Customer : " + ret;
            }
            desc += "\r\n-------------------------------------\r\n";
            i = 0;
            int u = 0;
            int z = 1;
            while (i < CustomerTable.getRowCount()) {
                try {
                    long code = (long) CustomerTable.getValueAt(i, 1);
                    u = 1;
                } catch (Exception e) {
                    String code = (String) CustomerTable.getValueAt(i, 1);
                    String offername = (String) CustomerTable.getValueAt(i, 2);
                    desc += "\r\n" + code + "\r\n" + offername.substring(0, 37);
                    desc += "\r\n" + "             " + offername.substring(37);

                    z = 2;
                }
                i++;
            }
            if (u == 1 && z == 1) {
                desc += "        No Offers Availed!!!";
            }
            desc += "\r\n-------------------------------------\r\n";
            desc += "     Thank You!...Visit Us Again!     \r\n";
            desc += "*************************************\r\n";
            preparedStatement.setString(2, desc);
            preparedStatement.executeUpdate();
            preparedStatement.close();
            i = 0;
            long code = 0;
            while (i < dtm.getRowCount()) {
                try {
                    code = (long) CustomerTable.getValueAt(i, 1);
                } catch (Exception e) {
                    preparedStatement = connection.prepareStatement("select ItemName1,ItemName2,Item1Quantity,Item2Quantity from offers where Offer_Code  = ?");
                    preparedStatement.setString(1, (String) CustomerTable.getValueAt(i, 1));
                    resultSet = preparedStatement.executeQuery();
                    resultSet.next();
                    String item1 = resultSet.getString("ItemName1");
                    String item2 = resultSet.getString("ItemName2");
                    Float item1q = resultSet.getFloat(1);
                    Float item2q = resultSet.getFloat(2);
                    resultSet.close();
                    preparedStatement.close();
                    preparedStatement = connection.prepareStatement("select code from item where description=?");
                    preparedStatement.setString(1, item1);
                    resultSet = preparedStatement.executeQuery();
                    resultSet.next();
                    Long code1 = resultSet.getLong("Code");
                    resultSet.close();
                    preparedStatement.close();
                    preparedStatement = connection.prepareStatement("select code from item where description=?");
                    preparedStatement.setString(1, item2);
                    resultSet = preparedStatement.executeQuery();
                    resultSet.next();
                    Long code2 = resultSet.getLong("Code");
                    resultSet.close();
                    preparedStatement.close();
                    preparedStatement = connection.prepareStatement("select Stock_Left from item where code = ?");
                    preparedStatement.setLong(1, code1);
                    resultSet = preparedStatement.executeQuery();
                    float newStock = 0;
                    float oldStock = 0;
                    if (resultSet.next()) {
                        oldStock = resultSet.getFloat(1);
                    }
                    resultSet.close();
                    preparedStatement.close();
                    float quan = item1q;
                    newStock = oldStock - quan;
                    preparedStatement = connection.prepareStatement("update item set Stock_left=? where code = ?");
                    preparedStatement.setDouble(1, newStock);
                    preparedStatement.setLong(2, code1);
                    preparedStatement.executeUpdate();
                    preparedStatement.close();

                    preparedStatement = connection.prepareStatement("select Stock_Left from item where code = ?");
                    preparedStatement.setLong(1, code2);
                    resultSet = preparedStatement.executeQuery();
                    newStock = 0;
                    oldStock = 0;
                    if (resultSet.next()) {
                        oldStock = resultSet.getFloat(1);
                    }
                    resultSet.close();
                    preparedStatement.close();
                    quan = item2q;
                    newStock = oldStock - quan;
                    preparedStatement = connection.prepareStatement("update item set Stock_left=? where code = ?");
                    preparedStatement.setDouble(1, newStock);
                    preparedStatement.setLong(2, code2);
                    preparedStatement.executeUpdate();
                    preparedStatement.close();
                    i++;
                    continue;
                }
                preparedStatement = connection.prepareStatement("select Stock_Left from item where code = ?");
                preparedStatement.setLong(1, code);
                resultSet = preparedStatement.executeQuery();
                float newStock = 0;
                float oldStock = 0;
                if (resultSet.next()) {
                    oldStock = resultSet.getFloat(1);
                }
                resultSet.close();
                preparedStatement.close();
                float quan = (float) CustomerTable.getValueAt(i, 4);
                newStock = oldStock - quan;
                preparedStatement = connection.prepareStatement("update item set Stock_left=? where code = ?");
                preparedStatement.setDouble(1, newStock);
                preparedStatement.setLong(2, code);
                preparedStatement.executeUpdate();
                preparedStatement.close();
                i++;
            }
            connection.close();
            int oi = 0;
            try {
                connection = DAOConnection.getConnection(storeNumber);
                statement = connection.createStatement();
                resultSet = statement.executeQuery("select count(*) from bill");
                resultSet.next();
                oi = resultSet.getInt(1);
                resultSet.close();
                statement.close();
                connection.close();
            } catch (Exception e) {
                message.setText(e.getMessage());
            }
            try {
                File f = new File("Bill" + oi + ".txt");
                try (RandomAccessFile raf = new RandomAccessFile(f, "rw")) {
                    raf.writeBytes(desc);
                }
            } catch (IOException ee) {
                JOptionPane.showMessageDialog(CustomerFrame.this, ee.getMessage(), "Error", 0);
            }

            JOptionPane.showMessageDialog(CustomerFrame.this, "Payment Successful (Last Paid Bill Number :" + oi + ")", "Payment Successful :" + oi, 1);
	    EnteredCode.setText(null);
            Desktop desktop = Desktop.getDesktop();
            try {
                desktop.print(new File("Bill" + oi + ".txt"));
            } catch (IOException e) {
                JOptionPane.showMessageDialog(CustomerFrame.this, e.getMessage(), "Error", 0);
            }
            PrintLastBillButton.setEnabled(true);
        } catch (Exception exception) {
            JOptionPane.showMessageDialog(CustomerFrame.this, exception.getMessage(), "Error", 0);
        }
    }//GEN-LAST:event_PayBillButtonActionPerformed

    private void EnteredCodeKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_EnteredCodeKeyReleased
        if (evt.getKeyChar() == VK_ENTER) {
            if (EnteredCode.getText().trim().isEmpty()) {
                return;
            }
            try {
                connection = DAOConnection.getConnection(storeNumber);
                preparedStatement = connection.prepareStatement("select * from customer where code = ?");
                preparedStatement.setLong(1, Long.parseLong(EnteredCode.getText().trim()));
                resultSet = preparedStatement.executeQuery();
                if (resultSet.next()) {
                    message.setText(null);
                    CustomerName.setText(null);
                    CustomerAddress.setText(null);
                    City.setText(null);
                    MobileNumber.setText(null);
                    String Name = resultSet.getString("Name");
                    String Address = resultSet.getString("Address");
                    String city = resultSet.getString("City");
                    String mobileNumber = resultSet.getString("Mobile_Number");
                    CustomerName.setText(Name);
                    CustomerAddress.setText(Address);
                    City.setText(city);
                    MobileNumber.setText(mobileNumber);
                    GeneratedCode.setText("" + EnteredCode.getText().trim());
                    EnteredCode.setText(null);
                    ItemName.requestFocus();
                    resultSet.close();
                    preparedStatement.close();
                    connection.close();
                } else {
                    resultSet.close();
                    preparedStatement.close();
                    connection.close();
                    CustomerName.setText(null);
                    CustomerAddress.setText(null);
                    City.setText(null);
                    MobileNumber.setText(null);
                    GeneratedCode.setText(null);
                    throw new Exception("Invalid Code :" + EnteredCode.getText().trim());
                }
            } catch (Exception e) {
                EnteredCode.setText(null);
                JOptionPane.showMessageDialog(CustomerFrame.this, e.getMessage(), "Error", 0);
            }
        }
    }//GEN-LAST:event_EnteredCodeKeyReleased

    private void quantityKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_quantityKeyReleased
        if (CustomerTable.getSelectedRow() < 0) {
            JOptionPane.showMessageDialog(CustomerFrame.this, "Select Item First", "Select Item", 0);
            ItemTable.requestFocus();
            return;
        }
        if (evt.getKeyChar() == VK_ENTER) {
            float q = 0;
            try {
                q = Float.parseFloat(quantity.getText().trim());
                if (q <= 0) {
                    throw new Exception();
                }
            } catch (Exception e) {
                quantity.setText(null);
                JOptionPane.showMessageDialog(CustomerFrame.this, "Enter valid Quantity!!", "Enter valid Quantity", 0);
                quantity.requestFocus();
                return;
            }
            CustomerTable.setValueAt(q, CustomerTable.getSelectedRow(), 4);
            CustomerTable.setValueAt(q, CustomerTable.getSelectedRow(), 4);
            float rate = (float) CustomerTable.getValueAt(CustomerTable.getSelectedRow(), 3);
            float total = Float.parseFloat(nf.format(q * rate).replace(",", ""));
            CustomerTable.setValueAt(total, CustomerTable.getSelectedRow(), 5);
            align();
            ItemTable.requestFocus();
            quantity.setText(null);
        }
    }//GEN-LAST:event_quantityKeyReleased

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        close();
    }//GEN-LAST:event_formWindowClosing

    private void ItemCodeKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ItemCodeKeyReleased
        ItemName.setText(null);
        String itemCode = (ItemCode.getText().trim());
        if (itemCode.length() == 0) {
            return;
        }
        long iCode = 0;
        try {
            iCode = Long.parseLong(itemCode);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(CustomerFrame.this, "Enter Valid Code", "Error", 0);
            ItemCode.setText(null);
            ItemCode.requestFocus();
            return;
        }
        int i = 0;
        while (i < ItemTable.getRowCount()) {
            long c = (Long) ItemTable.getValueAt(i, 0);

            if (c == iCode) {
                ItemTable.setRowSelectionInterval(i, i);
                ItemTable.scrollRectToVisible(ItemTable.getCellRect(i, i, false));
                break;
            }
            i++;
        }
        if (i == ItemTable.getRowCount()) {
            ItemTable.clearSelection();
        }
    }//GEN-LAST:event_ItemCodeKeyReleased

    private void ItemNameKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ItemNameKeyReleased
        int i = 0;
        String itemName = (ItemName.getText().trim());
        if (itemName.length() == 0) {
            return;
        }
        int y = 0;
        int l = 0;
        int a, b;
        while (i < ItemTable.getRowCount()) {
            String desc = (String) ItemTable.getValueAt(i, 1);
            if (itemName.length() <= desc.length()) {
                l = itemName.length();
                y = 0;
                while (y < l) {
                    a = itemName.charAt(y);
                    if (a >= 97 && a <= 122) {
                        a = a - 32;
                    }
                    b = desc.charAt(y);
                    if (b >= 97 && b <= 122) {
                        b = b - 32;
                    }
                    if (a != b) {
                        break;
                    }
                    y++;
                }
                if (y == l) {
                    ItemTable.setRowSelectionInterval(i, i);
                    ItemTable.scrollRectToVisible(ItemTable.getCellRect(i, i, false));
                    message.setText(null);

                    break;
                }
            }

            i++;
        }
        if (i == ItemTable.getRowCount()) {
            ItemTable.clearSelection();
        }
    }//GEN-LAST:event_ItemNameKeyReleased

    private void AvailOffersButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AvailOffersButtonActionPerformed
        int selectedRow = OfferTable1.getSelectedRow();
        if (selectedRow >= 0) {
            avail(OfferTable1);
            OfferTable1.clearSelection();
        } else {
            selectedRow = OfferTable2.getSelectedRow();
            if (selectedRow >= 0) {
                avail(OfferTable2);
                OfferTable2.clearSelection();
            } else {
                selectedRow = OfferTable3.getSelectedRow();
                if (selectedRow >= 0) {
                    avail(OfferTable3);
                    OfferTable3.clearSelection();
                } else {
                    JOptionPane.showMessageDialog(CustomerFrame.this, "Please Select Offer", "Error", 0);
                }
            }
        }
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        for (int i = 0; i < CustomerTable.getColumnCount(); i++) {
            CustomerTable.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }


    }//GEN-LAST:event_AvailOffersButtonActionPerformed

    private void OfferTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_OfferTable1MouseClicked
        int selectedRow = OfferTable1.getSelectedRow();
        if (selectedRow >= 0) {
            AvailOffersButton.setEnabled(true);
        } else {
            AvailOffersButton.setEnabled(false);
        }
    }//GEN-LAST:event_OfferTable1MouseClicked

    private void OfferTable2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_OfferTable2MouseClicked
        int selectedRow = OfferTable2.getSelectedRow();
        if (selectedRow >= 0) {
            AvailOffersButton.setEnabled(true);
        } else {
            AvailOffersButton.setEnabled(false);
        }
    }//GEN-LAST:event_OfferTable2MouseClicked

    private void OfferTable3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_OfferTable3MouseClicked
        int selectedRow = OfferTable3.getSelectedRow();
        if (selectedRow >= 0) {
            AvailOffersButton.setEnabled(true);
        } else {
            AvailOffersButton.setEnabled(false);
        }

    }//GEN-LAST:event_OfferTable3MouseClicked

    private void PrintLastBillButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PrintLastBillButtonActionPerformed
        Desktop desktop = Desktop.getDesktop();
        try {
            connection = DAOConnection.getConnection(storeNumber);
            preparedStatement = connection.prepareStatement("select count(*) from bill");
            resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                Long Bill = resultSet.getLong(1);
                if (Bill != 0) {
                    desktop.print(new File("Bill" + Bill + ".txt"));
                } else {
                    JOptionPane.showMessageDialog(CustomerFrame.this, "No Last Bill to Print", "Error", 0);
                }

            }
            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (ClassNotFoundException | SQLException | IOException e) {
            JOptionPane.showMessageDialog(CustomerFrame.this, e.getMessage(), "Error", 0);
        }
    }//GEN-LAST:event_PrintLastBillButtonActionPerformed

    private void MobileNumberKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_MobileNumberKeyReleased
        if (evt.getKeyCode() == VK_ENTER) {
            String numberCheck = "([0-9]+[0-9]+[0-9]+[0-9]+[0-9]+[0-9]+[0-9]+[0-9]+[0-9]+[0-9])";
            String number = MobileNumber.getText().trim();
            if ((!(number.matches(numberCheck)))) {
                JOptionPane.showMessageDialog(CustomerFrame.this, "Mobile Number required!!!", "Fill Details", 0);
                MobileNumber.setText(null);
                MobileNumber.requestFocus();
                return;
            }
            try {
                connection = DAOConnection.getConnection(0);
                statement = connection.createStatement();
                resultSet = statement.executeQuery("select code,name,address,city from customer where mobile_number=" + number);
                if (resultSet.next()) {
                    GeneratedCode.setText("" + resultSet.getLong("code"));
                    CustomerName.setText(resultSet.getString("name"));
                    CustomerAddress.setText(resultSet.getString("address"));
                    City.setText(resultSet.getString("city"));
                } else {
                    EnteredCode.setText(null);
                    GeneratedCode.setText(null);
                    CustomerName.setText(null);
                    CustomerAddress.setText(null);
                    City.setText(null);
                    CustomerName.requestFocus();
                }
                resultSet.close();
                statement.close();
                connection.close();
            } catch (ClassNotFoundException | SQLException ex) {
                JOptionPane.showMessageDialog(CustomerFrame.this, ex.getMessage(), "Error", 0);
            }
        }
    }//GEN-LAST:event_MobileNumberKeyReleased

    private void CustomerTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CustomerTableMouseClicked
int selectedRow=CustomerTable.getSelectedRow();
if(selectedRow>=0)
{
quantity.setText(""+CustomerTable.getValueAt(selectedRow,4));
quantity.requestFocus();
}
    }//GEN-LAST:event_CustomerTableMouseClicked

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CustomerFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CustomerFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CustomerFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CustomerFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CustomerFrame(args[0], 0).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField AmountPaidByCustomer;
    private javax.swing.JLabel AmountPaidByCustomerCaption;
    private javax.swing.JTextField AmountPaidToCustomer;
    private javax.swing.JLabel AmountPaidToCustomerCaption;
    private javax.swing.JButton AvailOffersButton;
    public static javax.swing.JLabel BillDate;
    private javax.swing.JLabel BillDateCaption;
    private javax.swing.JLabel BillNumberCaption;
    public static javax.swing.JTextField BillNumberr;
    private javax.swing.JPanel BillingAmountInformation;
    private javax.swing.JPanel BillingInformation;
    private javax.swing.JPanel ButtonPanel;
    private javax.swing.JButton CancelButton;
    private javax.swing.JTextField City;
    private javax.swing.JLabel CityCaption;
    private javax.swing.JButton ClearAllButton;
    private javax.swing.JLabel CodeCaption;
    private javax.swing.JTextField CustomerAddress;
    private javax.swing.JLabel CustomerAddressCaption;
    private javax.swing.JPanel CustomerInformation;
    private javax.swing.JTextField CustomerName;
    private javax.swing.JLabel CustomerNameCaption;
    private javax.swing.JPanel CustomerPanel;
    private javax.swing.JTable CustomerTable;
    private javax.swing.JButton DeleteItemFromListButton;
    public static javax.swing.JTextField EnteredCode;
    private javax.swing.JLabel EnteredCodeCaption;
    private javax.swing.JOptionPane Exit;
    public static javax.swing.JTextField GeneratedCode;
    private javax.swing.JButton HoldButton;
    private javax.swing.JPanel InformationPanel;
    private javax.swing.JTextField ItemCode;
    private javax.swing.JTextField ItemName;
    private javax.swing.JTable ItemTable;
    private javax.swing.JTextField MobileNumber;
    private javax.swing.JLabel MobileNumberCaption;
    private javax.swing.JTextField NettAmount;
    private javax.swing.JLabel NettAmountCaption;
    private javax.swing.JTable OfferTable1;
    private javax.swing.JTable OfferTable2;
    private javax.swing.JTable OfferTable3;
    private javax.swing.JLabel OffersMessage;
    private javax.swing.JPanel OffersPanel;
    private javax.swing.JButton PayBillButton;
    private javax.swing.JButton PrintLastBillButton;
    private javax.swing.JLabel SalesBillCaption;
    private javax.swing.JLabel SearchItemCodeCaption;
    private javax.swing.JLabel SearchItemNameCaption;
    private javax.swing.JSeparator SeparatorBetweenBillNumberrAndBillDate;
    private javax.swing.JSeparator SeparatorBetweenSalesBillAndBillNumber;
    private javax.swing.JTextField SubTotal;
    private javax.swing.JLabel SubTotalCaption;
    private javax.swing.JTabbedPane TabbedPane;
    private javax.swing.JLabel TotalAmountPayable;
    private javax.swing.JPanel TransactionPanel;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane9;
    public static javax.swing.JLabel message;
    private javax.swing.JComboBox mode;
    private javax.swing.JTextField quantity;
    private javax.swing.JLabel user;
    // End of variables declaration//GEN-END:variables

    private void getOffers() {
        try {
            connection = DAOConnection.getConnection(storeNumber);
            preparedStatement = connection.prepareStatement("select count(*) from offers");
            resultSet = preparedStatement.executeQuery();
            resultSet.next();
            if (resultSet.getLong(1) <= 0) {
                resultSet.close();
                preparedStatement.close();
                connection.close();
                OffersMessage.setText("No Offers!");
                return;
            }
            Long countOffers = resultSet.getLong(1);
            JOptionPane.showMessageDialog(CustomerFrame.this, "Total Available Offers : " + countOffers, "Information", 1);
            OffersMessage.setText("Total Available Offers : " + countOffers);
            resultSet.close();
            preparedStatement.close();
            preparedStatement = connection.prepareStatement("select description from offers order by ItemName1");
            resultSet = preparedStatement.executeQuery();
            DefaultTableModel dtm1 = (DefaultTableModel) OfferTable1.getModel();
            dtm1.setRowCount(0);
            while (resultSet.next()) {
                Object rowData[] = {resultSet.getString("Description")};
                dtm1.addRow(rowData);
                if (dtm1.getRowCount() > 29) {
                    break;
                }
            }

            DefaultTableModel dtm2 = (DefaultTableModel) OfferTable2.getModel();
            while (resultSet.next()) {
                Object rowData[] = {resultSet.getString("Description")};
                dtm2.addRow(rowData);
                if (dtm2.getRowCount() > 29) {
                    break;
                }
            }
            DefaultTableModel dtm3 = (DefaultTableModel) OfferTable3.getModel();
            while (resultSet.next()) {
                Object rowData[] = {resultSet.getString("Description")};
                dtm3.addRow(rowData);
            }

            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (ClassNotFoundException | SQLException ex) {
            JOptionPane.showMessageDialog(CustomerFrame.this, ex.getMessage(), "Error", 0);

        }
    }

    private void avail(javax.swing.JTable OfferTable) {
        int selectedRow = OfferTable.getSelectedRow();

        if (selectedRow >= 0) {
            String offer = (String) OfferTable.getValueAt(selectedRow, 0);
            int i = 0;
            /*  while (i < CustomerTable.getRowCount()) {
             if (offer.endsWith((String) CustomerTable.getValueAt(i, 2))) {
             JOptionPane.showMessageDialog(CustomerFrame.this, "Cannot Select Existing Offer");
             return;
             }
             i++;
             }*/
            try {
                connection = DAOConnection.getConnection(storeNumber);
                statement = connection.createStatement();
                resultSet = statement.executeQuery("select Offer_Code,Description,ItemName1,ItemName2,Rate from offers order by ItemName1");
                String offer_code = "";
                String itemName1 = "";
                String itemName2 = "";
                String desc = "";
                Float rate = 0F;
                while (resultSet.next()) {
                    offer_code = resultSet.getString("Offer_Code");
                    desc = resultSet.getString("Description");
                    if (desc.matches(offer)) {
                        itemName1 = resultSet.getString("ItemName1");
                        itemName2 = resultSet.getString("ItemName2");
                        rate = resultSet.getFloat("Rate");
                        break;
                    }

                }
                String stock1 = offer.substring(4);
                char s1[] = stock1.toCharArray();

                stock1 = "";
                while (i < s1.length) {
                    if (s1[i] == ' ') {
                        break;
                    }
                    stock1 += s1[i];
                    i++;
                }
                char s11[] = stock1.toCharArray();
                i = 0;
                stock1 = "";
                while (i < s11.length) {
                    if (!(s11[i] >= '0' && s11[i] <= '9')) {
                        break;
                    }
                    stock1 += s11[i];
                    i++;
                }
                int t = offer.lastIndexOf(itemName2);
                char off[] = offer.toCharArray();
                String temp = "";
                t--;
                while (t > 0) {
                    if (!((off[t] >= '0' && off[t] <= '9') || (off[t] == ' '))) {
                        break;
                    }
                    temp += off[t];
                    t--;
                }
                temp = temp.trim();
                StringBuffer a = new StringBuffer(temp);
                a = a.reverse();
                String stock2 = a.toString();
                resultSet.close();
                statement.close();
                connection.close();
                DefaultTableModel dtm = (DefaultTableModel) CustomerTable.getModel();
                float quantit = 1;
                i = 0;
                float te;
                te = rate * quantit;
                Object[] rowData = {dtm.getRowCount() + 1, offer_code, "Avail Offer :" + desc, rate, quantit, te};
                dtm.addRow(rowData);

                align();
                AvailOffersButton.setEnabled(false);
                JOptionPane.showMessageDialog(CustomerFrame.this, "Offer Added To Current Transaction", "Offer Availed", 1);
                TabbedPane.setSelectedIndex(0);
            } catch (SQLException | ClassNotFoundException ex) {
                JOptionPane.showMessageDialog(CustomerFrame.this, ex.getMessage(), "Error", 0);
            }

        }
    }

    private void align() {

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        for (int i = 0; i < CustomerTable.getColumnCount(); i++) {
            CustomerTable.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }
        float tott = 0;
        if (CustomerTable.getRowCount() > 0) {
            int i = 0;
            while (i < CustomerTable.getRowCount()) {
                tott += (Float) CustomerTable.getValueAt(i, 5);
                i++;
            }
        }
        SubTotal.setText("" + nf.format(tott));
        NettAmount.setText("" + Math.round(tott));
        TotalAmountPayable.setText("Rs " + nf.format(Float.parseFloat(NettAmount.getText())));
    }

    private void close() {

        int showConfirmDialog = Exit.showConfirmDialog(CustomerFrame.this, "Are you Sure to Exit the Current Frame?", "Close Transaction?", 0);

        if (showConfirmDialog == JOptionPane.NO_OPTION) {
            i = 1;
        }
        if (showConfirmDialog == JOptionPane.YES_OPTION) {
            open--;
            if (open <= 0) {
                String info = name + " Logged Out";
                Utility.setConsoleLogging(true);
                Utility.addToLog(info);
                new LoginFrame().setVisible(true);
            }
            CustomerFrame.this.dispose();
        }
    }
}
