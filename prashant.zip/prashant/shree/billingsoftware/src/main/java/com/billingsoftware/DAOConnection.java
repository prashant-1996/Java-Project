package com.billingsoftware;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class DAOConnection {

    private DAOConnection() {

    }

    public static Connection getConnection(int number) throws ClassNotFoundException {
        Connection connection = null;
        try {
            String classPath = "jdbc:sqlite:";
            String root = System.getenv("HOMEDRIVE");
            File f = new File(root + "/Database");
            if (f.exists() == false) {
                f.mkdirs();
            }
            classPath += root;
            Class.forName("org.sqlite.JDBC");

             if (number != 0) {

             connection = DriverManager.getConnection(classPath + "/Database/info" + number + ".db");
             } else {
             connection = DriverManager.getConnection(classPath + "/Database/info.db");
             }
//            Class.forName("com.mysql.jdbc.Driver");
  //          connection = DriverManager.getConnection("jdbc:mysql://www.vappcollege.com/billingsoftware", "billingsoftwareu","billingsoftwarep");
        } catch (ClassNotFoundException | SQLException exception) {
            JOptionPane.showMessageDialog(null, exception, "Error", 0);
            System.out.println(exception);
        }

        return connection;
    }
    public static void main(String gg[])
    {
        try{
            DAOConnection.getConnection(0);
        }catch(Exception e)
        {
        
        }
    
    }
}
