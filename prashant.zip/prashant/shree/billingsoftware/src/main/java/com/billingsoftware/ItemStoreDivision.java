package com.billingsoftware;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class ItemStoreDivision extends javax.swing.JFrame {

    public ItemStoreDivision() {
        initComponents();
    }
public void updateupdate() {
        try {
            Connection connection = DAOConnection.getConnection(0);
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("select code,description,stock_left from item order by description");
            DefaultTableModel dtm = (DefaultTableModel) jTable1.getModel();
            dtm.setRowCount(0);
            while (resultSet.next()) {
                Object newRow[] = {resultSet.getLong(1), resultSet.getString(2), resultSet.getFloat(3)};
                dtm.addRow(newRow);
            }
            resultSet.close();
            statement.close();
            connection.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(ItemStoreDivision.this, e.getMessage(), "Error", 0);
        }
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jTextField1 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
jLabel4.setFont(new java.awt.Font("Times New Roman", 0, 18));
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
setSize(640,640);

        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });
        getContentPane().setLayout(new java.awt.GridBagLayout());

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "     Code", "Description", "Stock Left"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridheight = 9;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.ipadx = 157;
        gridBagConstraints.ipady = 309;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 11, 0);
        getContentPane().add(jScrollPane1, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.gridheight = 2;
        gridBagConstraints.ipadx = 86;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(21, 34, 0, 0);
        getContentPane().add(jTextField1, gridBagConstraints);

        jLabel1.setText("Store 1");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.ipadx = 24;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(24, 26, 0, 0);
        getContentPane().add(jLabel1, gridBagConstraints);

        jLabel2.setText("Store 2");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.ipadx = 24;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(38, 26, 0, 0);
        getContentPane().add(jLabel2, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.gridheight = 2;
        gridBagConstraints.ipadx = 86;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(35, 34, 0, 0);
        getContentPane().add(jTextField2, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.gridheight = 2;
        gridBagConstraints.ipadx = 86;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(35, 34, 0, 0);
        getContentPane().add(jTextField3, gridBagConstraints);

        jLabel3.setText("Store 3");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.ipadx = 24;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(38, 26, 0, 0);
        getContentPane().add(jLabel3, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 4;
        gridBagConstraints.ipadx = 196;
        gridBagConstraints.ipady = 74;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(11, 26, 0, 20);
        getContentPane().add(jLabel4, gridBagConstraints);

        jButton1.setText("Save");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 7;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(43, 38, 0, 0);
        getContentPane().add(jButton1, gridBagConstraints);

    }// </editor-fold>//GEN-END:initComponents

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        int selectedRow = jTable1.getSelectedRow();

        try {
            Connection connection = DAOConnection.getConnection(0);
            PreparedStatement preparedStatement = connection.prepareStatement("select stock_left from item1 where description = ?");
            preparedStatement.setString(1, (String) jTable1.getValueAt(selectedRow, 1));
            ResultSet resultSet = preparedStatement.executeQuery();
jLabel4.setText(""+jTable1.getValueAt(selectedRow,1));
            float s1 = 0, s2 = 0, s3 = 0;
            if (resultSet.next()) {
                s1 = resultSet.getFloat(1);
                jTextField1.setText("" + s1);
            }
            resultSet.close();
            preparedStatement.close();
            preparedStatement = connection.prepareStatement("select stock_left from item2 where description = ?");
            preparedStatement.setString(1, (String) jTable1.getValueAt(selectedRow, 1));
            resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                s2 = resultSet.getFloat(1);
                jTextField2.setText("" + s2);
            }
            resultSet.close();
            preparedStatement.close();
            preparedStatement = connection.prepareStatement("select stock_left from item3 where description = ?");
            preparedStatement.setString(1, (String) jTable1.getValueAt(selectedRow, 1));
            resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                s3 = resultSet.getFloat(1);
                jTextField3.setText("" + s3);
            }
            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(ItemStoreDivision.this, e.getMessage(), "Error", 0);
        }
    }//GEN-LAST:event_jTable1MouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
 float s1 = 0;
        float s2 = 0;
        float s3 = 0;
        try {
            s1 = Float.parseFloat(jTextField1.getText().trim());
            if (s1 < 0) {
                throw new Exception("Invalid Number");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(ItemStoreDivision.this, e.getMessage(), "Error", 0);
            jTextField1.requestFocus();
            return;
        }
        try {
            s2 = Float.parseFloat(jTextField2.getText().trim());
            if (s2 < 0) {
                throw new Exception("Invalid Number");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(ItemStoreDivision.this, e.getMessage(), "Error", 0);
            jTextField2.requestFocus();
            return;
        }
        try {
            s3 = Float.parseFloat(jTextField3.getText().trim());
            if (s3 < 0) {
                throw new Exception("Invalid Number");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(ItemStoreDivision.this, e.getMessage(), "Error", 0);
            jTextField3.requestFocus();
            return;
        }

        float total = s1 + s2 + s3;
        float left = (float) jTable1.getValueAt(jTable1.getSelectedRow(), 2);
        if (left < total) {
            JOptionPane.showMessageDialog(ItemStoreDivision.this, "Distribution exceeds the limit", "Error", 0);
            return;
        }
        try {
            Connection connection = DAOConnection.getConnection(0);
            PreparedStatement preparedStatement = connection.prepareStatement("update item1 set stock_left =? where description  = ?");
            preparedStatement.setFloat(1, s1);
            preparedStatement.setString(2, (String) jTable1.getValueAt(jTable1.getSelectedRow(), 1));
            preparedStatement.executeUpdate();
            preparedStatement.close();
            preparedStatement = connection.prepareStatement("update item2 set stock_left =? where description = ?");
            preparedStatement.setFloat(1, s2);
            preparedStatement.setString(2, (String) jTable1.getValueAt(jTable1.getSelectedRow(), 1));
            preparedStatement.executeUpdate();
            preparedStatement.close();
            preparedStatement = connection.prepareStatement("update item3 set stock_left =? where description = ?");
            preparedStatement.setFloat(1, s3);
            preparedStatement.setString(2, (String) jTable1.getValueAt(jTable1.getSelectedRow(), 1));
            preparedStatement.executeUpdate();
            preparedStatement.close();
            connection.close();
            updateupdate();
            JOptionPane.showMessageDialog(ItemStoreDivision.this, "Update Success");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(ItemStoreDivision.this, "Update Failed", "Error", 0);
        }        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
      updateupdate();  // TODO add your handling code here:
    }//GEN-LAST:event_formWindowOpened

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        ItemStoreDivision.this.dispose();        
new AdminPanel().setVisible(true);
    }//GEN-LAST:event_formWindowClosing

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ItemStoreDivision.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ItemStoreDivision.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ItemStoreDivision.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ItemStoreDivision.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ItemStoreDivision().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    // End of variables declaration//GEN-END:variables
}
