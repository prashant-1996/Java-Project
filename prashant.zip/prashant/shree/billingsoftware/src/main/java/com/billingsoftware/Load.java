package com.billingsoftware;

import java.awt.AWTException;
import java.awt.Image;
import java.awt.MenuItem;
import java.awt.PopupMenu;
import java.awt.SystemTray;
import java.awt.TrayIcon;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class Load implements Resources {

    private static int open;
    static PopupMenu popup;
    static TrayIcon trayIcon;
    static SystemTray tray;
    static MenuItem exitItem;
    static MenuItem newTransaction;

    Load() {
        createAndShowGUI();
        open++;
    }

    public static void main(String[] args) {
        try {
            if (Integer.parseInt(args[0]) == 1) {
                tray.remove(trayIcon);
            } else {
                try {
                    for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                        if ("Windows".equals(info.getName())) {
                            javax.swing.UIManager.setLookAndFeel(info.getClassName());
                            break;
                        }
                    }
                } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
                }
                /* Turn off metal's use of bold fonts */
                UIManager.put("swing.boldMetal", Boolean.FALSE);
        //Schedule a job for the event-dispatching thread:
                //adding TrayIcon.
                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        createAndShowGUI();
                    }
                });

            }
        } catch (Exception e) {

        }
    }

    private static void createAndShowGUI() {
        //Check the SystemTray support
        if (!SystemTray.isSupported()) {
            JOptionPane.showMessageDialog(null, "SystemTray is not supported");
            return;
        }
        popup = new PopupMenu();
        trayIcon = new TrayIcon(createImage(TRANSACTION_ICON_1, "tray icon"));
        tray = SystemTray.getSystemTray();
        exitItem = new MenuItem("Exit");
        popup.add(exitItem);
        trayIcon.setPopupMenu(popup);
        if (CustomerFrame.open > 0) {
            newTransaction = new MenuItem("New Transaction");
            popup.add(newTransaction);
            newTransaction.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    String k[] = {CustomerFrame.name};
                    CustomerFrame.main(k);
                }
            });
        }
        try {
            tray.add(trayIcon);
        } catch (AWTException e) {
            JOptionPane.showMessageDialog(null, "TrayIcon could not be added.");
            return;
        }

        trayIcon.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                //JOptionPane.showMessageDialog(null, "This dialog box is run from System Tray");
                if (CustomerFrame.open > 0) {
                    String k[] = {CustomerFrame.name};
                    CustomerFrame.main(k);
                } else {
                    if (AdminPanel.open == 0) {
                        String k[] = {AdminPanel.username};
                        AdminPanel.main(k);
                    }
                }
            }
        });

        trayIcon.setImageAutoSize(true);
        trayIcon.setToolTip("BillingSoftware is currently running!");
        trayIcon.displayMessage("BillingSoftware", "BillingSoftware is currently running!", TrayIcon.MessageType.NONE);
        exitItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                tray.remove(trayIcon);
                System.exit(0);
            }
        });
    }

    protected static Image createImage(String path, String description) {
        URL imageURL = Load.class.getResource(path);
        if (imageURL == null) {
            JOptionPane.showMessageDialog(null, "Resource not found: " + path);
            return null;
        } else {
            return (new ImageIcon(imageURL, description)).getImage();
        }
    }

}
