package com.billingsoftware;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.SplashScreen;
import static java.awt.SplashScreen.getSplashScreen;
import static java.awt.event.KeyEvent.VK_ENTER;
import static java.lang.Thread.sleep;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.io.File;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;

public class LoginFrame extends javax.swing.JFrame implements Resources {

    static void renderSplashFrame(Graphics2D g, int frame) {
        final String[] comps = {""};
        g.setComposite(AlphaComposite.Clear);
        g.fillRect(120, 140, 200, 40);
        g.setPaintMode();
        g.setColor(Color.BLACK);
        g.drawString(" " + comps[(frame / 5) % 1] + "...", 120, 150);
    }

    public LoginFrame() {
        String root = System.getenv("HOMEDRIVE");
        File f = new File(root + "/Database/");
        if (f.exists() == false) {
            f.mkdirs();
        }
        initComponents();
        LoginFrame.this.setIconImage(new ImageIcon(getClass().getResource(APPLICATION_ICON)).getImage());
        final SplashScreen splash = getSplashScreen();
        if (splash == null) {
            return;
        }
        Graphics2D g = splash.createGraphics();
        if (g == null) {
            return;
        }
        for (int i = 0; i < 100; i++) {
            renderSplashFrame(g, i);
            splash.update();
            try {
                sleep(10);
            } catch (InterruptedException e) {
                System.out.println(e.getMessage());
            }
        }
        splash.close();
        toFront();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        exitDialog = new javax.swing.JDialog();
Dimension dimension=Toolkit.getDefaultToolkit().getScreenSize();
exitDialog.setLocation(dimension.width/2-getWidth()/2,dimension.height/2-getHeight()/2);
        jLabel2 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jOptionPane1 = new javax.swing.JOptionPane();
        ResetButton = new javax.swing.JButton();
        ExitButton = new javax.swing.JButton();
        passwordCaption = new javax.swing.JLabel();
        usernameCaption = new javax.swing.JLabel();
        username = new javax.swing.JTextField();
        TimeCaption = new javax.swing.JLabel();
        LoginButton = new javax.swing.JButton();
        password = new javax.swing.JPasswordField();
        jLabel1 = new javax.swing.JLabel();
        DayCaption = new javax.swing.JLabel();

        exitDialog.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        exitDialog.setTitle("THANKS FOR USING THIS APP");
        exitDialog.setAlwaysOnTop(true);
        exitDialog.setIconImage(null);
        exitDialog.setMinimumSize(new java.awt.Dimension(357, 249));
        exitDialog.setModalExclusionType(java.awt.Dialog.ModalExclusionType.TOOLKIT_EXCLUDE);
        exitDialog.setModalityType(java.awt.Dialog.ModalityType.APPLICATION_MODAL);
        exitDialog.setResizable(false);
        exitDialog.setType(java.awt.Window.Type.UTILITY);
        exitDialog.getContentPane().setLayout(new java.awt.GridBagLayout());
        exitDialog.getContentPane().add(jLabel2, new java.awt.GridBagConstraints());

        jPanel3.setToolTipText("Thank You!!");
        jPanel3.setMinimumSize(new java.awt.Dimension(205, 200));
        jPanel3.setLayout(new java.awt.GridBagLayout());

        jLabel3.setText("Thank You for Using This Application");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.ipadx = 22;
        gridBagConstraints.ipady = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(11, 10, 0, 0);
        jPanel3.add(jLabel3, gridBagConstraints);

        jLabel4.setText("Programmed by Prashant Upadhyay ");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.ipadx = 38;
        gridBagConstraints.ipady = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(6, 10, 0, 0);
        jPanel3.add(jLabel4, gridBagConstraints);

        jLabel5.setText("See You Soon!!!");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.ipadx = 117;
        gridBagConstraints.ipady = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(6, 10, 49, 0);
        jPanel3.add(jLabel5, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(19, 4, 30, 10);
        exitDialog.getContentPane().add(jPanel3, gridBagConstraints);

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Login");
        setResizable(false);

        ResetButton.setMnemonic('R');
        ResetButton.setText("Reset");
        ResetButton.setToolTipText("Click Here To Reset Fields");
        ResetButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ResetButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ResetButtonActionPerformed(evt);
            }
        });

        ExitButton.setMnemonic('X');
        ExitButton.setText("Exit");
        ExitButton.setToolTipText("Click Here To Exit");
        ExitButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ExitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExitButtonActionPerformed(evt);
            }
        });

        passwordCaption.setText("Enter Password");
        usernameCaption.setText("Enter Username");
        username.setToolTipText("Enter Username");
        username.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                usernameFocusGained(evt);
            }
        });

        LoginButton.setMnemonic('L');
        LoginButton.setText("Login");
        LoginButton.setToolTipText("Click Here To Login");
        LoginButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        LoginButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LoginButtonActionPerformed(evt);
            }
        });

        password.setToolTipText("Enter Password");
        password.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                passwordFocusGained(evt);
            }
        });
        password.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                passwordKeyReleased(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel1.setText("Billing Software");
        jLabel1.setVerticalAlignment(javax.swing.SwingConstants.TOP);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 123, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(usernameCaption)
                                        .addGap(36, 36, 36)
                                        .addComponent(username, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(passwordCaption)
                                        .addGap(38, 38, 38)
                                        .addComponent(password, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(LoginButton)
                                        .addGap(18, 18, 18)
                                        .addComponent(ResetButton)
                                        .addGap(18, 18, 18)
                                        .addComponent(ExitButton)))
                                .addGap(97, 97, 97))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addGap(107, 107, 107))))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(TimeCaption, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(DayCaption, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addComponent(jLabel1)
                .addGap(52, 52, 52)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addComponent(usernameCaption))
                    .addComponent(username, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addComponent(passwordCaption))
                    .addComponent(password, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(LoginButton)
                    .addComponent(ResetButton)
                    .addComponent(ExitButton))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 55, Short.MAX_VALUE)
                .addComponent(TimeCaption, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(DayCaption, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void ExitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExitButtonActionPerformed
        LoginFrame.this.dispose();
        exitDialog.show();
        Utility.setConsoleLogging(true);
        Utility.addToLog("Application terminated Normally");
        System.exit(0);
    }//GEN-LAST:event_ExitButtonActionPerformed

    private void ResetButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ResetButtonActionPerformed
        username.setText(null);
        password.setText(null);
        username.requestFocus();
    }//GEN-LAST:event_ResetButtonActionPerformed

    private void LoginButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LoginButtonActionPerformed
        String root = System.getenv("HOMEDRIVE");
        File f = new File(root + "/Database/info.db");
        if (f.length() == 0) {
            Toolkit.getDefaultToolkit().beep();
            jOptionPane1.showMessageDialog(LoginFrame.this, "Missing Database.Check Database File(info.db) in (Windows Root)/Database/ with size>=16KB", "Error", 0);
            return;
        }
        if (username.getText().trim().isEmpty()) {
            username.setText(null);
            username.requestFocus();
            JOptionPane.showMessageDialog(LoginFrame.this, "Enter Username!", "Fill Details", 0);
            return;
        }
        if (password.getText().isEmpty()) {
            JOptionPane.showMessageDialog(LoginFrame.this, "Enter Password!", "Fill Details", 0);

            password.setText(null);
            password.requestFocus();
            return;
        }
        int z = 0;
        try {
            Connection connection = DAOConnection.getConnection(0);
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("select * from users");
            String user = null;
            String pass = null;
            while (resultSet.next()) {
                user = resultSet.getString("username");
                pass = resultSet.getString("password");
                int c = resultSet.getInt(3);
                if (user.equals(username.getText().trim()) && pass.equals(password.getText())) {
                    if (c != 1) {
                        z = 1;
                    } else {
                        z = 2;
                    }
                    break;
                }
            }
            if (z == 1) {
                resultSet.close();
                statement.close();
                connection.close();
                Utility.setConsoleLogging(true);
                String info;
                info = username.getText().trim() + " Logged in.";
                Utility.addToLog(info);
                new AdminPanel(username.getText()).setVisible(true);
                new Load();
                LoginFrame.this.dispose();
            } else {
                if (z == 2) {
                    resultSet.close();
                    statement.close();
                    connection.close();
                    Utility.setConsoleLogging(true);
                    String info;
                    info = username.getText().trim() + " Logged in.";
                    Utility.addToLog(info);
                    new CustomerFrame(username.getText().trim(), 0).setVisible(true);
                    new Load();
                    LoginFrame.this.dispose();

                } else {
                    resultSet.close();
                    statement.close();
                    connection.close();
                    Utility.setConsoleLogging(true);
                    String info;
                    info = "Someone tried to Log into Software with Credentials :" + username.getText().trim() + " and " + password.getText();
                    Utility.addToLog(info);
                    jOptionPane1.showMessageDialog(LoginFrame.this, "Please Login With Correct Credentials", "Invalid Login Credentials", 0);
                }
            }
        } catch (Exception e) {
            if (e.getMessage().contains("missing database")) {
                Toolkit.getDefaultToolkit().beep();

                jOptionPane1.showMessageDialog(LoginFrame.this, "Missing Database.Check Database File(info.db) in (Windows Root)/Database/ with size>=16KB", "Error", 0);
            } else {
                jOptionPane1.showMessageDialog(LoginFrame.this, e.getMessage(), "Error", 0);
            }
        }
    }//GEN-LAST:event_LoginButtonActionPerformed

    private void usernameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_usernameFocusGained
        username.selectAll();
    }//GEN-LAST:event_usernameFocusGained

    private void passwordFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_passwordFocusGained
        password.selectAll();
    }//GEN-LAST:event_passwordFocusGained

    private void passwordKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_passwordKeyReleased
        if (evt.getKeyChar() == VK_ENTER) {
            LoginButton.doClick();
        }
    }//GEN-LAST:event_passwordKeyReleased
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
try
{
}catch(Exception e)
{
JOptionPane.showMessageDialog(null,e);
}
/*        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LoginFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LoginFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LoginFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LoginFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

*/
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LoginFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public static javax.swing.JLabel DayCaption;
    private javax.swing.JButton ExitButton;
    private javax.swing.JButton LoginButton;
    private javax.swing.JButton ResetButton;
    public static javax.swing.JLabel TimeCaption;
    private javax.swing.JDialog exitDialog;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JOptionPane jOptionPane1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPasswordField password;
    private javax.swing.JLabel passwordCaption;
    private javax.swing.JTextField username;
    private javax.swing.JLabel usernameCaption;
    // End of variables declaration//GEN-END:variables
}
