package com.billingsoftware;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.text.NumberFormat;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;

public class NewItem extends javax.swing.JFrame implements Resources {

    public NewItem() {
        initComponents();
        NewItem.this.setIconImage(new ImageIcon(getClass().getResource(APPLICATION_ICON)).getImage());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        ItemName = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        Rate = new javax.swing.JTextField();
        Margin = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        SellPrice = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        DoneButton = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        Stock = new javax.swing.JTextField();
        message = new javax.swing.JLabel();
        ReturnButton = new javax.swing.JButton();
        ResetButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Buy New Item");
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        jLabel1.setText("Item Name");

        jLabel2.setText("Rate");

        jLabel3.setText("Margin");

        SellPrice.setEditable(false);
        SellPrice.setFocusable(false);

        jLabel4.setText("Sell Price");

        DoneButton.setIcon(new javax.swing.ImageIcon(getClass().getResource(OK_ICON)));
        DoneButton.setMnemonic('D');
        DoneButton.setToolTipText("Click To Buy");
        DoneButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        DoneButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DoneButtonActionPerformed(evt);
            }
        });

        jLabel5.setText("Stock");

        Stock.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                StockFocusGained(evt);
            }
        });

        message.setForeground(java.awt.Color.red);

        ReturnButton.setIcon(new javax.swing.ImageIcon(getClass().getResource(BACK_ICON)) );
        ReturnButton.setMnemonic('B');
        ReturnButton.setToolTipText(BACK_ICON_STRING);
        ReturnButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ReturnButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ReturnButtonActionPerformed(evt);
            }
        });

        ResetButton.setMnemonic('R');
        ResetButton.setText("Reset");
        ResetButton.setToolTipText("Click Here To Reset Fields");
        ResetButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ResetButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ResetButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(58, 58, 58)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(38, 38, 38)
                                .addComponent(ItemName, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(38, 38, 38)
                                .addComponent(Rate, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(38, 38, 38)
                                .addComponent(Margin, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel5))
                                .addGap(38, 38, 38)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(Stock, javax.swing.GroupLayout.DEFAULT_SIZE, 212, Short.MAX_VALUE)
                                    .addComponent(SellPrice, javax.swing.GroupLayout.DEFAULT_SIZE, 212, Short.MAX_VALUE)))
                            .addComponent(message, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(156, 156, 156)
                        .addComponent(DoneButton, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(ResetButton)
                        .addGap(30, 30, 30)
                        .addComponent(ReturnButton, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(44, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ItemName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Rate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Margin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(SellPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel5)
                    .addComponent(Stock, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(message, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(ResetButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(DoneButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(ReturnButton, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(26, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void DoneButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DoneButtonActionPerformed
        if (ItemName.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(NewItem.this, "Enter Item Name", "Fill Details", 0);
            ItemName.requestFocus();
            return;
        }
        message.setText(null);
        if (Rate.getText().trim().isEmpty() || Rate.getText().trim().contains("-")) {
            JOptionPane.showMessageDialog(NewItem.this, "Enter Rate", "Fill Details", 0);
            Rate.requestFocus();
            return;
        }
        message.setText(null);
        if (Margin.getText().trim().isEmpty() || Margin.getText().trim().contains("-")) {
            JOptionPane.showMessageDialog(NewItem.this, "Enter Margin", "Fill Details", 0);
            Margin.requestFocus();
            return;
        }
        message.setText(null);

        String s = Stock.getText().trim();
        float stock = 0;
        try {
            stock = Float.parseFloat(s);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(NewItem.this, "Enter Stock Quantity", "Fill Details", 0);
            Stock.requestFocus();
            return;
        }
        if (stock <= 0) {
            JOptionPane.showMessageDialog(NewItem.this, "Enter Stock Quantity", "Fill Details", 0);
            Stock.requestFocus();
            return;
        }
        message.setText(null);
        try {
            Connection connection = DAOConnection.getConnection(0);
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("select description from item order by description");
            while (resultSet.next()) {
                if (resultSet.getString("description").equalsIgnoreCase(ItemName.getText().trim())) {
                    resultSet.close();
                    statement.close();
                    connection.close();
                    ItemName.requestFocus();
                    throw new Exception("Item Exists");
                }
            }
            resultSet.close();
            statement.close();
            PreparedStatement preparedStatement = connection.prepareStatement("insert into item(Description,Rate,Margin,Sell_Price,Stock_Left) values (?,?,?,?,?)");
            preparedStatement.setString(1, ItemName.getText().trim());
            preparedStatement.setDouble(2, Float.parseFloat(Rate.getText().trim()));
            preparedStatement.setDouble(3, Float.parseFloat(Margin.getText().trim()));
            preparedStatement.setFloat(4, Float.parseFloat(SellPrice.getText().trim()));
            preparedStatement.setDouble(5, Double.parseDouble(Stock.getText().trim()));
            preparedStatement.executeUpdate();
            resultSet = preparedStatement.getGeneratedKeys();
            Long Code = 0L;
            int z = 0;
            if (resultSet.next()) {
                Code = resultSet.getLong(1);
                resultSet.close();
                z = 1;
                preparedStatement.close();
                preparedStatement = connection.prepareStatement("update item set code = ? where description = ?");
                preparedStatement.setLong(1, Code);
                preparedStatement.setString(2, ItemName.getText().trim());
                preparedStatement.executeUpdate();
            }
            if (z != 1) {
                resultSet.close();
            }
            preparedStatement.close();
            connection.close();
            JOptionPane.showMessageDialog(NewItem.this, "Item Added!!!", "Update Successful", 1);

            new ViewPurchase().setVisible(true);
            NewItem.this.dispose();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(NewItem.this, e.getMessage(), "Error", 0);
        }

    }//GEN-LAST:event_DoneButtonActionPerformed

    private void ReturnButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ReturnButtonActionPerformed
        new ViewPurchase().setVisible(true);
        NewItem.this.dispose();
    }//GEN-LAST:event_ReturnButtonActionPerformed

    private void ResetButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ResetButtonActionPerformed
        ItemName.setText(null);
        Rate.setText(null);
        Margin.setText(null);
        Stock.setText(null);
        message.setText(null);
        SellPrice.setText(null);
        ItemName.requestFocus();
    }//GEN-LAST:event_ResetButtonActionPerformed

    private void StockFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_StockFocusGained
        try {
            if (Rate.getText().trim().isEmpty()) {
                Rate.requestFocus();
            }
            float rate = Float.parseFloat(Rate.getText().trim());
            if (Margin.getText().trim().isEmpty()) {
                Margin.requestFocus();
            }
            float margin = Float.parseFloat(Margin.getText().trim());
            float sellPrice = ((rate * margin) / 100) + rate;
            NumberFormat nf = NumberFormat.getNumberInstance();
            nf.setMaximumFractionDigits(2);
            nf.setMinimumFractionDigits(0);
            SellPrice.setText("" + nf.format(sellPrice).replace(",", ""));
        } catch (java.lang.NumberFormatException nfe) {
            JOptionPane.showMessageDialog(NewItem.this, "Enter Valid Input", "Error", 0);
        }
    }//GEN-LAST:event_StockFocusGained

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        new ViewPurchase().setVisible(true);
        NewItem.this.dispose();
    }//GEN-LAST:event_formWindowClosing

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(NewItem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(NewItem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(NewItem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(NewItem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new NewItem().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton DoneButton;
    private javax.swing.JTextField ItemName;
    private javax.swing.JTextField Margin;
    private javax.swing.JTextField Rate;
    private javax.swing.JButton ResetButton;
    private javax.swing.JButton ReturnButton;
    private javax.swing.JTextField SellPrice;
    private javax.swing.JTextField Stock;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel message;
    // End of variables declaration//GEN-END:variables
}
