package com.billingsoftware;

import java.awt.BorderLayout;
import java.awt.print.PageFormat;
import java.awt.print.PrinterJob;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ScrollPaneConstants;
import javax.swing.table.DefaultTableCellRenderer;
import com.billingsoftware.model.ItemDataModel;

public class PrintItemTable extends JFrame {

    private JScrollPane scrollPane;
    private JTable jt;
    private ItemDataModel edm;

    PrintItemTable() {
        edm = new ItemDataModel();
        jt = new JTable(edm);
        scrollPane = new JScrollPane(jt, ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
        setLayout(new BorderLayout());
        add(scrollPane, BorderLayout.CENTER);
        setSize(500, 500);
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        DefaultTableCellRenderer renderer;
        renderer = (DefaultTableCellRenderer) jt.getTableHeader().getDefaultRenderer();
        renderer.setHorizontalAlignment(JLabel.CENTER);
setVisible(true);
        for (int i = 0; i < jt.getColumnCount(); i++) {
            jt.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
        }
        PrinterJob job = PrinterJob.getPrinterJob();
        PageFormat landscape = job.defaultPage();
        landscape.setOrientation(PageFormat.PORTRAIT);
        if (job.printDialog()) {
            try {
                jt.print();
            } catch (Exception exc) { /* Handle Exception */

                JOptionPane.showMessageDialog(null, exc.getMessage());
            }
            dispose();
        }
    }
}
