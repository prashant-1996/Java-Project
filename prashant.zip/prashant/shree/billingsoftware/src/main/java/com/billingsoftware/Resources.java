package com.billingsoftware;

public interface Resources {

    public static final String OK_ICON = "/images/OK.png";
    public static final String OK_ICON_STRING = "Click Here To Return Back";
    public static final String BUY_ICON = "/images/BUY.gif";
    public static final String BUY_ICON_STRING = "Click Here To Buy Item";
    public static final String SETTINGS_ICON = "/images/SETTINGS.png";
    public static final String SETTINGS_ICON_STRING = "Go For Settings";
    public static final String LOAD_ICON = "/images/LOAD.gif";
    public static final String BACK_ICON = "/images/BACK.png";
    public static final String BACK_ICON_STRING = "Click Here To Return Back";
    public static final String LOCK_ICON = "/images/LOCK.png";
    public static final String LOCK_ICON_STRING = "Lock Application";
    public static final String APPLICATION_ICON = "/images/APPLICATION_ICON.png";
    public static final String BILL_ICON = "/images/BILL_ICON.png";
    public static final String TRANSACTION_ICON = "/images/TRANSACTION_ICON.jpg";
    public static final String TRANSACTION_ICON_1 = "/images/TRANSACTION_ICON_1.png";
    public static final String ADMINPANEL_BACKGROUND_ICON = "/images/BACKGROUND.jpg";
}
