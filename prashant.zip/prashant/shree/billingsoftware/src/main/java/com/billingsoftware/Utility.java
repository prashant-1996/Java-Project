package com.billingsoftware;

import java.io.*;

public class Utility {

    private static boolean consoleLogging = false;

    private Utility() {

    }

    private boolean isConsoleLoggingOn() {
        return consoleLogging;
    }

    public static void setConsoleLogging(boolean cl) {
        consoleLogging = cl;
    }

    public static void addToLog(String logData) {
        java.util.Date date = new java.util.Date();
        String logTime = date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds();

        try {
            int day = date.getDate();
            int month = date.getMonth() + 1;
            int year = date.getYear() + 1900;
            String fileName;
            if (day <= 26) {
                fileName = ((char) (65 + (day - 1))) + "__" + day + "_" + (month) + "_" + year + ".log";
            } else {
                fileName = ((char) (97 + (day - 27))) + "__" + day + "_" + (month) + "_" + year + ".log";
            }
            String yearFolderName = String.valueOf(year);
            String monthFolderName = "";
            switch (month) {
                case 1:
                    monthFolderName = "January";
                case 2:
                    monthFolderName = "February";
                case 3:
                    monthFolderName = "March";
                case 4:
                    monthFolderName = "April";
                case 5:
                    monthFolderName = "May";
                case 6:
                    monthFolderName = "June";
                case 7:
                    monthFolderName = "July";
                case 8:
                    monthFolderName = "August";
                case 9:
                    monthFolderName = "September";
                case 10:
                    monthFolderName = "October";
                case 11:
                    monthFolderName = "November";
                case 12:
                    monthFolderName = "December";
            }

            String folderStructureRequired = yearFolderName + "/" + monthFolderName;
            String userprofile = System.getenv("USERPROFILE");
            File f = new File(userprofile + "\\.billingsoftware\\.log\\" + folderStructureRequired);
            if (f.exists() == false) {
                f.mkdirs();
            }
            File file = new File(userprofile + "\\.billingsoftware\\.log\\" + folderStructureRequired + "/" + fileName);
            RandomAccessFile raf = new RandomAccessFile(file, "rw");
            raf.seek(raf.length());
            raf.writeBytes(logTime + "-" + logData + "\r\n");
            raf.close();
        } catch (Exception e) {
            Utility.addToLog("Utility : addToLog() ---> " + e.getMessage());
        }
    }
}
