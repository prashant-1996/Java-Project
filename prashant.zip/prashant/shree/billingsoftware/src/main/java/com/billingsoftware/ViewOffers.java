package com.billingsoftware;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.table.DefaultTableModel;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class ViewOffers extends javax.swing.JFrame implements Resources {

    public ViewOffers() {
        ViewOffers.this.setIconImage(new ImageIcon(getClass().getResource(APPLICATION_ICON)).getImage());
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        OffersOverview = new javax.swing.JLabel();
        message = new javax.swing.JLabel();
        OffersTabbedPane = new javax.swing.JTabbedPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        FreebiesTable = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        DiscountOffersTable = new javax.swing.JTable();
        TotalOffers = new javax.swing.JLabel();
        ReturnButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("View Offers");
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        OffersOverview.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        OffersOverview.setText("Offers Overview");

        message.setForeground(java.awt.Color.red);
        message.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        OffersTabbedPane.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                OffersTabbedPaneStateChanged(evt);
            }
        });

        FreebiesTable.setAutoCreateRowSorter(true);
        FreebiesTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "     Offer Code", "       Item Name1", "       Item Name2", "                               Description", "      Rate"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Object.class, java.lang.Object.class, java.lang.String.class, java.lang.Float.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(FreebiesTable);
        if (FreebiesTable.getColumnModel().getColumnCount() > 0) {
            FreebiesTable.getColumnModel().getColumn(0).setMinWidth(100);
            FreebiesTable.getColumnModel().getColumn(0).setPreferredWidth(100);
            FreebiesTable.getColumnModel().getColumn(0).setMaxWidth(100);
            FreebiesTable.getColumnModel().getColumn(1).setMinWidth(120);
            FreebiesTable.getColumnModel().getColumn(1).setPreferredWidth(120);
            FreebiesTable.getColumnModel().getColumn(1).setMaxWidth(120);
            FreebiesTable.getColumnModel().getColumn(2).setMinWidth(120);
            FreebiesTable.getColumnModel().getColumn(2).setPreferredWidth(120);
            FreebiesTable.getColumnModel().getColumn(2).setMaxWidth(120);
            FreebiesTable.getColumnModel().getColumn(4).setMinWidth(80);
            FreebiesTable.getColumnModel().getColumn(4).setPreferredWidth(80);
            FreebiesTable.getColumnModel().getColumn(4).setMaxWidth(80);
        }

        OffersTabbedPane.addTab("Freebies", jScrollPane1);

        DiscountOffersTable.setAutoCreateRowSorter(true);
        DiscountOffersTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "  Offer Code", "                Description", "                            Avail", "   Rate"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Float.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(DiscountOffersTable);
        if (DiscountOffersTable.getColumnModel().getColumnCount() > 0) {
            DiscountOffersTable.getColumnModel().getColumn(0).setMinWidth(80);
            DiscountOffersTable.getColumnModel().getColumn(0).setPreferredWidth(80);
            DiscountOffersTable.getColumnModel().getColumn(0).setMaxWidth(80);
            DiscountOffersTable.getColumnModel().getColumn(1).setResizable(false);
            DiscountOffersTable.getColumnModel().getColumn(2).setResizable(false);
            DiscountOffersTable.getColumnModel().getColumn(3).setMinWidth(80);
            DiscountOffersTable.getColumnModel().getColumn(3).setPreferredWidth(80);
            DiscountOffersTable.getColumnModel().getColumn(3).setMaxWidth(80);
        }

        OffersTabbedPane.addTab("Discount Offers", jScrollPane2);

        ReturnButton.setIcon(new javax.swing.ImageIcon(getClass().getResource(BACK_ICON)));
        ReturnButton.setMnemonic('B');
        ReturnButton.setToolTipText(BACK_ICON_STRING);
        ReturnButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ReturnButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(55, 55, 55)
                .addComponent(message, javax.swing.GroupLayout.PREFERRED_SIZE, 526, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 40, Short.MAX_VALUE)
                .addComponent(OffersOverview, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addComponent(OffersTabbedPane)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(TotalOffers, javax.swing.GroupLayout.PREFERRED_SIZE, 319, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addComponent(ReturnButton, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(ReturnButton, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(message, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(OffersOverview, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(11, 11, 11)
                .addComponent(OffersTabbedPane, javax.swing.GroupLayout.PREFERRED_SIZE, 418, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TotalOffers, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        new AdminPanel().setVisible(true);
        ViewOffers.this.dispose();
            }//GEN-LAST:event_formWindowClosing

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        try {
            Connection connection = DAOConnection.getConnection(0);
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("select count(*) from offers");
            resultSet.next();
            if (resultSet.getLong(1) <= 0) {
                resultSet.close();
                statement.close();
                connection.close();
                JOptionPane.showMessageDialog(ViewOffers.this, "No Offers Set", "Information", 0);
                TotalOffers.setText("Total Offers :0");
                return;
            }
            resultSet.close();
            resultSet = statement.executeQuery("select * from offers order by ItemName1");
            DefaultTableModel dtm = (DefaultTableModel) FreebiesTable.getModel();
            dtm.setRowCount(0);
            int i = 0;
            while (resultSet.next()) {
                String offerCode = resultSet.getString("Offer_Code");
                String itemName1 = resultSet.getString("ItemName1");
                String itemName2 = resultSet.getString("ItemName2");
                String desc = resultSet.getString("Description");
                Float rate = resultSet.getFloat("Rate");
                Object newRow[] = {offerCode, itemName1, itemName2, desc, rate};
                dtm.addRow(newRow);
                i++;
            }
            TotalOffers.setText("Total Offers :" + i);
            resultSet.close();

        } catch (ClassNotFoundException | SQLException ex) {
            JOptionPane.showMessageDialog(ViewOffers.this, ex.getMessage(), "Error", 0);
        }
    }//GEN-LAST:event_formWindowOpened

    private void OffersTabbedPaneStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_OffersTabbedPaneStateChanged
        if (OffersTabbedPane.getSelectedIndex() == 1) // Discount
        {
            int i = 1;
            TotalOffers.setText("Total Offers :" + i);
        }
    }//GEN-LAST:event_OffersTabbedPaneStateChanged

    private void ReturnButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ReturnButtonActionPerformed
        new AdminPanel().setVisible(true);
        ViewOffers.this.dispose();
    }//GEN-LAST:event_ReturnButtonActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ViewOffers.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ViewOffers().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable DiscountOffersTable;
    private javax.swing.JTable FreebiesTable;
    private javax.swing.JLabel OffersOverview;
    private javax.swing.JTabbedPane OffersTabbedPane;
    private javax.swing.JButton ReturnButton;
    private javax.swing.JLabel TotalOffers;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel message;
    // End of variables declaration//GEN-END:variables
}
