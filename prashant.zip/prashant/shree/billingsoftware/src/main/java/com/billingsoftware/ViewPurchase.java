package com.billingsoftware;

import com.billingsoftware.model.PurchaseDataModel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import javax.swing.JOptionPane;
import static java.awt.event.KeyEvent.VK_ENTER;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.table.DefaultTableModel;
import javax.swing.ImageIcon;
import java.text.NumberFormat;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableCellRenderer;

class MyRenderer extends DefaultTableCellRenderer {

    Color backgroundColor = getBackground();

    @Override
    public Component getTableCellRendererComponent(
            JTable PurchaseTable, Object value, boolean isSelected,
            boolean hasFocus, int row, int column) {
        Component c = super.getTableCellRendererComponent(
                PurchaseTable, value, isSelected, hasFocus, row, column);
        PurchaseDataModel model = (PurchaseDataModel) PurchaseTable.getModel();
        if (model.getState(row)) {
            c.setBackground(Color.green.darker());
        } else {
            c.setBackground(backgroundColor);
        }
        return c;
    }
}

public class ViewPurchase extends javax.swing.JFrame implements Resources, ListSelectionListener {

    private static NumberFormat nf;

    private void reset() {
        UpdateButton.setEnabled(false);
        BuyButton.setEnabled(false);
        ItemName1.setEnabled(false);
        Rate.setEnabled(false);
        Margin.setEnabled(false);
        SellPrice.setEnabled(false);
        Stock.setEnabled(false);
        ItemName1.setText(null);
        Rate.setText(null);
        Margin.setText(null);
        SellPrice.setText(null);
        Stock.setText(null);
    }

    public ViewPurchase() {
        initComponents();
        nf = NumberFormat.getNumberInstance();
        nf.setMaximumFractionDigits(2);
        nf.setMinimumFractionDigits(0);
        setLayout(new BorderLayout());
        add(Panel2, BorderLayout.CENTER);
        add(Panel1, BorderLayout.NORTH);
        add(Panel3, BorderLayout.SOUTH);
        DefaultTableCellRenderer renderer = (DefaultTableCellRenderer) PurchaseTable.getTableHeader().getDefaultRenderer();
        renderer.setHorizontalAlignment(JLabel.CENTER);
        com.billingsoftware.model.PurchaseDataModel.populateData();
        for (int i = 0; i < PurchaseTable.getColumnCount(); i++) {
            PurchaseTable.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }
        PurchaseTable.getSelectionModel().addListSelectionListener(this);
        ViewPurchase.this.setIconImage(new ImageIcon(getClass().getResource(APPLICATION_ICON)).getImage());
    }

    @Override
    public void valueChanged(ListSelectionEvent ev) {

        int selectedRow = PurchaseTable.getSelectedRow();
        if (selectedRow < 0 || selectedRow > PurchaseTable.getRowCount()) {
            PurchaseTable.clearSelection();
            reset();
            return;
        }
        ItemName1.setText((String) PurchaseTable.getValueAt(selectedRow, 2));
        Rate.setText("" + (float) PurchaseTable.getValueAt(PurchaseTable.getSelectedRow(), 3));
        Margin.setText("" + (float) PurchaseTable.getValueAt(PurchaseTable.getSelectedRow(), 4));
        SellPrice.setText("" + (float) PurchaseTable.getValueAt(PurchaseTable.getSelectedRow(), 5));
        float stock = 0;
        stock = (float) PurchaseTable.getValueAt(selectedRow, 6);
        String s = nf.format(stock).replace(",", "");
        Stock.setText(s);
        Rate.setEnabled(true);
        Margin.setEnabled(true);
        UpdateButton.setEnabled(true);
        BuyButton.setEnabled(true);

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
setResizable(false);
        centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        Panel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jLabel5 = new javax.swing.JLabel();
        ItemName1 = new javax.swing.JTextField();
        Rate = new javax.swing.JTextField();
        Margin = new javax.swing.JTextField();
        SellPrice = new javax.swing.JTextField();
        Stock = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        UpdateButton = new javax.swing.JButton();
        BuyButton = new javax.swing.JButton();
        PrintTableForTransactionButton = new javax.swing.JButton();
        SortByComboBox = new javax.swing.JComboBox();
        jLabel4 = new javax.swing.JLabel();
        Purchase = new javax.swing.JButton();
        Panel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        ReturnButton = new javax.swing.JButton();
        ItemCode = new javax.swing.JTextField();
        ItemName = new javax.swing.JTextField();
        message = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        Panel2 = new javax.swing.JPanel();
        pdm = new PurchaseDataModel();
        PurchaseTable = new javax.swing.JTable(pdm);
        pdm.fireTableDataChanged();
        PurchaseTable.setDefaultRenderer(Object.class, new MyRenderer());
        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Purchase");

        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }

            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        jLabel5.setText("Item Name");

        ItemName1.setEditable(false);

        Rate.setToolTipText("Enter Rate Of Item");

        Margin.setToolTipText("Enter Margin For Item");
        Margin.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                MarginFocusLost(evt);
            }
        });

        SellPrice.setEditable(false);
        SellPrice.setFocusable(false);

        Stock.setEditable(false);
        Stock.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                StockFocusLost(evt);
            }
        });

        jLabel6.setText("Stock");

        jLabel7.setText("Sell Price");

        jLabel8.setText("Margin");

        jLabel9.setText("Rate");

        UpdateButton.setText("Update");
        UpdateButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdateButtonActionPerformed(evt);
            }
        });

        BuyButton.setText("Buy");
        BuyButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BuyButtonActionPerformed(evt);
            }
        });

        PrintTableForTransactionButton.setText("Print Table For Transaction");
        PrintTableForTransactionButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PrintTableForTransactionButtonActionPerformed(evt);
            }
        });
        SortByComboBox.setModel(new javax.swing.DefaultComboBoxModel(new String[]{"--Select--", "Item Code", "Description", "Cost Price", "Margin", "Sell Price", "Stock Left"}));
        SortByComboBox.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                SortByComboBoxItemStateChanged(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Times New Roman", 0, 14));
        jLabel4.setText("Sort by :");

        Purchase.setText("Purchase");
        Purchase.setToolTipText("Click Here To Buy Item");
        Purchase.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Purchase.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PurchaseActionPerformed(evt);
            }
        });
jScrollPane1.setViewportView(PurchaseTable);

        javax.swing.GroupLayout Panel2Layout = new javax.swing.GroupLayout(Panel2);
        Panel2.setLayout(Panel2Layout);
        Panel2Layout.setHorizontalGroup(
            Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Panel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 750, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        Panel2Layout.setVerticalGroup(
            Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Panel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE,300, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout Panel3Layout = new javax.swing.GroupLayout(Panel3);
        Panel3.setLayout(Panel3Layout);
        Panel3Layout.setHorizontalGroup(
                Panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(Panel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(Panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(Panel3Layout.createSequentialGroup()
                                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(ItemName1, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(Panel3Layout.createSequentialGroup()
                                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(Rate))
                                .addGroup(Panel3Layout.createSequentialGroup()
                                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(Margin)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(Panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel6)
                                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(Panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(PrintTableForTransactionButton)
                                .addComponent(SellPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(Stock, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(Panel3Layout.createSequentialGroup()
                                        .addComponent(UpdateButton)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(BuyButton)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel3Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(SortByComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(6, 6, 6)
                        .addComponent(Purchase)
                        .addContainerGap())
        );
        Panel3Layout.setVerticalGroup(
                Panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel3Layout.createSequentialGroup()
                        .addGroup(Panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(Purchase)
                                .addComponent(SortByComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 16, Short.MAX_VALUE)
                        .addGroup(Panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(Panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(SellPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(Panel3Layout.createSequentialGroup()
                                        .addGroup(Panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(ItemName1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(Panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(Rate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jLabel6)
                                                .addComponent(Stock, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(Panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGroup(Panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                        .addComponent(Margin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(UpdateButton)
                                                        .addComponent(BuyButton)))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(PrintTableForTransactionButton)
                        .addContainerGap())
        );

        jLabel1.setFont(new java.awt.Font("Times New Roman", 0, 18));
        jLabel1.setText("Purchase");

        ReturnButton.setIcon(new javax.swing.ImageIcon(getClass().getResource(BACK_ICON)));
        ReturnButton.setMnemonic('B');
        ReturnButton.setToolTipText(BACK_ICON_STRING);
        ReturnButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ReturnButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ReturnButtonActionPerformed(evt);
            }
        });

        ItemCode.setToolTipText("Enter Item Code");
        ItemCode.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                ItemCodeFocusLost(evt);
            }
        });
        ItemCode.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                ItemCodeKeyReleased(evt);
            }
        });

        ItemName.setToolTipText("Enter Item Name");
        ItemName.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                ItemNameFocusLost(evt);
            }
        });
        ItemName.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                ItemNameKeyReleased(evt);
            }
        });

        message.setForeground(java.awt.Color.red);
        message.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        jLabel3.setFont(new java.awt.Font("Times New Roman", 0, 14));
        jLabel3.setText("Enter Item Name");

        jLabel2.setFont(new java.awt.Font("Times New Roman", 0, 14));
        jLabel2.setText("Enter Item Code");

        javax.swing.GroupLayout Panel1Layout = new javax.swing.GroupLayout(Panel1);
        Panel1.setLayout(Panel1Layout);
        Panel1Layout.setHorizontalGroup(
                Panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(Panel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(Panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(Panel1Layout.createSequentialGroup()
                                        .addComponent(ReturnButton, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(message, javax.swing.GroupLayout.PREFERRED_SIZE, 405, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(7, 7, 7))
                                .addGroup(Panel1Layout.createSequentialGroup()
                                        .addComponent(jLabel2)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(ItemCode, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel3)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(ItemName, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap())
        );
        Panel1Layout.setVerticalGroup(
                Panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(Panel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(Panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(ReturnButton, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(Panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jLabel1)
                                        .addComponent(message, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(Panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel2)
                                .addComponent(ItemCode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel3)
                                .addComponent(ItemName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap())
        );

        PurchaseTable.getTableHeader().setReorderingAllowed(false);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                        .addGap(10, 10, 10)
                                        .addComponent(Panel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(Panel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(Panel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .addContainerGap())))
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(Panel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Panel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(Panel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(45, 45, 45))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void PurchaseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PurchaseActionPerformed
        new NewItem().setVisible(true);
        ViewPurchase.this.dispose();
    }//GEN-LAST:event_PurchaseActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        UpdateButton.setEnabled(false);
        BuyButton.setEnabled(false);
        if (PurchaseTable.getRowCount() <= 0) {
            PrintTableForTransactionButton.setEnabled(false);
        }
        reset();
    }//GEN-LAST:event_formWindowOpened

    private void ReturnButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ReturnButtonActionPerformed
        new AdminPanel().setVisible(true);
        ViewPurchase.this.dispose();
    }//GEN-LAST:event_ReturnButtonActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        new AdminPanel().setVisible(true);
        ViewPurchase.this.dispose();
    }//GEN-LAST:event_formWindowClosing

    private void ItemCodeKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ItemCodeKeyReleased
        if (evt.getKeyCode() != VK_ENTER) {
            ItemName.setText(null);
            String itemCode = (ItemCode.getText().trim());
            if (itemCode.length() == 0) {
                message.setText(null);
                return;
            }
            long iCode = 0;
            try {
                iCode = Long.parseLong(itemCode);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(ViewPurchase.this, "Enter Valid Code", "Error", 0);
                ItemCode.setText(null);
                return;
            }
            int i = 0;
            while (i < PurchaseTable.getRowCount()) {
                long c = (Long) PurchaseTable.getValueAt(i, 1);

                if (c == iCode) {
                    PurchaseTable.setRowSelectionInterval(i, i);
                    PurchaseTable.scrollRectToVisible(PurchaseTable.getCellRect(i, i, false));
                    message.setText(null);
                    break;
                }
                i++;
            }
            if (i == PurchaseTable.getRowCount()) {
                PurchaseTable.clearSelection();
                message.setText("Not Found");
            }
        }
    }//GEN-LAST:event_ItemCodeKeyReleased

    private void ItemNameKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ItemNameKeyReleased
        if (evt.getKeyCode() != VK_ENTER) {
            ItemCode.setText(null);
            int i = 0;
            String itemName = (ItemName.getText().trim());
            if (itemName.length() == 0) {
                message.setText(null);
                return;
            }
            int y = 0;
            int l = 0;
            int a, b;
            while (i < PurchaseTable.getRowCount()) {
                String desc = (String) PurchaseTable.getValueAt(i, 2);
                if (itemName.length() <= desc.length()) {
                    l = itemName.length();
                    y = 0;
                    while (y < l) {
                        a = itemName.charAt(y);
                        if (a >= 97 && a <= 122) {
                            a = a - 32;
                        }
                        b = desc.charAt(y);
                        if (b >= 97 && b <= 122) {
                            b = b - 32;
                        }
                        if (a != b) {
                            break;
                        }
                        y++;
                    }
                    if (y == l) {
                        PurchaseTable.setRowSelectionInterval(i, i);
                        PurchaseTable.scrollRectToVisible(PurchaseTable.getCellRect(i, i, false));
                        message.setText(null);
                        break;

                    }
                }
                i++;
            }
            if (i == PurchaseTable.getRowCount()) {
                PurchaseTable.clearSelection();
                message.setText("Not Found");
            }
        }
    }//GEN-LAST:event_ItemNameKeyReleased

    private void SortByComboBoxItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_SortByComboBoxItemStateChanged
//            sort((String) SortByComboBox.getSelectedItem());

    }//GEN-LAST:event_SortByComboBoxItemStateChanged

    private void MarginFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_MarginFocusLost
        try {
            float rate = Float.parseFloat(Rate.getText().trim());
            float margin = Float.parseFloat(Margin.getText().trim());
            float sellPrice = ((rate * margin) / 100) + rate;
            if (rate <= 0) {
                JOptionPane.showMessageDialog(ViewPurchase.this, "Enter Valid Rate", "Fill Details", 0);
                Rate.requestFocus();
                return;
            }
            if (margin <= 0) {
                JOptionPane.showMessageDialog(ViewPurchase.this, "Enter Valid Margin", "Fill Details", 0);
                Margin.requestFocus();
                return;
            }
            SellPrice.setText(nf.format(sellPrice).replace(",", ""));
        } catch (Exception e) {
            if (!(Margin.getText().trim().isEmpty())) {
                JOptionPane.showMessageDialog(ViewPurchase.this, e.getMessage(), "Error", 0);
            }
            if ((Margin.getText().trim().isEmpty())) {
                Margin.requestFocus();
            }
            if ((Rate.getText().trim().isEmpty())) {
                Rate.requestFocus();
            }
        }
    }//GEN-LAST:event_MarginFocusLost

    private void StockFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_StockFocusLost
        try {
            Float stock = Float.parseFloat(Stock.getText().trim());
            if (stock <= 0) {
                JOptionPane.showMessageDialog(ViewPurchase.this, "Enter Valid Stock", "Fill Details", 0);
                Stock.requestFocus();
                return;
            }
        } catch (Exception e) {
            Stock.setForeground(Color.red);
            Stock.requestFocus();
            if ((Rate.getText().trim().isEmpty())) {
                Rate.requestFocus();
            }
            if ((Stock.getText().trim().isEmpty())) {
                Stock.requestFocus();
            }
            if ((Margin.getText().trim().isEmpty())) {
                Margin.requestFocus();
            }
        }
    }//GEN-LAST:event_StockFocusLost

    private void UpdateButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UpdateButtonActionPerformed
        if (Rate.getText().trim().isEmpty() || Rate.getText().trim().contains("-")) {
            JOptionPane.showMessageDialog(ViewPurchase.this, "Enter Valid Rate", "Fill Details", 0);
            Rate.requestFocus();
            return;
        }
        message.setText(null);
        if (Margin.getText().trim().isEmpty() || Margin.getText().trim().contains("-")) {
            JOptionPane.showMessageDialog(ViewPurchase.this, "Enter Valid Margin", "Fill Details", 0);
            Margin.requestFocus();
            return;
        }
        try {
            Connection connection = DAOConnection.getConnection(0);
            PreparedStatement preparedStatement = connection.prepareStatement("update item set Rate=?,Margin=?,Sell_Price=? where code = ?");
            preparedStatement.setFloat(1, Float.parseFloat(Rate.getText().trim()));
            preparedStatement.setFloat(2, Float.parseFloat(Margin.getText().trim()));
            preparedStatement.setFloat(3, Float.parseFloat(SellPrice.getText().trim()));
            preparedStatement.setLong(4, (Long) PurchaseTable.getValueAt(PurchaseTable.getSelectedRow(), 1));
            preparedStatement.executeUpdate();
            pdm.setValueAt(Float.parseFloat(Rate.getText()), PurchaseTable.getSelectedRow(), 3);
            pdm.setValueAt(Float.parseFloat(Margin.getText()), PurchaseTable.getSelectedRow(), 4);
            pdm.setValueAt(Float.parseFloat(SellPrice.getText()), PurchaseTable.getSelectedRow(), 5);
            ItemName1.setText("" + PurchaseTable.getValueAt(PurchaseTable.getSelectedRow(), 2));
            Rate.setText("" + PurchaseTable.getValueAt(PurchaseTable.getSelectedRow(), 3));
            Margin.setText("" + PurchaseTable.getValueAt(PurchaseTable.getSelectedRow(), 4));
            SellPrice.setText("" + PurchaseTable.getValueAt(PurchaseTable.getSelectedRow(), 5));
            Stock.setText("" + PurchaseTable.getValueAt(PurchaseTable.getSelectedRow(), 6));
            int selectedRow = PurchaseTable.getSelectedRow();
            pdm.fireTableDataChanged();
            PurchaseTable.setRowSelectionInterval(selectedRow, selectedRow);
            PurchaseTable.scrollRectToVisible(PurchaseTable.getCellRect(selectedRow, selectedRow, false));
            JOptionPane.showMessageDialog(ViewPurchase.this, "Update Successfully!!!", "Update Successful", 1);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(ViewPurchase.this, e.getMessage(), "Error", 0);
        }
    }//GEN-LAST:event_UpdateButtonActionPerformed

    private void BuyButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BuyButtonActionPerformed
        String s = "";
        while (true) {
            s = JOptionPane.showInputDialog(null, "Enter " + ItemName1.getText().trim() + "\'s New Quantity", ItemName1.getText().trim(), 1);
            try {
                if (s.length() == 0 || s.equals("0") || s.contains("-")) {
                    JOptionPane.showMessageDialog(ViewPurchase.this, "Enter Valid Stock Quantity", "Fill Details", 0);
                    continue;
                }
            } catch (Exception e) {
                return;
            }
            break;
        }
        double stock = 0;
        try {
            stock = Double.parseDouble(s);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(ViewPurchase.this, "Enter Valid Stock Quantity", "Fill Details", 0);
            return;
        }
        if (stock <= 0) {
            JOptionPane.showMessageDialog(ViewPurchase.this, "Enter Valid Stock Quantity", "Fill Details", 0);
            return;
        }

        s = nf.format(stock);
        s = s.replace(",", "");
        stock = Double.parseDouble(s);
        try {
            Connection connection = DAOConnection.getConnection(0);
            PreparedStatement preparedStatement = connection.prepareStatement("select stock_left from item where code = ?");
            preparedStatement.setLong(1, (long) PurchaseTable.getValueAt(PurchaseTable.getSelectedRow(), 1));
            ResultSet resultSet = preparedStatement.executeQuery();
            double oldStock = 0L;
            if (resultSet.next()) {
                oldStock = resultSet.getDouble(1);
            }
            resultSet.close();
            preparedStatement.close();
            preparedStatement = connection.prepareStatement("update item set stock_left = ? where code=?");
            stock = stock + oldStock;
            preparedStatement.setDouble(1, stock);
            preparedStatement.setLong(2, (long) PurchaseTable.getValueAt(PurchaseTable.getSelectedRow(), 1));
            preparedStatement.executeUpdate();
            preparedStatement.close();
            connection.close();
            Stock.setText(nf.format(stock).replace(",", ""));
            pdm.setValueAt(Float.parseFloat(Rate.getText()), PurchaseTable.getSelectedRow(), 3);
            pdm.setValueAt(Float.parseFloat(Margin.getText()), PurchaseTable.getSelectedRow(), 4);
            pdm.setValueAt(Float.parseFloat(SellPrice.getText()), PurchaseTable.getSelectedRow(), 5);
            pdm.setValueAt(Float.parseFloat(Stock.getText()), PurchaseTable.getSelectedRow(), 6);
            ItemName1.setText((String) PurchaseTable.getValueAt(PurchaseTable.getSelectedRow(), 2));
            Rate.setText("" + (float) PurchaseTable.getValueAt(PurchaseTable.getSelectedRow(), 3));
            Margin.setText("" + (float) PurchaseTable.getValueAt(PurchaseTable.getSelectedRow(), 4));
            SellPrice.setText("" + (float) PurchaseTable.getValueAt(PurchaseTable.getSelectedRow(), 5));
            Stock.setText("" + (float) PurchaseTable.getValueAt(PurchaseTable.getSelectedRow(), 6));
            int selectedRow = PurchaseTable.getSelectedRow();
            pdm.fireTableDataChanged();
            PurchaseTable.setRowSelectionInterval(selectedRow, selectedRow);
            PurchaseTable.scrollRectToVisible(PurchaseTable.getCellRect(selectedRow, selectedRow, false));
            JOptionPane.showMessageDialog(ViewPurchase.this, "Update Successfully!!!", "Update Successful", 1);
        } catch (SQLException | ClassNotFoundException e) {
            JOptionPane.showMessageDialog(ViewPurchase.this, e.getMessage(), "Error", 0);
        } catch (Exception ee) {
            JOptionPane.showMessageDialog(ViewPurchase.this, ee.getMessage(), "Error", 0);
        }
    }//GEN-LAST:event_BuyButtonActionPerformed

    private void ItemNameFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_ItemNameFocusLost
        ItemName.setText(null);        // TODO add your handling code here:
    }//GEN-LAST:event_ItemNameFocusLost

    private void ItemCodeFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_ItemCodeFocusLost
        ItemCode.setText(null);
    }//GEN-LAST:event_ItemCodeFocusLost

    private void PrintTableForTransactionButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PrintTableForTransactionButtonActionPerformed
        new PrintItemTable();
    }//GEN-LAST:event_PrintTableForTransactionButtonActionPerformed

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ViewPurchase.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ViewPurchase.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ViewPurchase.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ViewPurchase.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ViewPurchase().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BuyButton;
    private javax.swing.JTextField ItemCode;
    private javax.swing.JTextField ItemName;
    public static javax.swing.JTextField ItemName1;
    private javax.swing.JTextField Margin;
    private javax.swing.JPanel Panel1;
    private javax.swing.JPanel Panel2;
    private javax.swing.JPanel Panel3;
    private javax.swing.JButton PrintTableForTransactionButton;
    private javax.swing.JButton Purchase;
    private javax.swing.JTable PurchaseTable;
    private javax.swing.JTextField Rate;
    private javax.swing.JButton ReturnButton;
    private javax.swing.JTextField SellPrice;
    private javax.swing.JComboBox SortByComboBox;
    private javax.swing.JTextField Stock;
    private javax.swing.JButton UpdateButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;

    public static javax.swing.JLabel message;
    private PurchaseDataModel pdm;
    private javax.swing.JScrollPane scrollPane;
    private static javax.swing.JScrollPane jScrollPane1;
    private DefaultTableCellRenderer centerRenderer;
    // End of variables declaration//GEN-END:variables

    private void sort(String value) {
        if (value.equalsIgnoreCase("--Select--")) {
            return;
        }
        try {
            Connection connection = DAOConnection.getConnection(0);
            Statement statement = connection.createStatement();
            ResultSet resultSet = null;
            if (value.equalsIgnoreCase("Item Number")) {
                resultSet = statement.executeQuery("select * from item");
            }
            if (value.equalsIgnoreCase("Item Code")) {
                resultSet = statement.executeQuery("select * from item order by Code");
            }
            if (value.equalsIgnoreCase("Description")) {
                resultSet = statement.executeQuery("select * from item order by Description");
            }
            if (value.equalsIgnoreCase("Stock Left")) {
                resultSet = statement.executeQuery("select * from item order by Stock_Left");
            }
            if (value.equalsIgnoreCase("Margin")) {
                resultSet = statement.executeQuery("select * from item order by Margin");
            }
            if (value.equalsIgnoreCase("Sell Price")) {
                resultSet = statement.executeQuery("select * from item order by Sell_Price");
            }
            if (value.equalsIgnoreCase("Cost Price")) {
                resultSet = statement.executeQuery("select * from item order by Rate");
            }
            int i = 1;
            DefaultTableModel tm = (DefaultTableModel) PurchaseTable.getModel();
            tm.setRowCount(0);
            while (resultSet.next()) {
                Long code = resultSet.getLong("Code");
                String description = resultSet.getString("Description");
                float rate = resultSet.getFloat("Rate");
                float margin = resultSet.getFloat("Margin");
                float sellPrice = resultSet.getFloat("Sell_Price");
                double stock_Left = resultSet.getDouble("Stock_Left");
                String s = nf.format(stock_Left).replace(",", "");
                double stockLeft = Double.parseDouble(s);
                Object[] newRow = {i, code, description, rate, margin, sellPrice, stockLeft};
                tm.addRow(newRow);
                i++;
            }
            resultSet.close();
            statement.close();
            connection.close();
        } catch (SQLException | ClassNotFoundException e) {
            message.setText(e.getMessage());
        }
    }
}
