package com.billingsoftware;

import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import java.awt.Dimension;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.BorderLayout;
import java.awt.Toolkit;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ScrollPaneConstants;
import javax.swing.table.AbstractTableModel;
import java.sql.*;

public class ViewStock extends JFrame implements Resources {

    private  JTable jt;
    private  JScrollPane scrollPane;
    private  viewStockAs vsa;

    ViewStock() {
        super("Items In Stores");
        ViewStock.this.setIconImage(new ImageIcon(getClass().getResource(APPLICATION_ICON)).getImage());
        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
new AdminPanel().setVisible(true);
ViewStock.this.dispose();
            }
});
        try {
            Connection c = DAOConnection.getConnection(0);
            Statement s = c.createStatement();
            ResultSet r = s.executeQuery("select count(*) as cnt from item");
            if (r.next()) {
                vsa = new viewStockAs();
                jt = new JTable(vsa);
                scrollPane = new JScrollPane(jt, ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
                DefaultTableCellRenderer renderer = (DefaultTableCellRenderer) jt.getTableHeader().getDefaultRenderer();
                renderer.setHorizontalAlignment(JLabel.CENTER);
                DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
                centerRenderer.setHorizontalAlignment(JLabel.CENTER);
                for (int i = 0; i < jt.getColumnCount(); i++) {
                    jt.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
                }
                setLayout(new BorderLayout());
                add(scrollPane, BorderLayout.CENTER);
                setSize(500, 500);
		Dimension dimension=Toolkit.getDefaultToolkit().getScreenSize(); 
		setLocation(dimension.width/2-getWidth()/2,dimension.height/2-getHeight()/2); 
                setVisible(true);
            }
            r.close();
            s.close();
            c.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "Error", 0);
        }
    }
}

class viewStockAs extends AbstractTableModel {

    private String[] title = {"Code", "Description", "Store1", "Store2", "Store3"};
    private Object data[][];

    viewStockAs() {
        try {
            Connection connection = DAOConnection.getConnection(0);
            PreparedStatement ps1 = connection.prepareStatement("select count(*) from item");
            ResultSet rs1 = ps1.executeQuery();
            int lines = 0;
            if (rs1.next()) {
                lines = rs1.getInt(1);
            }
            rs1.close();
           if (lines == 0) {
                ps1.close();
                connection.close();
                return;
            }
            ps1.close();
            data = new Object[lines][5];
            int e = 0;
            PreparedStatement ps2 = connection.prepareStatement("select code,description from item order by description");
            PreparedStatement ps3 = connection.prepareStatement("select stock_left from item1 order by description");
            PreparedStatement ps4 = connection.prepareStatement("select stock_left from item2 order by description");
            PreparedStatement ps5 = connection.prepareStatement("select stock_left from item3 order by description");
            ResultSet rs2 = ps2.executeQuery();
            ResultSet rs3 = ps3.executeQuery();
            ResultSet rs4 = ps4.executeQuery();
            ResultSet rs5 = ps5.executeQuery();
            rs3.next();
            rs4.next();
            rs5.next();
            while (rs2.next()) {
                data[e][0] = rs2.getLong(1);
                data[e][1] = rs2.getString(2);
                data[e][2] = rs3.getFloat("stock_left" );
                data[e][3] = rs4.getFloat("stock_left");
                data[e][4] = rs5.getFloat("stock_left");
                rs3.next();
                rs4.next();
                rs5.next();
                e++;
            }
            rs5.close();
            rs4.close();
            rs3.close();
            rs2.close();
            ps5.close();
            ps4.close();
            ps3.close();
            ps2.close();
            connection.close();
        } catch (Exception e) {
e.printStackTrace();
        }
    }

    public int getRowCount() {
        return data.length;
    }

    public int getColumnCount() {
        return 5;
    }

    public String getColumnName(int c) {
        return title[c];
    }

    public boolean isCellEditable(int r, int c) {
        return false;
    }

    public Object getValueAt(int r, int c) {
        return data[r][c];
    }

    public Class getColumnClass(int c) {
        try {
            if (c == 0) {
                return Class.forName("java.lang.Long");
            }
            if (c == 1) {
                return Class.forName("java.lang.String");
            }
            if (c == 2 || c == 3 || c == 4) {
                return Class.forName("java.lang.Float");
            }
        } catch (ClassNotFoundException cfne) {
        }
        return null;
    }

}
