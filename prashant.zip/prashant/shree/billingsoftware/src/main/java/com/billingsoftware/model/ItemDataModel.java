package com.billingsoftware.model;

import com.billingsoftware.DAOConnection;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.table.AbstractTableModel;

public class ItemDataModel extends AbstractTableModel {

    private String[] title = {"Code", "Description"};
    private static Object data[][];
    public static int len;
public static void populateData()
{
        try {
            Connection connection = DAOConnection.getConnection(0);
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("select count(*) as cnt from item");
            int lines = 0;
            if (resultSet.next()) {
                lines = resultSet.getInt("cnt");
            }
            resultSet.close();
            if (lines == 0) {
                statement.close();
                connection.close();
                return;
            }
            data = new Object[lines][2];
            int e = 0;
            statement = connection.createStatement();
            resultSet = statement.executeQuery("select code,description from item order by description");
            while (resultSet.next()) {
                data[e][0] = resultSet.getInt("Code");
                data[e][1] = resultSet.getString("Description");
                e++;
            }
            resultSet.close();
            statement.close();
            statement = connection.createStatement();
            resultSet = statement.executeQuery("select max(Description) from item");
            if (resultSet.next()) {
                len = resultSet.getString(1).length();
            }
            connection.close();
        } catch (Exception e) {
        }

}

    public ItemDataModel() {
	populateData();
    }

    public int getRowCount() {
        return data.length;
    }

    public int getColumnCount() {
        return 2;
    }

    public String getColumnName(int c) {
        return title[c];
    }

    public boolean isCellEditable(int r, int c) {
        return false;
    }

    public Object getValueAt(int r, int c) {
        return data[r][c];
    }

    public Class getColumnClass(int c) {
        try {
            if (c == 0) {
                return Class.forName("java.lang.Integer");
            }
            if (c == 1) {
                return Class.forName("java.lang.String");
            }
        } catch (ClassNotFoundException cfne) {
        }
        return null;
    }
}
