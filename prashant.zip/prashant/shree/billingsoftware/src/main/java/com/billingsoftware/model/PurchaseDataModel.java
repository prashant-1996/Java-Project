package com.billingsoftware.model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.table.AbstractTableModel;

public class PurchaseDataModel extends AbstractTableModel {

    private String[] title = {"Item Number", "Code", "Description", "Rate", "Margin", "Sell_Price", "Stock_Left(in Hand)"};
    public static Object data[][];

    public static void populateData() {
        try {
            Connection connection = com.billingsoftware.DAOConnection.getConnection(0);
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("select count(*) from item");
            int lines = 0;
            if (resultSet.next()) {
                lines = resultSet.getInt(1);
                data = new Object[lines][7];
            }
            resultSet.close();
            if (lines == 0) {
                statement.close();
                connection.close();
                return;
            }
            statement.close();
            statement = connection.createStatement();
            resultSet = statement.executeQuery("select Code,Description,Rate,Margin,Sell_Price,Stock_Left from item order by Description");
            int i = 0;
            int e = 0;
            while (resultSet.next()) {
                data[e][0] = ++i;
                data[e][1] = resultSet.getLong("Code");
                data[e][2] = resultSet.getString("Description");
                data[e][3] = resultSet.getFloat("Rate");
                data[e][4] = resultSet.getFloat("Margin");
                data[e][5] = resultSet.getFloat("Sell_Price");
                data[e][6] = resultSet.getFloat("Stock_Left");
                e++;
            }
            resultSet.close();
            statement.close();
            connection.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public PurchaseDataModel() {
        populateData();
    }

    public boolean getState(int row) {
        if (row % 2 == 0) {
            return true;
        }
        return false;
    }

    public void setValueAt(Object value, int r, int c) {
        data[r][c] = value;
        fireTableCellUpdated(r, c);
    }

    public int getRowCount() {
        return data.length;
    }

    public int getColumnCount() {
        return 7;
    }

    public String getColumnName(int c) {
        return title[c];
    }

    public boolean isCellEditable(int r, int c) {
        return false;
    }

    public Object getValueAt(int r, int c) {
        return data[r][c];
    }

    public Class getColumnClass(int c) {
        try {
            if (c == 0) {
                return Class.forName("java.lang.Long");
            }
            if (c == 1) {
                return Class.forName("java.lang.String");
            }
            if (c >= 2 && c <= 6) {
                return Class.forName("java.lang.Float");
            }

        } catch (ClassNotFoundException cfne) {
        }
        return null;
    }
}
